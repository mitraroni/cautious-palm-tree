import HeaderNavigation from "@/components/sections/header-navigation";
import SidebarNavigation from "@/components/sections/sidebar-navigation";
import MobileBottomNavigation from "@/components/sections/mobile-bottom-navigation";
import Footer from "@/components/sections/footer";
import LiveChatWidget from "@/components/sections/live-chat-widget";
import { Trophy, Clock, Users, DollarSign } from "lucide-react";

export default function TournamentsPage() {
  const tournaments = [
    {
      name: "Mega Slots Tournament",
      prize: "$50,000",
      players: "2,450",
      timeLeft: "3d 12h",
      status: "Active"
    },
    {
      name: "Live Casino Championship",
      prize: "$25,000",
      players: "1,230",
      timeLeft: "1d 8h",
      status: "Active"
    },
    {
      name: "Sports Betting Marathon",
      prize: "$15,000",
      players: "890",
      timeLeft: "5d 20h",
      status: "Active"
    }
  ];

  return (
    <div className="min-h-screen bg-primary-background">
      <HeaderNavigation />
      <SidebarNavigation />
      <MobileBottomNavigation />
      
      <main className="pb-16 pt-24 md:pb-0 lg:ml-16 lg:pt-24">
        <div className="container mx-auto px-4 lg:px-8 max-w-6xl">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Tournaments</h1>
            <p className="text-xl text-gray-400">
              Compete against other players for massive prize pools
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {tournaments.map((tournament, index) => (
              <div key={index} className="bg-[#0D1B2A] rounded-2xl p-6 border border-gray-800 hover:border-[#6FCF26]/50 transition-colors">
                <div className="flex items-center justify-between mb-4">
                  <Trophy className="h-8 w-8 text-[#FFB800]" />
                  <span className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-sm font-semibold">
                    {tournament.status}
                  </span>
                </div>
                
                <h3 className="text-xl font-bold text-white mb-4">{tournament.name}</h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400 flex items-center gap-2">
                      <DollarSign className="h-4 w-4" />
                      Prize Pool
                    </span>
                    <span className="text-[#6FCF26] font-bold">{tournament.prize}</span>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400 flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      Players
                    </span>
                    <span className="text-white font-semibold">{tournament.players}</span>
                  </div>
                  
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400 flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      Time Left
                    </span>
                    <span className="text-white font-semibold">{tournament.timeLeft}</span>
                  </div>
                </div>
                
                <button className="w-full mt-6 bg-[#6FCF26] hover:bg-[#5DB51F] text-white font-semibold px-6 py-3 rounded-lg transition-colors">
                  Join Tournament
                </button>
              </div>
            ))}
          </div>
          
          <div className="bg-[#0D1B2A] rounded-2xl p-8 border border-gray-800">
            <h2 className="text-2xl font-bold text-white mb-6">How Tournaments Work</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <div className="bg-[#6FCF26]/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                  <span className="text-[#6FCF26] font-bold text-xl">1</span>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Join a Tournament</h3>
                <p className="text-gray-400">Select a tournament and opt in to start competing</p>
              </div>
              
              <div>
                <div className="bg-[#6FCF26]/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                  <span className="text-[#6FCF26] font-bold text-xl">2</span>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Play & Compete</h3>
                <p className="text-gray-400">Earn points by playing eligible games during the tournament period</p>
              </div>
              
              <div>
                <div className="bg-[#6FCF26]/10 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                  <span className="text-[#6FCF26] font-bold text-xl">3</span>
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">Win Prizes</h3>
                <p className="text-gray-400">Climb the leaderboard and claim your share of the prize pool</p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
      <LiveChatWidget />
    </div>
  );
}