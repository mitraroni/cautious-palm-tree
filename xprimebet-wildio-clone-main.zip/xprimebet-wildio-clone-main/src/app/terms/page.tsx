import HeaderNavigation from "@/components/sections/header-navigation";
import SidebarNavigation from "@/components/sections/sidebar-navigation";
import MobileBottomNavigation from "@/components/sections/mobile-bottom-navigation";
import Footer from "@/components/sections/footer";
import LiveChatWidget from "@/components/sections/live-chat-widget";

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-primary-background">
      <HeaderNavigation />
      <SidebarNavigation />
      <MobileBottomNavigation />
      
      <main className="pb-16 pt-24 md:pb-0 lg:ml-16 lg:pt-24">
        <div className="container mx-auto px-4 lg:px-8 max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Terms & Conditions</h1>
          <p className="text-gray-400 mb-8">Last updated: January 2025</p>
          
          <div className="space-y-8 text-gray-300 leading-relaxed">
            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">1. Acceptance of Terms</h2>
              <p>
                By accessing and using Xprimebet, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.
              </p>
            </section>
            
            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">2. Eligibility</h2>
              <p className="mb-4">To use our services, you must:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Be at least 18 years of age (or the legal age in your jurisdiction)</li>
                <li>Not be located in a restricted territory</li>
                <li>Have the legal capacity to enter into a binding agreement</li>
                <li>Not be self-excluded from gambling activities</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">3. Account Registration</h2>
              <p className="mb-4">When creating an account, you agree to:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Provide accurate and complete information</li>
                <li>Maintain the security of your account credentials</li>
                <li>Not allow others to use your account</li>
                <li>Notify us immediately of any unauthorized use</li>
                <li>Have only one account per person</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">4. Deposits and Withdrawals</h2>
              <p className="mb-4">Regarding financial transactions:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>All deposits must be made in supported cryptocurrencies</li>
                <li>Minimum and maximum limits apply to transactions</li>
                <li>We reserve the right to request verification before processing withdrawals</li>
                <li>Withdrawals will be processed within 24 hours under normal circumstances</li>
                <li>You are responsible for any transaction fees</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">5. Bonuses and Promotions</h2>
              <p className="mb-4">All bonuses are subject to:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Specific terms and conditions for each promotion</li>
                <li>Wagering requirements before withdrawal</li>
                <li>Time limits for bonus use</li>
                <li>Maximum bet limits when playing with bonus funds</li>
                <li>Our right to void bonuses in case of abuse</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">6. Responsible Gambling</h2>
              <p>
                We are committed to responsible gambling. We provide tools for self-exclusion, deposit limits, and reality checks. If you believe you may have a gambling problem, please contact our support team or seek help from professional organizations.
              </p>
            </section>
            
            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">7. Game Rules and Fairness</h2>
              <p className="mb-4">All games on our platform:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Use certified random number generators</li>
                <li>Are provably fair where applicable</li>
                <li>Have specific rules that must be followed</li>
                <li>May have different return-to-player (RTP) percentages</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">8. Prohibited Activities</h2>
              <p className="mb-4">The following activities are strictly prohibited:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Creating multiple accounts</li>
                <li>Colluding with other players</li>
                <li>Using bots or automated software</li>
                <li>Money laundering or fraudulent activity</li>
                <li>Bonus abuse or irregular play patterns</li>
                <li>Providing false information</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">9. Account Suspension and Termination</h2>
              <p>
                We reserve the right to suspend or terminate your account if we suspect any violation of these terms, fraudulent activity, or for any other reason we deem necessary.
              </p>
            </section>
            
            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">10. Limitation of Liability</h2>
              <p>
                To the fullest extent permitted by law, Xprimebet shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use or inability to use the service.
              </p>
            </section>
            
            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">11. Changes to Terms</h2>
              <p>
                We reserve the right to modify these terms at any time. Changes will be effective immediately upon posting. Your continued use of the service constitutes acceptance of the modified terms.
              </p>
            </section>
            
            <section>
              <h2 className="text-2xl font-semibold text-white mb-4">12. Contact Information</h2>
              <p>
                For questions about these Terms & Conditions, please contact our support team via live chat or email at support@xprimebet.io
              </p>
            </section>
          </div>
        </div>
      </main>

      <Footer />
      <LiveChatWidget />
    </div>
  );
}