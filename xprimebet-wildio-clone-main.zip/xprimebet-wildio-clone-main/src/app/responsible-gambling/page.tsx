import HeaderNavigation from "@/components/sections/header-navigation";
import SidebarNavigation from "@/components/sections/sidebar-navigation";
import MobileBottomNavigation from "@/components/sections/mobile-bottom-navigation";
import Footer from "@/components/sections/footer";
import LiveChatWidget from "@/components/sections/live-chat-widget";
import { Shield, Clock, DollarSign, User } from "lucide-react";

export default function ResponsibleGamblingPage() {
  const tools = [
    {
      icon: <DollarSign className="h-8 w-8" />,
      title: "Deposit Limits",
      description: "Set daily, weekly, or monthly deposit limits to control your spending"
    },
    {
      icon: <Clock className="h-8 w-8" />,
      title: "Session Time Limits",
      description: "Set time limits to manage how long you play in a single session"
    },
    {
      icon: <User className="h-8 w-8" />,
      title: "Self-Exclusion",
      description: "Temporarily or permanently exclude yourself from using our services"
    },
    {
      icon: <Shield className="h-8 w-8" />,
      title: "Reality Checks",
      description: "Receive regular reminders about how long you've been playing"
    }
  ];

  return (
    <div className="min-h-screen bg-primary-background">
      <HeaderNavigation />
      <SidebarNavigation />
      <MobileBottomNavigation />
      
      <main className="pb-16 pt-24 md:pb-0 lg:ml-16 lg:pt-24">
        <div className="container mx-auto px-4 lg:px-8 max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Responsible Gambling</h1>
          <p className="text-xl text-gray-400 mb-12">
            We're committed to promoting responsible gambling and player safety
          </p>
          
          <div className="space-y-8">
            <section className="bg-[#0D1B2A] rounded-2xl p-8 border border-gray-800">
              <h2 className="text-2xl font-semibold text-white mb-4">Our Commitment</h2>
              <p className="text-gray-300 leading-relaxed">
                At Xprimebet, we believe that gambling should be an enjoyable form of entertainment. We're dedicated to ensuring that our players can gamble safely and responsibly. We provide various tools and resources to help you maintain control over your gambling activities.
              </p>
            </section>
            
            <section>
              <h2 className="text-2xl font-semibold text-white mb-6">Responsible Gambling Tools</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {tools.map((tool, index) => (
                  <div key={index} className="bg-[#0D1B2A] rounded-xl p-6 border border-gray-800">
                    <div className="text-[#6FCF26] mb-4">
                      {tool.icon}
                    </div>
                    <h3 className="text-lg font-semibold text-white mb-2">{tool.title}</h3>
                    <p className="text-gray-400">{tool.description}</p>
                  </div>
                ))}
              </div>
            </section>
            
            <section className="bg-[#0D1B2A] rounded-2xl p-8 border border-gray-800">
              <h2 className="text-2xl font-semibold text-white mb-4">Warning Signs</h2>
              <p className="text-gray-300 mb-4">
                You may have a gambling problem if you:
              </p>
              <ul className="text-gray-300 space-y-2 list-disc list-inside ml-4">
                <li>Spend more time or money gambling than you can afford</li>
                <li>Chase losses by gambling more to win back what you've lost</li>
                <li>Neglect work, family, or other responsibilities</li>
                <li>Borrow money to gamble or pay gambling debts</li>
                <li>Feel anxious or irritable when trying to cut down</li>
                <li>Lie about your gambling activities</li>
              </ul>
            </section>
            
            <section className="bg-[#0D1B2A] rounded-2xl p-8 border border-gray-800">
              <h2 className="text-2xl font-semibold text-white mb-4">Get Help</h2>
              <p className="text-gray-300 mb-6">
                If you're concerned about your gambling, there are organizations that can help:
              </p>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">Gamblers Anonymous</h3>
                  <p className="text-gray-400">Website: <a href="https://www.gamblersanonymous.org" className="text-[#6FCF26] hover:underline">www.gamblersanonymous.org</a></p>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">GamCare</h3>
                  <p className="text-gray-400">Website: <a href="https://www.gamcare.org.uk" className="text-[#6FCF26] hover:underline">www.gamcare.org.uk</a></p>
                  <p className="text-gray-400">Helpline: 0808 8020 133</p>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">BeGambleAware</h3>
                  <p className="text-gray-400">Website: <a href="https://www.begambleaware.org" className="text-[#6FCF26] hover:underline">www.begambleaware.org</a></p>
                </div>
              </div>
            </section>
            
            <section className="bg-[#0D1B2A] rounded-2xl p-8 border border-gray-800">
              <h2 className="text-2xl font-semibold text-white mb-4">Underage Gambling</h2>
              <p className="text-gray-300 leading-relaxed">
                You must be at least 18 years old (or the legal age in your jurisdiction) to use our services. We take underage gambling seriously and employ age verification measures. Parents and guardians should use internet filtering software to prevent minors from accessing gambling sites.
              </p>
            </section>
          </div>
        </div>
      </main>

      <Footer />
      <LiveChatWidget />
    </div>
  );
}