import HeaderNavigation from "@/components/sections/header-navigation";
import SidebarNavigation from "@/components/sections/sidebar-navigation";
import MobileBottomNavigation from "@/components/sections/mobile-bottom-navigation";
import Footer from "@/components/sections/footer";
import LiveChatWidget from "@/components/sections/live-chat-widget";

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-primary-background">
      <HeaderNavigation />
      <SidebarNavigation />
      <MobileBottomNavigation />
      
      <main className="pb-16 pt-24 md:pb-0 lg:ml-16 lg:pt-24">
        <div className="container mx-auto px-4 lg:px-8 max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-8">About Xprimebet</h1>
          
          <div className="space-y-6 text-gray-300 leading-relaxed">
            <p className="text-lg">
              Welcome to Xprimebet, the premier destination for cryptocurrency gaming and sports betting. We're committed to providing our players with a world-class gaming experience backed by cutting-edge technology and exceptional customer service.
            </p>
            
            <h2 className="text-2xl font-semibold text-white mt-8 mb-4">Our Mission</h2>
            <p>
              Our mission is to revolutionize online gaming by combining the excitement of casino games and sports betting with the security and transparency of blockchain technology. We believe in fair play, instant transactions, and complete anonymity for our users.
            </p>
            
            <h2 className="text-2xl font-semibold text-white mt-8 mb-4">Why Choose Xprimebet?</h2>
            <ul className="list-disc list-inside space-y-3 ml-4">
              <li>Over 8,000+ casino games from top providers</li>
              <li>Comprehensive sportsbook covering 80+ sports</li>
              <li>Instant cryptocurrency deposits and withdrawals</li>
              <li>Provably fair gaming technology</li>
              <li>24/7 customer support</li>
              <li>Generous bonuses and promotions</li>
              <li>VIP loyalty program with exclusive rewards</li>
            </ul>
            
            <h2 className="text-2xl font-semibold text-white mt-8 mb-4">Licensing & Security</h2>
            <p>
              Xprimebet is owned and operated by Nonce Gaming B.V., a company incorporated under the laws of Curaçao with company registration number 161858. We hold a valid Certificate of Operation (OGL/2024/210/0198) and are committed to maintaining the highest standards of security and fair play.
            </p>
            
            <h2 className="text-2xl font-semibold text-white mt-8 mb-4">Contact Us</h2>
            <p>
              Have questions? Our support team is available 24/7 via live chat to assist you with any inquiries.
            </p>
          </div>
        </div>
      </main>

      <Footer />
      <LiveChatWidget />
    </div>
  );
}