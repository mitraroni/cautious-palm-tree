import HeaderNavigation from "@/components/sections/header-navigation";
import SidebarNavigation from "@/components/sections/sidebar-navigation";
import MobileBottomNavigation from "@/components/sections/mobile-bottom-navigation";
import Footer from "@/components/sections/footer";
import LiveChatWidget from "@/components/sections/live-chat-widget";
import { MessageCircle, Mail, HelpCircle, Clock } from "lucide-react";

export default function SupportPage() {
  const faqs = [
    {
      question: "How do I deposit cryptocurrency?",
      answer: "Click on the Deposit button, select your preferred cryptocurrency, and send funds to the provided address. Deposits are credited instantly."
    },
    {
      question: "How long do withdrawals take?",
      answer: "Cryptocurrency withdrawals are processed within 24 hours. Most withdrawals are completed within a few hours."
    },
    {
      question: "What is the minimum deposit?",
      answer: "The minimum deposit varies by cryptocurrency but is typically equivalent to $10 USD."
    },
    {
      question: "Are there any fees?",
      answer: "Xprimebet does not charge deposit or withdrawal fees. You only pay the network transaction fees for cryptocurrency transfers."
    },
    {
      question: "How do I claim bonuses?",
      answer: "Bonuses are automatically credited when you meet the requirements. Some bonuses may require you to opt-in first."
    },
    {
      question: "Is my information secure?",
      answer: "Yes, we use industry-standard encryption and security measures to protect your data and funds."
    }
  ];

  return (
    <div className="min-h-screen bg-primary-background">
      <HeaderNavigation />
      <SidebarNavigation />
      <MobileBottomNavigation />
      
      <main className="pb-16 pt-24 md:pb-0 lg:ml-16 lg:pt-24">
        <div className="container mx-auto px-4 lg:px-8 max-w-4xl">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 text-center">Support Center</h1>
          <p className="text-xl text-gray-400 text-center mb-12">
            We're here to help 24/7
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
            <div className="bg-[#0D1B2A] rounded-xl p-6 border border-gray-800">
              <MessageCircle className="h-12 w-12 text-[#6FCF26] mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">Live Chat</h3>
              <p className="text-gray-400 mb-4">Get instant help from our support team</p>
              <button className="bg-[#6FCF26] hover:bg-[#5DB51F] text-white font-semibold px-6 py-3 rounded-lg transition-colors">
                Start Chat
              </button>
            </div>
            
            <div className="bg-[#0D1B2A] rounded-xl p-6 border border-gray-800">
              <Mail className="h-12 w-12 text-[#3B82F6] mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">Email Support</h3>
              <p className="text-gray-400 mb-4">Send us an email and we'll respond within 24 hours</p>
              <a href="mailto:support@xprimebet.io" className="inline-block bg-[#3B82F6] hover:bg-blue-600 text-white font-semibold px-6 py-3 rounded-lg transition-colors">
                Email Us
              </a>
            </div>
          </div>
          
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-6">
              <Clock className="h-8 w-8 text-[#6FCF26]" />
              <h2 className="text-3xl font-bold text-white">Support Hours</h2>
            </div>
            <div className="bg-[#0D1B2A] rounded-xl p-6 border border-gray-800">
              <p className="text-gray-300 text-lg">
                Our support team is available <span className="text-[#6FCF26] font-bold">24/7</span> to assist you with any questions or issues.
              </p>
            </div>
          </section>
          
          <section>
            <div className="flex items-center gap-3 mb-6">
              <HelpCircle className="h-8 w-8 text-[#6FCF26]" />
              <h2 className="text-3xl font-bold text-white">Frequently Asked Questions</h2>
            </div>
            <div className="space-y-4">
              {faqs.map((faq, index) => (
                <details key={index} className="bg-[#0D1B2A] rounded-xl border border-gray-800 overflow-hidden">
                  <summary className="p-6 cursor-pointer hover:bg-[#132038] transition-colors">
                    <span className="text-lg font-semibold text-white">{faq.question}</span>
                  </summary>
                  <div className="px-6 pb-6">
                    <p className="text-gray-400">{faq.answer}</p>
                  </div>
                </details>
              ))}
            </div>
          </section>
        </div>
      </main>

      <Footer />
      <LiveChatWidget />
    </div>
  );
}