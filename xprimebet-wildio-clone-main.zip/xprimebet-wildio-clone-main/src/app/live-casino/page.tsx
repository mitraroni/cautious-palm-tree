import HeaderNavigation from "@/components/sections/header-navigation";
import SidebarNavigation from "@/components/sections/sidebar-navigation";
import MobileBottomNavigation from "@/components/sections/mobile-bottom-navigation";
import Footer from "@/components/sections/footer";
import LiveChatWidget from "@/components/sections/live-chat-widget";
import Image from "next/image";

export default function LiveCasinoPage() {
  const games = [
    { name: "Roulette", tables: "24 tables" },
    { name: "Blackjack", tables: "18 tables" },
    { name: "Baccarat", tables: "12 tables" },
    { name: "Poker", tables: "8 tables" },
    { name: "Game Shows", tables: "6 shows" },
    { name: "Craps", tables: "4 tables" }
  ];

  return (
    <div className="min-h-screen bg-primary-background">
      <HeaderNavigation />
      <SidebarNavigation />
      <MobileBottomNavigation />
      
      <main className="pb-16 pt-24 md:pb-0 lg:ml-16 lg:pt-24">
        <div className="container mx-auto px-4 lg:px-8 max-w-6xl">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Live Casino</h1>
            <p className="text-xl text-gray-400">
              Experience the thrill of real dealers and authentic casino atmosphere
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6 mb-12">
            {games.map((game, index) => (
              <div key={index} className="bg-[#0D1B2A] rounded-xl p-6 border border-gray-800 text-center hover:border-[#6FCF26]/50 transition-colors cursor-pointer">
                <h3 className="text-xl font-bold text-white mb-2">{game.name}</h3>
                <p className="text-[#6FCF26]">{game.tables}</p>
              </div>
            ))}
          </div>
          
          <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-8 text-white">
            <div className="max-w-2xl">
              <h2 className="text-3xl font-bold mb-4">Why Live Casino?</h2>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <span className="text-[#FFB800] text-xl">✓</span>
                  <span>Real professional dealers streaming in HD</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-[#FFB800] text-xl">✓</span>
                  <span>Chat with dealers and other players</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-[#FFB800] text-xl">✓</span>
                  <span>Authentic casino experience from home</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-[#FFB800] text-xl">✓</span>
                  <span>Multiple camera angles and game statistics</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </main>

      <Footer />
      <LiveChatWidget />
    </div>
  );
}