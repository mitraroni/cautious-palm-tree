import HeaderNavigation from "@/components/sections/header-navigation";
import SidebarNavigation from "@/components/sections/sidebar-navigation";
import MobileBottomNavigation from "@/components/sections/mobile-bottom-navigation";
import Footer from "@/components/sections/footer";
import LiveChatWidget from "@/components/sections/live-chat-widget";
import { Gift, Zap, Trophy, TrendingUp } from "lucide-react";

export default function PromotionsPage() {
  const promotions = [
    {
      icon: <Gift className="h-12 w-12" />,
      title: "Welcome Bonus",
      subtitle: "120% up to $5,000 + 75 Free Spins",
      description: "New players get an incredible welcome package with their first deposit. Boost your bankroll and enjoy free spins on popular slots.",
      color: "from-purple-600 to-blue-600"
    },
    {
      icon: <Zap className="h-12 w-12" />,
      title: "Daily Rakeback",
      subtitle: "Earn rewards from every bet",
      description: "Get a percentage of your bets back every day, regardless of whether you win or lose. The more you play, the more you earn.",
      color: "from-green-600 to-teal-600"
    },
    {
      icon: <Trophy className="h-12 w-12" />,
      title: "Tournaments",
      subtitle: "Compete for big prizes",
      description: "Join our regular casino and sports tournaments with huge prize pools. Climb the leaderboard and claim your share of the rewards.",
      color: "from-orange-600 to-red-600"
    },
    {
      icon: <TrendingUp className="h-12 w-12" />,
      title: "VIP Loyalty Program",
      subtitle: "Exclusive rewards for loyal players",
      description: "Progress through VIP levels to unlock cashback, exclusive bonuses, faster withdrawals, and a dedicated account manager.",
      color: "from-yellow-600 to-orange-600"
    }
  ];

  return (
    <div className="min-h-screen bg-primary-background">
      <HeaderNavigation />
      <SidebarNavigation />
      <MobileBottomNavigation />
      
      <main className="pb-16 pt-24 md:pb-0 lg:ml-16 lg:pt-24">
        <div className="container mx-auto px-4 lg:px-8 max-w-6xl">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 text-center">Promotions & Bonuses</h1>
          <p className="text-xl text-gray-400 text-center mb-12">
            Exclusive offers and rewards for Xprimebet players
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            {promotions.map((promo, index) => (
              <div 
                key={index}
                className="relative overflow-hidden rounded-2xl bg-gradient-to-br p-[1px] hover:scale-[1.02] transition-transform"
                style={{ backgroundImage: `linear-gradient(to bottom right, ${promo.color})` }}
              >
                <div className="bg-[#0D1B2A] rounded-2xl p-8 h-full">
                  <div className="text-[#6FCF26] mb-4">
                    {promo.icon}
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">{promo.title}</h3>
                  <p className="text-[#FFB800] font-semibold mb-4">{promo.subtitle}</p>
                  <p className="text-gray-400 leading-relaxed">{promo.description}</p>
                  <button className="mt-6 bg-[#6FCF26] hover:bg-[#5DB51F] text-white font-semibold px-6 py-3 rounded-lg transition-colors">
                    Claim Now
                  </button>
                </div>
              </div>
            ))}
          </div>
          
          <div className="bg-[#0D1B2A] rounded-2xl p-8 border border-gray-800">
            <h2 className="text-2xl font-bold text-white mb-4">Terms & Conditions</h2>
            <ul className="text-gray-400 space-y-2 list-disc list-inside">
              <li>All bonuses are subject to wagering requirements</li>
              <li>Minimum deposit may apply for certain promotions</li>
              <li>Free spins are valid for 7 days from issue date</li>
              <li>Only one bonus per player/household</li>
              <li>Full terms and conditions apply</li>
            </ul>
          </div>
        </div>
      </main>

      <Footer />
      <LiveChatWidget />
    </div>
  );
}