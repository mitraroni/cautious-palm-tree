import Image from "next/image";
import CookieNoticeBanner from "@/components/sections/cookie-notice-banner";
import HeaderNavigation from "@/components/sections/header-navigation";
import SidebarNavigation from "@/components/sections/sidebar-navigation";
import MobileBottomNavigation from "@/components/sections/mobile-bottom-navigation";
import HeroWelcomeSection from "@/components/sections/hero-welcome-section";
import DepositCryptoBanner from "@/components/sections/deposit-crypto-banner";
import CasinoSportsCards from "@/components/sections/casino-sports-cards";
import LiveWinsCarousel from "@/components/sections/live-wins-carousel";
import CasinoGamesGrid from "@/components/sections/casino-games-grid";
import DailyRakebackBanner from "@/components/sections/daily-rakeback-banner";
import SportsCategoriesGrid from "@/components/sections/sports-categories-grid";
import GameProvidersCarousel from "@/components/sections/game-providers-carousel";
import LeaderboardTable from "@/components/sections/leaderboard-table";
import ContentAboutCasino from "@/components/sections/content-about-casino";
import CryptoPaymentLogos from "@/components/sections/crypto-payment-logos";
import Footer from "@/components/sections/footer";
import LiveChatWidget from "@/components/sections/live-chat-widget";

export default function Home() {
  return (
    <div className="min-h-screen bg-primary-background">
      <CookieNoticeBanner />
      <HeaderNavigation />
      <SidebarNavigation />
      <MobileBottomNavigation />
      
      <main className="pb-16 pt-14 md:pb-0 lg:ml-16 lg:pt-16">
        <HeroWelcomeSection />
        
        <div className="container mx-auto px-4 lg:px-8">
          <DepositCryptoBanner />
          <CasinoSportsCards />
        </div>

        <LiveWinsCarousel />

        <div className="container mx-auto px-4 lg:px-8">
          <CasinoGamesGrid />
        </div>

        <DailyRakebackBanner />

        <div className="container mx-auto px-4 lg:px-8">
          <SportsCategoriesGrid />
        </div>

        <GameProvidersCarousel />
        <LeaderboardTable />
      </main>

      <ContentAboutCasino />
      <CryptoPaymentLogos />
      <Footer />
      <LiveChatWidget />
    </div>
  );
}