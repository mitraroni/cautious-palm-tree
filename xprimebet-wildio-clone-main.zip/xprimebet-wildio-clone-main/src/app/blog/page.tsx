import HeaderNavigation from "@/components/sections/header-navigation";
import SidebarNavigation from "@/components/sections/sidebar-navigation";
import MobileBottomNavigation from "@/components/sections/mobile-bottom-navigation";
import Footer from "@/components/sections/footer";
import LiveChatWidget from "@/components/sections/live-chat-widget";
import { Calendar, User } from "lucide-react";

export default function BlogPage() {
  const posts = [
    {
      title: "Top 10 Crypto Casino Games in 2025",
      excerpt: "Discover the most popular crypto casino games that players are loving this year.",
      date: "Jan 15, 2025",
      author: "Xprimebet Team"
    },
    {
      title: "Understanding Provably Fair Gaming",
      excerpt: "Learn how blockchain technology ensures fairness in online casino games.",
      date: "Jan 10, 2025",
      author: "Xprimebet Team"
    },
    {
      title: "Sports Betting Strategies for Beginners",
      excerpt: "Essential tips and strategies for new sports bettors to get started.",
      date: "Jan 5, 2025",
      author: "Xprimebet Team"
    },
    {
      title: "Cryptocurrency Guide for Casino Players",
      excerpt: "Everything you need to know about using crypto for online gambling.",
      date: "Dec 28, 2024",
      author: "Xprimebet Team"
    },
    {
      title: "Maximizing Your Casino Bonuses",
      excerpt: "Tips and tricks to get the most value from casino bonuses and promotions.",
      date: "Dec 20, 2024",
      author: "Xprimebet Team"
    },
    {
      title: "Live Casino vs Regular Casino Games",
      excerpt: "Compare the benefits of live dealer games versus traditional online casino games.",
      date: "Dec 15, 2024",
      author: "Xprimebet Team"
    }
  ];

  return (
    <div className="min-h-screen bg-primary-background">
      <HeaderNavigation />
      <SidebarNavigation />
      <MobileBottomNavigation />
      
      <main className="pb-16 pt-24 md:pb-0 lg:ml-16 lg:pt-24">
        <div className="container mx-auto px-4 lg:px-8 max-w-6xl">
          <div className="mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Blog</h1>
            <p className="text-xl text-gray-400">
              News, guides, and insights from the world of crypto gaming
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {posts.map((post, index) => (
              <article key={index} className="bg-[#0D1B2A] rounded-xl overflow-hidden border border-gray-800 hover:border-[#6FCF26]/50 transition-colors cursor-pointer">
                <div className="h-48 bg-gradient-to-br from-purple-600 to-blue-600" />
                <div className="p-6">
                  <h2 className="text-xl font-bold text-white mb-3 hover:text-[#6FCF26] transition-colors">
                    {post.title}
                  </h2>
                  <p className="text-gray-400 mb-4 line-clamp-2">{post.excerpt}</p>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      <span>{post.date}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <User className="h-4 w-4" />
                      <span>{post.author}</span>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </main>

      <Footer />
      <LiveChatWidget />
    </div>
  );
}