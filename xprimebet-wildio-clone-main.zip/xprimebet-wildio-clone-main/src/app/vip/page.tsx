import HeaderNavigation from "@/components/sections/header-navigation";
import SidebarNavigation from "@/components/sections/sidebar-navigation";
import MobileBottomNavigation from "@/components/sections/mobile-bottom-navigation";
import Footer from "@/components/sections/footer";
import LiveChatWidget from "@/components/sections/live-chat-widget";
import { Crown, Gift, Zap, Users } from "lucide-react";

export default function VIPPage() {
  const levels = [
    { name: "Bronze", color: "from-orange-700 to-orange-600", cashback: "5%", bonus: "$100" },
    { name: "Silver", color: "from-gray-500 to-gray-400", cashback: "8%", bonus: "$500" },
    { name: "Gold", color: "from-yellow-600 to-yellow-500", cashback: "10%", bonus: "$1,500" },
    { name: "Platinum", color: "from-cyan-600 to-cyan-500", cashback: "12%", bonus: "$5,000" },
    { name: "Diamond", color: "from-blue-600 to-purple-600", cashback: "15%", bonus: "$15,000" }
  ];

  const benefits = [
    {
      icon: <Gift className="h-10 w-10" />,
      title: "Exclusive Bonuses",
      description: "Get special bonuses and promotions not available to regular players"
    },
    {
      icon: <Zap className="h-10 w-10" />,
      title: "Faster Withdrawals",
      description: "Priority processing of your withdrawal requests"
    },
    {
      icon: <Users className="h-10 w-10" />,
      title: "Personal Manager",
      description: "Dedicated account manager for all your needs"
    },
    {
      icon: <Crown className="h-10 w-10" />,
      title: "Special Events",
      description: "Invitations to exclusive tournaments and events"
    }
  ];

  return (
    <div className="min-h-screen bg-primary-background">
      <HeaderNavigation />
      <SidebarNavigation />
      <MobileBottomNavigation />
      
      <main className="pb-16 pt-24 md:pb-0 lg:ml-16 lg:pt-24">
        <div className="container mx-auto px-4 lg:px-8 max-w-6xl">
          <div className="text-center mb-12">
            <div className="flex justify-center mb-4">
              <Crown className="h-16 w-16 text-[#FFB800]" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">VIP Club</h1>
            <p className="text-xl text-gray-400">
              Experience premium treatment with exclusive rewards and benefits
            </p>
          </div>
          
          <section className="mb-16">
            <h2 className="text-3xl font-bold text-white text-center mb-8">VIP Levels</h2>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {levels.map((level, index) => (
                <div 
                  key={index} 
                  className={`relative overflow-hidden rounded-xl bg-gradient-to-br ${level.color} p-6 text-center text-white`}
                >
                  <h3 className="text-2xl font-bold mb-4">{level.name}</h3>
                  <div className="space-y-2">
                    <p className="text-sm opacity-90">Cashback</p>
                    <p className="text-3xl font-bold">{level.cashback}</p>
                    <p className="text-sm opacity-90 mt-4">Level Bonus</p>
                    <p className="text-xl font-bold">{level.bonus}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>
          
          <section className="mb-16">
            <h2 className="text-3xl font-bold text-white text-center mb-8">VIP Benefits</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {benefits.map((benefit, index) => (
                <div key={index} className="bg-[#0D1B2A] rounded-xl p-6 border border-gray-800 text-center">
                  <div className="flex justify-center text-[#6FCF26] mb-4">
                    {benefit.icon}
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{benefit.title}</h3>
                  <p className="text-gray-400 text-sm">{benefit.description}</p>
                </div>
              ))}
            </div>
          </section>
          
          <section className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-8 text-center text-white">
            <h2 className="text-3xl font-bold mb-4">Ready to Join?</h2>
            <p className="text-lg mb-6 opacity-90">
              Start playing today and automatically progress through VIP levels as you play
            </p>
            <button className="bg-white text-purple-600 font-bold px-8 py-4 rounded-lg hover:bg-gray-100 transition-colors">
              Start Your VIP Journey
            </button>
          </section>
        </div>
      </main>

      <Footer />
      <LiveChatWidget />
    </div>
  );
}