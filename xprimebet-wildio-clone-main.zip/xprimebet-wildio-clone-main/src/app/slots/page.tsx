import HeaderNavigation from "@/components/sections/header-navigation";
import SidebarNavigation from "@/components/sections/sidebar-navigation";
import MobileBottomNavigation from "@/components/sections/mobile-bottom-navigation";
import CasinoGamesGrid from "@/components/sections/casino-games-grid";
import Footer from "@/components/sections/footer";
import LiveChatWidget from "@/components/sections/live-chat-widget";

export default function SlotsPage() {
  return (
    <div className="min-h-screen bg-primary-background">
      <HeaderNavigation />
      <SidebarNavigation />
      <MobileBottomNavigation />
      
      <main className="pb-16 pt-24 md:pb-0 lg:ml-16 lg:pt-24">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Slot Games</h1>
            <p className="text-xl text-gray-400">
              Spin the reels on thousands of exciting slot games with massive jackpots
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div className="bg-[#0D1B2A] rounded-xl p-6 border border-gray-800">
              <h3 className="text-xl font-bold text-white mb-3">Classic Slots</h3>
              <p className="text-gray-400">Traditional 3-reel slots with simple gameplay and nostalgic vibes</p>
            </div>
            
            <div className="bg-[#0D1B2A] rounded-xl p-6 border border-gray-800">
              <h3 className="text-xl font-bold text-white mb-3">Video Slots</h3>
              <p className="text-gray-400">Modern 5-reel slots with stunning graphics and bonus features</p>
            </div>
            
            <div className="bg-[#0D1B2A] rounded-xl p-6 border border-gray-800">
              <h3 className="text-xl font-bold text-white mb-3">Progressive Jackpots</h3>
              <p className="text-gray-400">Life-changing jackpots that grow with every spin</p>
            </div>
          </div>
          
          <CasinoGamesGrid />
        </div>
      </main>

      <Footer />
      <LiveChatWidget />
    </div>
  );
}