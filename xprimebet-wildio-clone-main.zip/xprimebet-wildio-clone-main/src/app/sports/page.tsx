import HeaderNavigation from "@/components/sections/header-navigation";
import SidebarNavigation from "@/components/sections/sidebar-navigation";
import MobileBottomNavigation from "@/components/sections/mobile-bottom-navigation";
import SportsCategoriesGrid from "@/components/sections/sports-categories-grid";
import Footer from "@/components/sections/footer";
import LiveChatWidget from "@/components/sections/live-chat-widget";

export default function SportsPage() {
  return (
    <div className="min-h-screen bg-primary-background">
      <HeaderNavigation />
      <SidebarNavigation />
      <MobileBottomNavigation />
      
      <main className="pb-16 pt-24 md:pb-0 lg:ml-16 lg:pt-24">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Sports Betting</h1>
            <p className="text-xl text-gray-400">
              Bet on 80+ sports including Football, Basketball, Tennis, Cricket, and eSports
            </p>
          </div>
          
          <SportsCategoriesGrid />
          
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-[#0D1B2A] rounded-xl p-6 border border-gray-800">
              <h3 className="text-xl font-bold text-white mb-3">Live Betting</h3>
              <p className="text-gray-400">Bet on live matches with real-time odds and instant updates</p>
            </div>
            
            <div className="bg-[#0D1B2A] rounded-xl p-6 border border-gray-800">
              <h3 className="text-xl font-bold text-white mb-3">Best Odds</h3>
              <p className="text-gray-400">Competitive odds across all sports and events</p>
            </div>
            
            <div className="bg-[#0D1B2A] rounded-xl p-6 border border-gray-800">
              <h3 className="text-xl font-bold text-white mb-3">Fast Payouts</h3>
              <p className="text-gray-400">Quick settlement of winning bets with crypto withdrawals</p>
            </div>
          </div>
        </div>
      </main>

      <Footer />
      <LiveChatWidget />
    </div>
  );
}