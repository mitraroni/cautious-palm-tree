import HeaderNavigation from "@/components/sections/header-navigation";
import SidebarNavigation from "@/components/sections/sidebar-navigation";
import MobileBottomNavigation from "@/components/sections/mobile-bottom-navigation";
import Footer from "@/components/sections/footer";
import LiveChatWidget from "@/components/sections/live-chat-widget";
import { TrendingUp, Users, DollarSign, BarChart } from "lucide-react";

export default function AffiliatePage() {
  const benefits = [
    {
      icon: <DollarSign className="h-12 w-12" />,
      title: "Up to 45% Revenue Share",
      description: "Industry-leading commission rates that scale with performance"
    },
    {
      icon: <Users className="h-12 w-12" />,
      title: "Lifetime Commissions",
      description: "Earn from every player you refer for as long as they play"
    },
    {
      icon: <TrendingUp className="h-12 w-12" />,
      title: "No Negative Carryover",
      description: "Start each month fresh with no negative balance rollover"
    },
    {
      icon: <BarChart className="h-12 w-12" />,
      title: "Advanced Analytics",
      description: "Track your performance with real-time reporting tools"
    }
  ];

  return (
    <div className="min-h-screen bg-primary-background">
      <HeaderNavigation />
      <SidebarNavigation />
      <MobileBottomNavigation />
      
      <main className="pb-16 pt-24 md:pb-0 lg:ml-16 lg:pt-24">
        <div className="container mx-auto px-4 lg:px-8 max-w-6xl">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Affiliate Program</h1>
            <p className="text-xl text-gray-400">
              Partner with Xprimebet and earn generous commissions
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            {benefits.map((benefit, index) => (
              <div key={index} className="bg-[#0D1B2A] rounded-xl p-8 border border-gray-800">
                <div className="text-[#6FCF26] mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-2xl font-bold text-white mb-3">{benefit.title}</h3>
                <p className="text-gray-400">{benefit.description}</p>
              </div>
            ))}
          </div>
          
          <div className="bg-[#0D1B2A] rounded-2xl p-8 border border-gray-800 mb-12">
            <h2 className="text-2xl font-bold text-white mb-6">Commission Structure</h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-4 bg-[#132038] rounded-lg">
                <span className="text-gray-300">0 - 10 Players</span>
                <span className="text-[#6FCF26] font-bold text-xl">25%</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-[#132038] rounded-lg">
                <span className="text-gray-300">11 - 50 Players</span>
                <span className="text-[#6FCF26] font-bold text-xl">30%</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-[#132038] rounded-lg">
                <span className="text-gray-300">51 - 100 Players</span>
                <span className="text-[#6FCF26] font-bold text-xl">35%</span>
              </div>
              <div className="flex justify-between items-center p-4 bg-[#132038] rounded-lg">
                <span className="text-gray-300">101+ Players</span>
                <span className="text-[#6FCF26] font-bold text-xl">45%</span>
              </div>
            </div>
          </div>
          
          <div className="bg-gradient-to-r from-green-600 to-teal-600 rounded-2xl p-8 text-center text-white">
            <h2 className="text-3xl font-bold mb-4">Ready to Start Earning?</h2>
            <p className="text-lg mb-6 opacity-90">
              Join our affiliate program today and start earning commissions from your referrals
            </p>
            <button className="bg-white text-green-600 font-bold px-8 py-4 rounded-lg hover:bg-gray-100 transition-colors">
              Apply Now
            </button>
          </div>
        </div>
      </main>

      <Footer />
      <LiveChatWidget />
    </div>
  );
}