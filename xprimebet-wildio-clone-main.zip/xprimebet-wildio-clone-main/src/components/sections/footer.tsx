import Image from 'next/image';
import { Instagram, MessageCircle, Star, Twitter, Send } from 'lucide-react';

const ThemeToggle = () => (
  <div className="relative flex w-[76px] cursor-pointer items-center rounded-full bg-[#061824] p-1 text-sm font-semibold text-gray-400">
    <div className="absolute h-[28px] w-[34px] rounded-full bg-[#5cb85c] transition-transform duration-300" style={{ transform: 'translateX(34px)' }} />
    <span className="relative z-10 flex h-7 w-1/2 items-center justify-center">AM</span>
    <span className="relative z-10 flex h-7 w-1/2 items-center justify-center text-white">PM</span>
  </div>
);

const ExcellentSupportBadge = () => (
  <div className="relative flex h-[72px] w-[120px] flex-col items-center justify-center gap-y-1 rounded-lg border border-gray-700 bg-gray-800/10 p-2 text-center">
    <div className="flex text-[#ffb700]">
      <Star fill="currentColor" strokeWidth={0} className="h-3.5 w-3.5" />
      <Star fill="currentColor" strokeWidth={0} className="h-3.5 w-3.5" />
      <Star fill="currentColor" strokeWidth={0} className="h-3.5 w-3.5" />
      <Star fill="currentColor" strokeWidth={0} className="h-3.5 w-3.5" />
      <Star fill="currentColor" strokeWidth={0} className="h-3.5 w-3.5" />
    </div>
    <div className="text-[9px] font-bold uppercase leading-none tracking-wider text-white">
      <p>Excellent Support</p>
    </div>
    <p className="text-[8px] uppercase text-gray-400">2025</p>
  </div>
);

const FooterLink = ({ href, children }: { href: string; children: React.ReactNode }) => (
  <li>
    <a href={href} className="text-[#a0a0a0] hover:text-[#5cb85c] transition-colors leading-loose">
      {children}
    </a>
  </li>
);

const Footer = () => {
    const socialLinks = [
        { icon: <Send className="h-5 w-5" />, href: "https://t.me/wild_io", label: "Telegram" },
        { icon: <Twitter className="h-5 w-5" />, href: "https://x.com/wild_io", label: "Twitter" },
        { icon: <Instagram className="h-5 w-5" />, href: "https://instagram.com/wild.io_casino", label: "Instagram" },
        { icon: <MessageCircle className="h-5 w-5" />, href: "https://discord.gg/wildio", label: "Discord" },
    ];

    const linkColumns = {
        'SLOT GAMES': [
            { text: 'Slots', href: '/slots' },
            { text: 'Skill Games', href: '/casino' },
            { text: 'Jackpot', href: '/casino' },
            { text: 'Bonus Buy', href: '/casino' },
            { text: 'Crash Games', href: '/casino' }
        ],
        'LIVE CASINO': [
            { text: 'Roulette', href: '/live-casino' },
            { text: 'Blackjack', href: '/live-casino' },
            { text: 'Live Casino', href: '/live-casino' },
            { text: 'Table Games', href: '/casino' },
            { text: 'Video Poker', href: '/casino' }
        ],
        'CASINO': [
            { text: 'About Us', href: '/about' },
            { text: 'Promotions', href: '/promotions' },
            { text: 'Tournaments', href: '/tournaments' },
            { text: 'Affiliate Program', href: '/affiliate' },
            { text: 'Loyalty Program', href: '/vip' },
            { text: 'Refer a friend', href: '/vip' },
            { text: 'Blog', href: '/blog' },
            { text: 'Bonus Shop', href: '/promotions' },
            { text: 'Agent Verification', href: '/support' },
            { text: 'Jungle Jackpot', href: '/casino' }
        ],
        'LEGAL': [
            { text: 'Privacy Policy', href: '/privacy-policy' },
            { text: 'Terms & Conditions', href: '/terms' },
            { text: 'Bonus Terms', href: '/promotions' },
            { text: 'Responsible Gambling', href: '/responsible-gambling' }
        ],
        'SUPPORT': [
            { text: 'Live Support', href: '/support' }
        ]
    };

    const awards = [
        { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fbest-new-casino-1-117.svg", alt: "Best New Casino 2023" },
        { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fbest-casino-1-119.svg", alt: "Best Casino 2024" },
        { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fplayers-choice-1-121.svg", alt: "Player's Choice 2025" }
    ];

    const responsibleGamingLogos = [
        { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/footer-badge-112.svg", alt: "18+", width: 28, height: 28 },
        { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/gamcare-113.svg", alt: "GameCare", width: 106, height: 28 },
        { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/responsiblegambling-114.svg", alt: "Responsible Gaming", width: 104, height: 28 },
        { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/gamblersanonymous-115.svg", alt: "Gamblers Anonymous", width: 92, height: 28 },
        { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/icons/GCBSeal-1.png", alt: "GCB Seal", width: 42, height: 42 },
    ];

    return (
        <footer className="bg-[#0a0e14] py-16 text-sm font-sans">
            <div className="mx-auto max-w-[1440px] px-8 lg:px-12">
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-[1.5fr_repeat(5,_1fr)] gap-y-10 gap-x-8">
                    <div className="col-span-2 flex flex-col gap-y-6 lg:col-span-1">
                        <a href="/" className="w-fit">
                            <Image src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Flogo-dark-v2-3.svg" alt="Xprimebet Logo" width={110} height={36} />
                        </a>
                        <p className="text-[#a0a0a0]">© 2025 Xprimebet. All rights reserved.</p>
                        <div className="flex space-x-4 text-[#a0a0a0]">
                            {socialLinks.map((link, index) => (
                                <a key={index} href={link.href} aria-label={link.label} target="_blank" rel="noopener noreferrer" className="hover:text-[#5cb85c] transition-colors">
                                    {link.icon}
                                </a>
                            ))}
                        </div>
                        <ThemeToggle />
                    </div>

                    {Object.entries(linkColumns).map(([title, links]) => (
                        <div key={title}>
                            <h3 className="font-semibold text-white uppercase tracking-wider mb-4">{title}</h3>
                            <ul className="space-y-2">
                                {links.map((link) => (
                                    <FooterLink key={link.text} href={link.href}>{link.text}</FooterLink>
                                ))}
                            </ul>
                        </div>
                    ))}
                </div>

                <div className="my-12 border-t border-gray-800" />
                
                <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-y-8">
                    <p className="text-[#a0a0a0] max-w-2xl leading-relaxed">
                        Xprimebet.io is owned and operated by Nonce Gaming B.V. a company that is incorporated under the laws of Curacao with company registration number 161858, having its registered address at Scharlooweg 39, Willemstad, Curaçao. Xprimebet.io is licensed and holds a valid Certificate of Operation (OGL/2024/210/0198).
                    </p>
                    <div className="flex items-center justify-start lg:justify-end gap-x-4 flex-wrap gap-y-4 shrink-0">
                        {responsibleGamingLogos.map((logo, index) => (
                            <Image key={index} src={logo.src} alt={logo.alt} width={logo.width} height={logo.height} className="opacity-70" />
                        ))}
                    </div>
                </div>

                <div className="my-12 border-t border-gray-800" />

                <div className="flex flex-col lg:flex-row items-start gap-y-6">
                    <h3 className="font-semibold text-white uppercase tracking-wider shrink-0 mr-8">Awards</h3>
                    <div className="flex items-center flex-wrap gap-4">
                        {awards.map((award, index) => (
                            <a href="#" key={index}>
                                <Image src={award.src} alt={award.alt} width={120} height={72} className="opacity-80 hover:opacity-100 transition-opacity" />
                            </a>
                        ))}
                        <a href="#">
                           <ExcellentSupportBadge />
                        </a>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;