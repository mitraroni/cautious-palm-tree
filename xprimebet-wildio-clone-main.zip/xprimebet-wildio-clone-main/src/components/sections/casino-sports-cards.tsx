"use client";

import Image from "next/image";

const CasinoSportsCards = () => {
  return (
    <div className="my-6 grid grid-cols-1 gap-4 md:my-8 md:grid-cols-2 md:gap-6">
      {/* Casino Card */}
      <a
        href="#casino"
        className="group relative overflow-hidden rounded-2xl transition-transform hover:scale-[1.02]"
      >
        <div className="relative h-64 md:h-80">
          <Image
            src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/banner_casino-3.webp"
            alt="Casino"
            fill
            className="object-cover brightness-90 transition-all group-hover:brightness-100"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 p-6">
          <div className="mb-3 flex items-center gap-3">
            <Image
              src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/seven-40.svg"
              alt="Casino Icon"
              width={40}
              height={40}
            />
            <div>
              <h3 className="text-2xl font-bold text-white">Casino</h3>
              <span className="inline-block rounded-full bg-[#8B5CF6] px-3 py-1 text-xs font-semibold text-white">
                8k+ Games
              </span>
            </div>
          </div>
          <p className="text-sm text-gray-200 md:text-base">
            Explore our exclusive games, live casino, and thrilling slot games.
          </p>
        </div>
      </a>

      {/* Sportsbook Card */}
      <a
        href="#sportsbook"
        className="group relative overflow-hidden rounded-2xl transition-transform hover:scale-[1.02]"
      >
        <div className="relative h-64 md:h-80">
          <Image
            src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/banner_sports-4.webp"
            alt="Sportsbook"
            fill
            className="object-cover brightness-90 transition-all group-hover:brightness-100"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 p-6">
          <div className="mb-3 flex items-center gap-3">
            <Image
              src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/football-41.svg"
              alt="Sportsbook Icon"
              width={40}
              height={40}
            />
            <div>
              <h3 className="text-2xl font-bold text-white">Sportsbook</h3>
              <span className="inline-block rounded-full bg-blue-600 px-3 py-1 text-xs font-semibold text-white">
                Free Bets
              </span>
            </div>
          </div>
          <p className="text-sm text-gray-200 md:text-base">
            Bet on Football, Cricket, NFL, eSports & more than 80 other sports.
          </p>
        </div>
      </a>
    </div>
  );
};

export default CasinoSportsCards;
