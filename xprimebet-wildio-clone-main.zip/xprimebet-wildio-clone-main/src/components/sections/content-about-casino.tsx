"use client";

import { useState } from "react";
import { Check } from "lucide-react";

const ListItem = ({ children }: { children: React.ReactNode }) => (
  <li className="flex items-start">
    <Check className="h-5 w-5 text-primary flex-shrink-0 mt-1 mr-4" style={{ color: '#5cb85c' }} />
    <p className="!m-0 text-text-secondary leading-relaxed">{children}</p>
  </li>
);

const ContentAboutCasino = () => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="w-full bg-[#0f1419]">
      <div className="max-w-[1200px] mx-auto py-16 px-4 md:px-8">
        <div className="space-y-6">
          <h1 className="text-white font-bold text-center text-2xl md:text-[2.5rem] !leading-tight mb-8">
            Xprimebet: Experience the Future of Online Gaming With the Best Bitcoin & Crypto Casino
          </h1>

          <p className="text-base text-text-secondary leading-relaxed">
            Welcome to Xprimebet, your one-stop shop for premium online gaming using popular cryptocurrencies like Bitcoin (BTC), Solana (SOL), Bitcoin Cash (BCH), Ethereum (ETH), Litecoin (LTC), Binance Coin (BNB), Ripple (XRP), Tron (TRX), and Cardano (ADA). Whether you’re a crypto veteran or just getting started, we have lots of perks:
          </p>

          <ul className="list-none p-0 my-8 space-y-4">
            <ListItem>
              <a href="https://wild.io/blog/understanding-what-provably-fair-is" className="text-[#5cb85c] hover:underline font-semibold">Provably fair games</a>
              : A major highlight of Xprimebet is its extensive collection of over 9000 games, showcasing its commitment to a vast and diverse gaming experience.
            </ListItem>
            <ListItem>
              Instant deposits and withdrawals: We have rapid processing times for both deposits and withdrawals, ensuring you can start playing or cash out your winnings in less than 10 minutes.
            </ListItem>
            <ListItem>
              <a href="https://wild.io/promotions" className="text-[#5cb85c] hover:underline font-semibold">Large bonuses and promotions</a>
              : Take advantage of enticing offers, such as sign-up bonuses, free spins, and loyalty rewards to enhance your overall gaming experience.
            </ListItem>
            <ListItem>
              Privacy & Anonymity: One of the standout features of crypto casinos is the level of anonymity they offer. Transactions are recorded on a public ledger also known as the blockchain, without revealing your personal information, ensuring your privacy is maintained.
            </ListItem>
            <ListItem>
              Lower Transaction Fees: Compared to fiat payment methods, transaction fees for cryptocurrencies are generally much lower, allowing you to keep more of your winnings.
            </ListItem>
          </ul>

          <div className={`${isExpanded ? "block" : "hidden"} space-y-6 text-text-secondary`}>
            <p className="leading-relaxed">Read on to see why more players are choosing Xprimebet for their favorite crypto casino games, from classic table games to the latest slots, all powered by digital currencies.</p>

            <h2 className="text-3xl font-semibold text-white pt-4">Are Bitcoin Casinos Legit?</h2>
            <p className="leading-relaxed">Worried about online sites accepting BTC? Here’s what to check:</p>
            <ol className="list-decimal list-inside space-y-2 pl-4">
              <li>Check licensing and regulation. Reputable operators, like those licensed by the Malta Gaming Authority, the UK Gambling Commission, or holding a Curaçao Gaming License, must follow strict guidelines. This ensures the casino's operations are legitimized and provides a safe environment for players.</li>
              <li>Look for provably fair gaming. Many crypto casinos use transparent algorithms that let you verify game results on the blockchain.</li>
              <li>Read user reviews. <a href="https://www.trustpilot.com/review/wild.io" rel="noopener noreferrer nofollow" target="_blank" className="text-[#5cb85c] hover:underline">Look for feedback</a> on withdrawal speed, fairness and overall customer satisfaction.</li>
              <li>Security measures. A good site should use SSL encryption, two-factor authentication (2FA) and robust internal protocols to protect your funds and personal data.</li>
            </ol>
            <p className="leading-relaxed">By doing some research, you can find a trustworthy crypto casino that respects your privacy and provides a reliable platform for online gaming—just like Xprimebet.</p>

            <h2 className="text-3xl font-semibold text-white pt-4">Responsible Gaming in Ethereum Casinos and Beyond</h2>
            <p className="leading-relaxed">Choosing a site that prioritizes responsible gambling is key for a safe and enjoyable experience. Look for:</p>
            <ul className="list-disc list-inside space-y-2 pl-4">
              <li>Licensing & Regulation. An operator that follows regulatory requirements is more likely to have fair games and protect players.</li>
              <li>Provably Fair Games. Platforms that offer provably fair games ensure transparency and trust in the gaming experience, which is crucial for user satisfaction.</li>
              <li>Account Tools. Features like deposit limits, self-exclusion and time-outs to help you stay in control.</li>
              <li>Player Protection. Mandatory ID verification, age checks and other security measures to prevent fraud and underage play.</li>
              <li>Transparent Payouts. Reputable casinos show game payout percentages so you can make informed decisions.</li>
              <li>Support Resources. A site that cares about player well-being will link to external help organizations and offer direct support for problem gambling.</li>
            </ul>
            <p className="leading-relaxed">Xprimebet has all of these measures in place to create a safe and secure environment for everyone whether you’re playing Ethereum casino games, Cardano or any other cryptocurrency.</p>

            {/* Additional content sections can be added here following the same structure */}
            {/* For brevity, only a few sections are included in this example. */}
            
            <h2 className="text-3xl font-semibold text-white pt-4">FAQ</h2>
            <div className="space-y-4">
                <h3 className="text-xl font-semibold text-white">What cryptocurrencies do you accept?</h3>
                <p>We accept a wide range of cryptocurrencies including Bitcoin (BTC), Ethereum (ETH), Litecoin (LTC), Dogecoin (DOGE), Bitcoin Cash (BCH), Ripple (XRP), Tron (TRX), Tether (USDT), Binance Coin (BNB), USD Coin (USDC), Cardano (ADA), and Solana (SOL). So you can play in your favourite cryptocurrency.</p>
                <h3 className="text-xl font-semibold text-white">Are there bonuses for new players?</h3>
                <p>Yes, new players at Xprimebet are welcome with a large variety of bonuses. The First Deposit Bonus consists of a reload of up to 120% (up to $1,000) + 75 high-value Free Spins (at $1.00 per spin). There are also bonuses for your second and third deposits to enhance your experience with us.</p>
                <h3 className="text-xl font-semibold text-white">What types of games do you have?</h3>
                <p>We have over 9000 games including Bitcoin slots, dice games, classic table games like blackjack, roulette and baccarat, live casino games and unique games like Crash, Plinko, Bingo and Keno. Our games are for all types of players so everyone has a great time.</p>
            </div>
          </div>

          <div className="text-center">
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="text-[#5cb85c] font-semibold hover:underline mt-4 text-lg"
            >
              {isExpanded ? "Read less" : "Read more"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContentAboutCasino;