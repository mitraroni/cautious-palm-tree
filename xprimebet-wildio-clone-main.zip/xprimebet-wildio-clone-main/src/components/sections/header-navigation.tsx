"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { Menu, Search, User } from "lucide-react";

const NavLink = ({ href, iconSrc, text, active = false }: { href: string; iconSrc: string; text: string; active?: boolean }) => (
  <a
    href={href}
    className={`group flex items-center space-x-2 whitespace-nowrap rounded-md px-5 py-2 text-[15px] font-semibold transition-all duration-200 focus:outline-none ${
      active
        ? "bg-[#1a2332] text-white"
        : "text-gray-400 hover:bg-[#1a2332] hover:text-white"
    }`}
  >
    <Image src={iconSrc} alt={`${text} tab`} width={18} height={18} />
    <span>{text}</span>
  </a>
);

const HeaderNavigation = () => {
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth >= 768) {
                setIsMobileMenuOpen(false);
            }
        };
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-[100] w-full bg-[#1a2332] font-['Proxima_Nova'] shadow-[0_2px_8px_rgba(0,0,0,0.15)]">
        <div className="flex h-14 flex-row items-center px-3 lg:h-16">
          <div className="flex items-center space-x-3 md:space-x-4">
            <button className="hidden h-9 w-9 items-center justify-center rounded-md p-0 text-gray-400 hover:bg-white/10 md:flex">
                <Menu className="h-7 w-7" />
            </button>
            <button className="flex h-9 w-9 items-center justify-center rounded-md p-0 text-gray-400 hover:bg-white/10 md:hidden" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
                <Menu className="h-7 w-7" />
            </button>
            <a href="/" className="flex items-center">
                <Image
                    src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/document-uploads/IMG_20251006_113700_220-1759733945934.jpg"
                    alt="Xprimebet Logo"
                    width={140}
                    height={48}
                    className="h-9 w-auto md:h-10"
                    priority
                />
            </a>
          </div>

          <div className="ml-4 hidden flex-row items-center md:flex">
              <nav aria-label="Tabs" className="inline-flex space-x-1 rounded-lg bg-[#0D2433] p-1">
                <NavLink href="#" iconSrc="https://www.wild.io/cdn-cgi/image/width=48,quality=75,format=auto//assets/category-icons/slot-games.svg" text="Casino" active />
                <NavLink href="#" iconSrc="https://www.wild.io/cdn-cgi/image/width=48,quality=75,format=auto//assets/category-icons/sports.svg" text="Sports" />
              </nav>
          </div>
          
          <div className="hidden flex-1 items-center lg:flex lg:pl-2">
            <div className="relative w-full max-w-md">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4">
                    <Search className="h-5 w-5 stroke-gray-500" />
                </div>
                <input
                    id="navbar-search-trigger"
                    className="h-10 w-full cursor-pointer rounded-lg border-0 bg-[#0D2433] py-2.5 pl-12 pr-10 text-sm text-white placeholder-gray-500 ring-1 ring-inset ring-white/10 transition-all duration-200 ease-in-out focus:ring-2 focus:ring-inset focus:ring-[#5cb85c] hover:placeholder:text-gray-400"
                    placeholder="Search for Games & Providers"
                    type="search"
                />
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3">
                    <kbd className="inline-flex items-center rounded border border-gray-600 px-2 font-sans text-xs font-medium text-gray-400">
                        CTRL+K
                    </kbd>
                </div>
              </div>
          </div>
          
          <div className="ml-auto flex items-center gap-2">
              <button className="flex h-10 w-10 items-center justify-center rounded-lg p-0 text-sm text-gray-400 hover:bg-white/10 lg:hidden">
                <Search className="h-5 w-5 stroke-current" />
              </button>
              <a href="#" className="hidden md:block">
                <button className="relative z-0 flex h-10 items-center justify-center overflow-hidden rounded-lg bg-transparent px-6 text-sm font-semibold text-white transition-all hover:bg-white/10">
                  Log In
                </button>
              </a>
              <a href="#">
                <button className="relative z-0 flex h-10 items-center justify-center overflow-hidden whitespace-nowrap rounded-lg bg-blue-600 px-6 text-sm font-semibold text-white transition-all hover:bg-blue-700">
                  Sign Up
                </button>
              </a>
              <div className="hidden rounded-xl bg-[#0D2433] p-1 md:block">
                <button className="relative z-0 flex h-8 w-8 items-center justify-center overflow-hidden rounded-lg bg-transparent p-0 text-sm text-white transition-all hover:bg-white/10">
                  <User className="h-5 w-5" />
                </button>
              </div>
          </div>

        </div>
      </header>
      
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-[99] pt-14 md:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsMobileMenuOpen(false)}></div>
          <div className="relative h-full w-4/5 max-w-xs bg-[#1a2332] p-4">
              <nav className="flex flex-col space-y-4">
                 <NavLink href="#" iconSrc="https://www.wild.io/cdn-cgi/image/width=48,quality=75,format=auto//assets/category-icons/slot-games.svg" text="Casino" active />
                 <NavLink href="#" iconSrc="https://www.wild.io/cdn-cgi/image/width=48,quality=75,format=auto//assets/category-icons/sports.svg" text="Sports" />
                 <div className="border-t border-white/10 pt-4">
                  <a href="#" className="block w-full rounded-lg bg-transparent px-4 py-2.5 text-center font-semibold text-white ring-1 ring-inset ring-white/20">
                      Log In
                  </a>
                 </div>
              </nav>
          </div>
        </div>
      )}
    </>
  );
};

export default HeaderNavigation;
