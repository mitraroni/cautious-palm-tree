"use client";

import Image from "next/image";
import { Star } from "lucide-react";

const HeroWelcomeSection = () => {
  return (
    /*<section className="relative min-h-[400px] overflow-hidden bg-gradient-to-br from-[#0a4a5c] via-[#1a1f3a] to-[#0a4a5c] px-4 py-12 md:min-h-[500px] md:py-16 lg:py-20">*/<section className="relative min-h-[400px] overflow-hidden bg-gradient-to-br from-blue-700 via-blue-900 to-blue-700 px-4 py-12 md:min-h-[500px] md:py-16 lg:py-20">

      {/* Background Image */}
      <div className="absolute inset-0 opacity-20">
        <Image
          src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/hero-background-desktop-2.webp"
          alt="Hero Background"
          fill
          className="object-cover"
          priority
        />
      </div>

      <div className="container relative mx-auto flex flex-col items-center gap-8 lg:flex-row lg:items-center lg:justify-between">
        {/* Left Content */}
        <div className="z-10 w-full text-center lg:w-1/2 lg:text-left">
          <p className="mb-2 text-sm font-medium text-gray-400 md:text-base">Welcome Offer</p>
          <h1 className="mb-2 text-4xl font-bold leading-tight text-[#FFB800] md:text-5xl lg:text-6xl">
            120% up to $5,000
          </h1>
          <p className="mb-6 text-xl font-semibold text-white md:mb-8 md:text-2xl">
            and 75 Free Spins
          </p>
          
          <div className="flex flex-col items-center gap-4 lg:items-start">
            <a href="#signup">
              <button className="group relative overflow-hidden rounded-xl bg-gradient-to-b from-[#3B82F6] to-[#1E40AF] px-10 py-4 text-lg font-semibold text-white shadow-[0_0_24px_rgba(59,130,246,0.4)] transition-all hover:scale-105 hover:shadow-[0_0_32px_rgba(59,130,246,0.6)] md:px-12 md:py-5 md:text-xl">
                Sign Up Now
                <span className="mt-1 block text-xs font-normal opacity-90">
                  Only Takes 30 seconds
                </span>
              </button>
            </a>

            {/* Trustpilot Rating */}
            <div className="flex items-center gap-3 rounded-lg bg-white/10 px-4 py-2 backdrop-blur-sm">
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star key={star} className="h-4 w-4 fill-[#6FCF26] text-[#6FCF26]" />
                ))}
              </div>
              <div className="text-left">
                <p className="text-sm font-semibold text-white">Great</p>
                <p className="text-xs text-gray-300">550+ User Reviews</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Content - Mascots */}
        <div className="relative z-10 w-full lg:w-1/2">
          <div className="relative mx-auto aspect-square w-full max-w-[400px] md:max-w-[500px]">
            {/* Placeholder for mascot images - you can add actual mascot images here */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="mb-4 text-6xl md:text-8xl">🎰</div>
                <div className="flex justify-center gap-4 text-4xl md:text-5xl">
                  <span>🎲</span>
                  <span>🃏</span>
                  <span>💎</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroWelcomeSection;
