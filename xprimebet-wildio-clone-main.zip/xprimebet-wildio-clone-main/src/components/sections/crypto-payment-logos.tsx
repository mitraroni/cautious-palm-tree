import Image from "next/image";
import React from "react";

const cryptoLogos = [
  {
    name: "Bitcoin",
    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/btc-98.svg",
  },
  {
    name: "Bitcoin Cash",
    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/bch-99.svg",
  },
  {
    name: "Ethereum",
    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/eth-100.svg",
  },
  {
    name: "Litecoin",
    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/ltc-101.svg",
  },
  {
    name: "Dogecoin",
    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/dog-102.svg",
  },
  {
    name: "Tether",
    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/usdt-103.svg",
  },
  {
    name: "Tron",
    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/trx-104.svg",
  },
  {
    name: "Cardano",
    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/ada-105.svg",
  },
  {
    name: "Binance",
    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/bnb-106.svg",
  },
  {
    name: "Ripple",
    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/xrp-107.svg",
  },
  {
    name: "Solana",
    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sol-108.svg",
  },
  {
    name: "USD Coin",
    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/usdc-110.svg",
  },
];

const CryptoPaymentLogos = () => {
  return (
    <section className="bg-gradient-to-r from-blue-700 via-blue-900 to-blue-700">
      <div className="container px-3 py-10 md:py-14">
        <div className="flex flex-wrap items-center justify-center gap-x-12 gap-y-4 md:gap-x-20">
          {cryptoLogos.map((logo) => (
            <Image
              key={logo.name}
              src={logo.src}
              alt={logo.name}
              width={80}
              height={32}
              className="h-auto w-20 filter grayscale transition-all duration-300 hover:filter-none"
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default CryptoPaymentLogos;
