"use client";

import { useEffect, useState } from "react";
import Image from "next/image";

const DailyRakebackBanner = () => {
  const [timeLeft, setTimeLeft] = useState({
    days: 5,
    hours: 12,
    minutes: 30,
    seconds: 45,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else if (prev.days > 0) {
          return { days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative my-8 overflow-hidden rounded-2xl bg-gradient-to-r from-purple-900 via-purple-800 to-blue-900 md:my-12">
      {/* Background Image */}
      <div className="absolute inset-0 opacity-30">
        <Image
          src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/rakeback-banner-36.png"
          alt="Rakeback Background"
          fill
          className="object-cover"
        />
      </div>

      <div className="relative flex flex-col items-center gap-6 p-6 md:flex-row md:justify-between md:p-8">
        {/* Left Section */}
        <div className="text-center md:text-left">
          <p className="mb-1 text-sm font-medium text-[#6FCF26] md:text-base">
            Earn rewards
          </p>
          <p className="text-base font-medium text-white md:text-lg">
            from every single bet you place.
          </p>
        </div>

        {/* Center Section */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-white md:text-4xl">
            Daily Rakeback
          </h2>
        </div>

        {/* Right Section - Timer */}
        <div className="flex flex-col items-center gap-3 md:flex-row md:gap-4">
          <div className="text-center">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-gray-300">
              Hurry Up
            </p>
            <div className="flex gap-2">
              <div className="flex flex-col items-center rounded-lg bg-[#0D2433] px-3 py-2">
                <span className="text-xl font-bold text-[#6FCF26] md:text-2xl">
                  {timeLeft.days}
                </span>
                <span className="text-[10px] uppercase text-gray-400">Days</span>
              </div>
              <div className="flex flex-col items-center rounded-lg bg-[#0D2433] px-3 py-2">
                <span className="text-xl font-bold text-[#6FCF26] md:text-2xl">
                  {String(timeLeft.hours).padStart(2, "0")}
                </span>
                <span className="text-[10px] uppercase text-gray-400">Hrs</span>
              </div>
              <div className="flex flex-col items-center rounded-lg bg-[#0D2433] px-3 py-2">
                <span className="text-xl font-bold text-[#6FCF26] md:text-2xl">
                  {String(timeLeft.minutes).padStart(2, "0")}
                </span>
                <span className="text-[10px] uppercase text-gray-400">Mins</span>
              </div>
              <div className="flex flex-col items-center rounded-lg bg-[#0D2433] px-3 py-2">
                <span className="text-xl font-bold text-[#6FCF26] md:text-2xl">
                  {String(timeLeft.seconds).padStart(2, "0")}
                </span>
                <span className="text-[10px] uppercase text-gray-400">Sec</span>
              </div>
            </div>
          </div>

          <a href="#claim-bonus">
            <button className="whitespace-nowrap rounded-lg bg-gradient-to-b from-blue-500 to-blue-700 px-6 py-3 font-semibold text-white shadow-[0_0_20px_rgba(59,130,246,0.3)] transition-all hover:scale-105 hover:shadow-[0_0_28px_rgba(59,130,246,0.5)] md:px-8">
              Claim Bonus
            </button>
          </a>
        </div>
      </div>
    </div>
  );
};

export default DailyRakebackBanner;
