import Image from 'next/image';
import Link from 'next/link';

const sportsData = [
  { name: 'Football', href: '/sports/soccer', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_football-51.svg' },
  { name: 'Basketball', href: '/sports/basketball', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_basketball-52.svg' },
  { name: 'Tennis', href: '/sports/tennis', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_tennis-53.svg' },
  { name: 'American Football', href: '/sports/american-football', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_american_football-54.svg' },
  { name: 'Counter Strike', href: '/sports/cs2', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_counter_strike-55.svg' },
  { name: 'e-Football', href: '/sports/cybersport', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_e_football-56.svg' },
  { name: 'Ice Hockey', href: '/sports/ice-hockey', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_ice_hockey-57.svg' },
  { name: 'Cricket', href: '/sports/cricket', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_cricket-58.svg' },
  { name: 'Dota', href: '/sports/dota2', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_dota-59.svg' },
  { name: 'LOL', href: '/sports/lol', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_league_of_legends-60.svg' },
  { name: 'Boxing', href: '/sports/boxing', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_boxing-61.svg' },
  { name: 'MMA', href: '/sports/mma', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_mma-62.svg' },
  { name: 'Baseball', href: '/sports/baseball', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_baseball-63.svg' },
  { name: 'Valorant', href: '/sports/valorant', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_valorant-64.svg' },
  { name: 'Volleyball', href: '/sports/volleyball', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_volleyball-65.svg' },
  { name: 'Table Tennis', href: '/sports/table-tennis', icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_table_tennis-66.svg' },
];

const SportsCategoriesGrid = () => {
  return (
    <section className="mt-8 lg:mt-16 bg-gradient-to-r from-blue-700 via-blue-800 to-blue-900" aria-labelledby="sports-heading">
      <div className="mb-4 flex items-center justify-between">
        <Link href="/sports" className="flex items-center space-x-2 group">
          <Image
            src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sports-category-50.svg"
            alt="Sports icon"
            width={28}
            height={28}
            unoptimized
          />
          <h3 id="sports-heading" className="text-lg font-bold text-text-primary lg:text-xl transition-colors group-hover:text-primary">
            Sports
          </h3>
        </Link>
        <Link href="/sports" className="rounded-md px-2 py-0.5 text-xs text-text-secondary hover:bg-secondary transition-colors">
          View all
          <span className="ml-1 rounded-sm bg-card px-2 py-1 text-[10px] font-bold text-text-primary">
            16
          </span>
        </Link>
      </div>
      <div className="grid grid-cols-3 gap-2 md:grid-cols-4 md:gap-4 lg:grid-cols-8">
        {sportsData.map((sport) => (
          <Link href={sport.href} key={sport.name} className="group">
            <div className="flex h-full flex-col justify-center rounded-lg bg-[#1a1f2e] p-3 text-center transition-colors ease-in-out hover:bg-[#202638] lg:gap-2 lg:p-6">
              <Image
                src={sport.icon}
                alt={`Sports ${sport.name}`}
                width={64}
                height={64}
                unoptimized
                className="mx-auto block h-12 w-12 transform-gpu transition-transform duration-200 ease-in-out group-hover:scale-110 lg:h-16 lg:w-16"
              />
              <span className="mt-2 text-[13px] text-text-primary">{sport.name}</span>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
};

export default SportsCategoriesGrid;
