"use client";

import React, { useRef, useState, useEffect } from "react";
import Link from 'next/link';
import Image from 'next/image';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface Provider {
  name: string;
  logo: string | null;
  games: number;
  href: string;
}

const providersData: Provider[] = [
  { name: 'Endorphina', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/endorphina-67.svg', games: 197, href: '/providers/endorphina' },
  { name: 'Originals', logo: null, games: 14, href: '/providers/originals' },
  { name: 'BGAMING', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/bgaming-68.svg', games: 207, href: '/providers/bgaming' },
  { name: 'Platipus', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/platipus-69.svg', games: 162, href: '/providers/platipus' },
  { name: 'BELATRA', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/belatra-70.svg', games: 108, href: '/providers/belatra' },
  { name: 'popiplay', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/popiplay-71.svg', games: 67, href: '/providers/popiplay' },
  { name: 'Onlyplay', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/onlyplay-72.svg', games: 123, href: '/providers/onlyplay' },
  { name: 'BSG', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/bsg-73.svg', games: 194, href: '/providers/bsg' },
  { name: 'Evolution', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/evolution-74.svg', games: 1, href: '/providers/evolution' },
  { name: 'Booming', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/booming-75.svg', games: 205, href: '/providers/booming' },
  { name: 'Gamebeat', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/gamebeat-76.svg', games: 51, href: '/providers/gamebeat' },
  { name: 'Mascot', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/mascot-77.svg', games: 123, href: '/providers/mascot' },
  { name: 'Yggdrasil', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/yggdrasil-78.svg', games: 347, href: '/providers/yggdrasil' },
  { name: 'AvatarUX', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/avatarux-79.svg', games: 65, href: '/providers/avatarux' },
  { name: 'GameArt', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/gameart-80.svg', games: 151, href: '/providers/gameart' },
  { name: 'KAGaming', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/kagaming-81.svg', games: 889, href: '/providers/kagaming' },
  { name: '1spin4win', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/1spin4win-82.svg', games: 174, href: '/providers/1spin4win' },
  { name: 'Nucleus', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/nucleus-83.svg', games: 154, href: '/providers/nucleus' },
  { name: 'Zillion', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/zillion-84.svg', games: 60, href: '/providers/zillion' },
  { name: 'Spribe', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/spribe-85.svg', games: 1, href: '/providers/spribe' },
  { name: 'Apparat', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/apparat-86.svg', games: 57, href: '/providers/apparat' },
  { name: 'Mancala', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/mancala-87.svg', games: 86, href: '/providers/mancala' },
  { name: 'Clawbuster', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/clawbuster-88.svg', games: 32, href: '/providers/clawbuster' },
  { name: 'Platipuslive', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/platipuslive-89.svg', games: 4, href: '/providers/platipuslive' },
  { name: 'TaDaGaming', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/tadagaming-90.svg', games: 196, href: '/providers/tadagaming' },
  { name: 'Beterlive', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/beterlive-91.svg', games: 51, href: '/providers/beterlive' },
  { name: 'FelixGaming', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/felixgaming-92.svg', games: 59, href: '/providers/felixgaming' },
  { name: 'PragmaticPlay', logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/pragmaticplay-93.svg', games: 510, href: '/providers/pragmaticplay' },
];

function useInterval(callback: () => void, delay: number | null) {
  const savedCallback = useRef<() => void>();

  useEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  useEffect(() => {
    function tick() {
      if (savedCallback.current) {
        savedCallback.current();
      }
    }
    if (delay !== null) {
      let id = setInterval(tick, delay);
      return () => clearInterval(id);
    }
  }, [delay]);
}

const GameProvidersCarousel = () => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  const scrollAmount = 200 + 16; 

  useInterval(() => {
    if (scrollContainerRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
      if (scrollLeft + clientWidth >= scrollWidth - 1) {
        scrollContainerRef.current.scrollTo({ left: 0, behavior: 'smooth' });
      } else {
        scrollContainerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
      }
    }
  }, isHovered ? null : 3000);

  const handleScroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section className="py-8 md:py-16 bg-gradient-to-r from-blue-700 via-blue-800 to-blue-900 text-white">
      <div className="container">
        <header className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Image
              src="https://www.wild.io/cdn-cgi/image/width=3840,quality=75,format=auto//assets/providers-page.svg"
              alt="Game Providers Icon"
              width={32}
              height={32}
            />
            <h2 className="text-xl font-bold text-white md:text-2xl">Game Providers</h2>
          </div>
          <Link href="/providers" className="flex items-center gap-2 text-sm font-semibold text-primary transition-colors hover:brightness-110">
            View all
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-secondary text-xs font-bold text-primary">
              28
            </span>
          </Link>
        </header>

        <div
          className="relative"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <div
            ref={scrollContainerRef}
            className="flex gap-4 overflow-x-auto pb-4 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
          >
            {providersData.map((provider) => (
              <Link key={provider.name} href={provider.href} className="group block flex-shrink-0">
                <div className="flex h-[120px] w-[200px] flex-col items-center justify-center gap-2 rounded-xl bg-[#1a1f2e] p-4 text-center transition-all duration-300 ease-in-out group-hover:scale-105 group-hover:shadow-[0_0_20px_rgba(111,207,38,0.3)]">
                  <div className="flex h-10 flex-grow items-center justify-center">
                    {provider.logo ? (
                      <div className="relative h-10 w-36">
                        <Image
                          src={provider.logo}
                          alt={`${provider.name} logo`}
                          fill
                          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                          style={{ objectFit: 'contain' }}
                          className="filter invert"
                        />
                      </div>
                    ) : (
                      <span className="text-3xl font-extrabold uppercase text-white">{provider.name}</span>
                    )}
                  </div>
                  <span className="text-sm text-text-secondary">{provider.games} Games</span>
                </div>
              </Link>
            ))}
          </div>

          <button
              onClick={() => handleScroll('left')}
              className={`absolute left-0 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2 grid h-10 w-10 place-items-center rounded-full bg-slate-800/80 text-white transition-opacity hover:bg-slate-700/90 disabled:opacity-0 ${isHovered ? 'opacity-100' : 'opacity-0'}`}
              aria-label="Scroll left"
            >
              <ChevronLeft size={24} />
            </button>
            <button
              onClick={() => handleScroll('right')}
              className={`absolute right-0 top-1/2 z-10 translate-x-1/2 -translate-y-1/2 grid h-10 w-10 place-items-center rounded-full bg-slate-800/80 text-white transition-opacity hover:bg-slate-700/90 disabled:opacity-0 ${isHovered ? 'opacity-100' : 'opacity-0'}`}
              aria-label="Scroll right"
            >
              <ChevronRight size={24} />
          </button>
        </div>
      </div>
    </section>
  );
};

export default GameProvidersCarousel;
