"use client";

import { useState } from "react";
import { MessageSquare, X } from "lucide-react";

const LiveChatWidget = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed bottom-4 right-4 z-[9999] lg:bottom-8 lg:right-8">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`
          group flex h-16 w-16 items-center justify-center rounded-full bg-[#6FCF26] text-white
          shadow-[0_0_20px_rgba(111,207,38,0.3)]
          transition-all duration-300 ease-in-out
          hover:scale-110 hover:shadow-[0_0_30px_rgba(111,207,38,0.6)]
          focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2
          ${!isOpen ? "animate-pulse" : ""}
        `}
        aria-label="Toggle live chat"
      >
        <div className="relative flex h-full w-full items-center justify-center">
          <span
            className={`
              absolute inset-0 flex items-center justify-center
              transition-opacity duration-300
              ${isOpen ? "opacity-0" : "opacity-100"}
            `}
            aria-hidden={isOpen}
          >
            <MessageSquare size={32} className="stroke-current" />
          </span>
          <span
            className={`
              absolute inset-0 flex items-center justify-center
              transition-opacity duration-300
              ${isOpen ? "opacity-100" : "opacity-0"}
            `}
            aria-hidden={!isOpen}
          >
            <X size={32} className="stroke-current" />
          </span>
        </div>
      </button>
    </div>
  );
};

export default LiveChatWidget;