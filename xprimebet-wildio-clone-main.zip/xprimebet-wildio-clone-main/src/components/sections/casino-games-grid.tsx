"use client";

import React, { useState, useEffect, useRef } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Play, ChevronRight } from 'lucide-react';

const slugify = (text: string) =>
  text
    .toLowerCase()
    .replace(' - ', '-')
    .replace(/\s+/g, '-')
    .replace(/[^\w-]+/g, '');

const gameData = [
  { name: 'Sweet Rush Bonanza', provider: 'Pragmatic Play', image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fpragmaticexternal%2FSweetRushBonanza-21.png' },
  { name: 'Clucking Hell', provider: 'BGAMING', image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fsoftswiss%2FCluckingHell-22.png' },
  { name: 'Wild Tiger 2', provider: 'BGAMING', image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fsoftswiss%2FWildTiger2-23.png' },
  { name: 'Chaos Crew 3', provider: 'Hacksaw Gaming', image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fhacksaw%2FChaosCrew394-24.png' },
  { name: 'Disco Farm', provider: 'Betsoft', image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fbsg%2FDiscoFarmHoldAndWin-25.png' },
  { name: '5 Lions Megaways 2', provider: 'Pragmatic Play', image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fwild.io%2Fthumbnail%2Fpragmaticexternal%2F5LionsMegaways2-26.webp' },
  { name: 'Coin Dazzle', provider: 'Platipus', image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fwild.io%2Fthumbnail%2Fplatipus%2Fcoindazzle-27.webp' },
  { name: 'Overheat', provider: 'Mascot', image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fwild.io%2Fthumbnail%2Fmascot%2Foverheat-28.webp' },
  { name: 'Bonanza Trillion', provider: 'BGAMING', image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fsoftswiss%2FBonanzaTrillion-29.png' },
  { name: 'Waves of Poseidon', provider: 'Pragmatic Play', image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fpragmaticexternal%2FWavesOfPoseidon-30.png' },
  { name: 'Freak Out', provider: 'Gamebeat', image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fwild.io%2Fthumbnail%2Fgamebeat%2FFreakOut-31.webp' },
  { name: 'Thunder Crown', provider: 'Endorphina', image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fendorphina%2Fendorphina2_ThunderCrown-32.png' },
  { name: 'Genie\'s Gem Bonanza', provider: 'Pragmatic Play', image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fpragmaticexternal%2FGeniesGemBonanza-33.png' },
  { name: 'Oktobearfest', provider: 'Popiplay', image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fpopiplay%2FOktobearfest-34.png' },
  { name: 'Fortune Chests', provider: 'Endorphina', image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fendorphina%2Fendorphina2_FortuneChests-35.png' },
];

const games = gameData.map((game) => ({
  ...game,
  href: `/games/${slugify(game.name)}`,
}));

type Game = typeof games[0];

const GameCard = ({ game }: { game: Game }) => {
  const ref = useRef<HTMLAnchorElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
  }, []);
  
  return (
    <Link
      ref={ref}
      href={game.href}
      className={`group relative block overflow-hidden rounded-lg outline-none transition-all duration-500 ease-out focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
      }`}
    >
      <div className="aspect-[3/4] w-full">
        <Image
          src={game.image}
          alt={`Game thumbnail for ${game.name}`}
          fill
          sizes="(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 20vw"
          className="object-cover transition-transform duration-300 group-hover:scale-105"
          loading="lazy"
        />
      </div>
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 p-4 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        <div className="relative z-10 flex h-14 w-14 transform items-center justify-center rounded-full bg-primary text-primary-foreground scale-75 transition-transform duration-300 group-hover:scale-100">
          <Play className="ml-1 h-8 w-8 fill-current" />
        </div>
        <div className="absolute bottom-4 left-4 right-4 z-10 text-center">
          <h4 className="truncate font-semibold uppercase text-white text-base">{game.name}</h4>
          <p className="text-xs uppercase text-text-secondary">{game.provider}</p>
        </div>
      </div>
    </Link>
  );
}

const CasinoGamesGrid = () => {
  return (
    <section className="py-8 md:py-16 bg-gradient-to-r from-blue-700 via-blue-900 to-blue-700">
      <div className="container">
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/games" className="hidden md:flex">
              <Image
                src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/providers-page-49.svg"
                alt="Casino icon"
                width={26}
                height={26}
              />
            </Link>
            <Link href="/games">
              <h3 className="text-2xl font-bold text-white lg:text-3xl">Casino</h3>
            </Link>
          </div>
          <Link href="/games" className="group flex items-center gap-2 text-text-secondary transition-colors hover:text-primary">
            <span className="text-right text-sm font-semibold leading-tight">
              View all
              <br />
              3778
            </span>
            <ChevronRight className="h-4 w-4 shrink-0" />
          </Link>
        </div>

        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-5">
          {games.map((game, index) => (
            <GameCard key={index} game={game} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default CasinoGamesGrid;
