"use client";

import Image from "next/image";
import { Home, Gamepad2, Trophy, Gift, User } from "lucide-react";

const MobileBottomNavigation = () => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-[90] border-t border-white/10 bg-[#1a2332] shadow-[0_-2px_8px_rgba(0,0,0,0.15)] md:hidden">
      <div className="flex items-center justify-around px-2 py-2">
        {/* Home */}
        <a
          href="/"
          className="flex flex-col items-center gap-1 rounded-lg px-4 py-2 transition-colors hover:bg-white/10"
        >
          <Home className="h-5 w-5 text-[#6FCF26]" />
          <span className="text-[10px] font-medium text-white">Home</span>
        </a>

        {/* Casino */}
        <a
          href="#casino"
          className="flex flex-col items-center gap-1 rounded-lg px-4 py-2 transition-colors hover:bg-white/10"
        >
          <Gamepad2 className="h-5 w-5 text-gray-400" />
          <span className="text-[10px] font-medium text-gray-400">Casino</span>
        </a>

        {/* Sports */}
        <a
          href="#sports"
          className="flex flex-col items-center gap-1 rounded-lg px-4 py-2 transition-colors hover:bg-white/10"
        >
          <Trophy className="h-5 w-5 text-gray-400" />
          <span className="text-[10px] font-medium text-gray-400">Sports</span>
        </a>

        {/* Promotions */}
        <a
          href="#promotions"
          className="flex flex-col items-center gap-1 rounded-lg px-4 py-2 transition-colors hover:bg-white/10"
        >
          <Gift className="h-5 w-5 text-gray-400" />
          <span className="text-[10px] font-medium text-gray-400">Promos</span>
        </a>

        {/* Account */}
        <a
          href="#account"
          className="flex flex-col items-center gap-1 rounded-lg px-4 py-2 transition-colors hover:bg-white/10"
        >
          <User className="h-5 w-5 text-gray-400" />
          <span className="text-[10px] font-medium text-gray-400">Account</span>
        </a>
      </div>
    </nav>
  );
};

export default MobileBottomNavigation;