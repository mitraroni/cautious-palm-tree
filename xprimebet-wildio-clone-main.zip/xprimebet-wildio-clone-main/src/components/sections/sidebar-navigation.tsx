"use client";

import Image from "next/image";

const sidebarItems = [
  { icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/home-5.svg", label: "Home", href: "/", active: true },
  { icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/slot-games-6.svg", label: "Slots", href: "#slots" },
  { icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Flive_casino-17.svg", label: "Live Casino", href: "#live-casino" },
  { icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Ftable_games-18.svg", label: "Table Games", href: "#table-games" },
  { icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sports-7.svg", label: "Sports", href: "#sports" },
  { icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fpromotions-21.svg", label: "Promotions", href: "#promotions" },
  { icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Ftournaments-22.svg", label: "Tournaments", href: "#tournaments" },
  { icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2FVIP_club-23.svg", label: "VIP Club", href: "#vip" },
  { icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fwheel_of_fortune-8.svg", label: "Wheel", href: "#wheel" },
  { icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fwild_lottery-10.svg", label: "Lottery", href: "#lottery" },
  { icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fbonus_shop-11.svg", label: "Bonus Shop", href: "#bonus" },
  { icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Flive_support-24.svg", label: "Support", href: "#support" },
];

const SidebarNavigation = () => {
  return (
    <aside className="fixed left-0 top-14 z-[80] hidden h-[calc(100vh-3.5rem)] w-16 flex-col items-center gap-2 overflow-y-auto bg-[#0f1419] py-4 shadow-[2px_0_8px_rgba(0,0,0,0.15)] lg:top-16 lg:flex lg:h-[calc(100vh-4rem)]">
      {sidebarItems.map((item, index) => (
        <a
          key={index}
          href={item.href}
          className={`group relative flex h-12 w-12 items-center justify-center rounded-full transition-all ${
            item.active
              ? "bg-[#6FCF26]/20 ring-2 ring-[#6FCF26]"
              : "bg-transparent hover:bg-white/10"
          }`}
          title={item.label}
        >
          <Image
            src={item.icon}
            alt={item.label}
            width={24}
            height={24}
            className={`transition-all ${
              item.active ? "brightness-125" : "opacity-60 group-hover:opacity-100"
            }`}
          />
          
          {/* Tooltip */}
          <span className="pointer-events-none absolute left-14 whitespace-nowrap rounded-md bg-[#1a2332] px-3 py-1.5 text-xs font-medium text-white opacity-0 shadow-lg transition-opacity group-hover:opacity-100">
            {item.label}
          </span>
        </a>
      ))}
    </aside>
  );
};

export default SidebarNavigation;