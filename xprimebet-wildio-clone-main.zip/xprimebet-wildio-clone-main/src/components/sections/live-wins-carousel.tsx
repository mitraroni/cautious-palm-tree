"use client";

import React, { useEffect, useRef } from "react";
import Image from "next/image";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface LiveWin {
  gameName: string;
  winAmount: string;
  currency: 'BTC' | 'USDT' | 'XRP' | 'SOL' | 'LTC' | 'DOGE' | 'TRX';
  gameImage: string;
  gameUrl: string;
}

const cryptoIcons = {
  BTC: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/BTC-43.svg',
  USDT: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/USDT-47.svg',
  XRP: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/XRP-44.svg',
  SOL: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/SOL-97.svg',
  LTC: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/LTC-42.svg',
  DOGE: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/DOG-45.svg',
  TRX: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/TRX-46.svg',
};

const liveWinsData: LiveWin[] = [
    { gameName: "West Town", winAmount: "$186.14", currency: "BTC", gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fsoftswiss%2FWestTown-17.png", gameUrl: "https://wild.io/games/west-town" },
    { gameName: "Bonanza Trillion", winAmount: "$1.00", currency: "USDT", gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fsoftswiss%2FBonanzaTrillion-19.png", gameUrl: "https://wild.io/games/bonanza-trillion" },
    { gameName: "Sharky Frenzy", winAmount: "$0.50", currency: "XRP", gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fwild.io%2Fthumbnail%2Fmancala%2FSharkyFrenzy-16.webp", gameUrl: "https://wild.io/games/sharky-frenzy" },
    { gameName: "Clucking Hell", winAmount: "$72.53", currency: "SOL", gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fsoftswiss%2FCluckingHell-22.png", gameUrl: "https://wild.io/games/clucking-hell" },
    { gameName: "Bonus Mania Plinko", winAmount: "$2.00", currency: "LTC", gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fkagaming%2FBonusManiaPlinko-12.png", gameUrl: "https://wild.io/games/bonus-mania-plinko" },
    { gameName: "Slot", winAmount: "$17.50", currency: "BTC", gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Foriginals%2FSlot-14.png", gameUrl: "https://wild.io/games/slot" },
    { gameName: "Hell Hot 20", winAmount: "$1.60", currency: "BTC", gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fendorphina%2Fendorphina2_HellHot20-7.png", gameUrl: "https://wild.io/games/hell-hot-20" },
    { gameName: "Hell Hot 100", winAmount: "$126.00", currency: "BTC", gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fendorphina%2Fendorphina2_HellHot100-9.png", gameUrl: "https://wild.io/games/hell-hot-100" },
    { gameName: "Fortune Mummy", winAmount: "$4.35", currency: "LTC", gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fbelatra%2FFortuneMummy-5.png", gameUrl: "https://wild.io/games/fortune-mummy" },
    { gameName: "Temple Of Ra", winAmount: "$1.20", currency: "BTC", gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fendorphina%2Fendorphina2_TempleOfRa-6.png", gameUrl: "https://wild.io/games/temple-of-ra" },
    { gameName: "Jackpot Joker FEVER", winAmount: "$6.40", currency: "XRP", gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fwild.io%2Fthumbnail%2Ftadagaming%2FJackpotJokerFEVER-8.webp", gameUrl: "https://wild.io/games/jackpot-joker-fever" },
    { gameName: "LuckyCrown 81x", winAmount: "$0.31", currency: "DOGE", gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2F1spin4win%2FLuckyCrown81x-10.png", gameUrl: "https://wild.io/games/luckycrown-81x" },
    { gameName: "Wild Bandito", winAmount: "$2.16", currency: "TRX", gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fwild.io%2Fthumbnail%2Fpgsoft%2FWildBandito-15.webp", gameUrl: "https://wild.io/games/wild-bandito" },
    { gameName: "Chaos Crew 3", winAmount: "$13.40", currency: "LTC", gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fhacksaw%2FChaosCrew394-18.png", gameUrl: "https://wild.io/games/chaos-crew-3" },
];

const WinCard = React.memo(({ win }: { win: LiveWin }) => (
  <a href={win.gameUrl} className="flex-shrink-0 w-[150px] bg-[#1a1f2e] rounded-md shadow-md hover:shadow-xl transition-all duration-300 ease-in-out hover:scale-105" target="_blank" rel="noopener noreferrer">
    <div className="relative h-[200px] w-full"><Image src={win.gameImage} alt={win.gameName} layout="fill" objectFit="cover" className="rounded-t-md" /></div>
    <div className="p-3 flex flex-col gap-1">
      <p className="text-xs text-text-secondary truncate">{win.gameName}</p>
      <div className="flex items-center gap-1.5">
        <p className="text-base font-bold text-white">{win.winAmount}</p>
        <Image src={cryptoIcons[win.currency]} alt={win.currency} width={16} height={16} />
      </div>
    </div>
  </a>
));
WinCard.displayName = 'WinCard';

const LiveWinsCarousel = () => {
    const scrollContainerRef = useRef<HTMLDivElement>(null);
    const animationFrameRef = useRef<number>();
    const isHovering = useRef(false);
    const scrollSpeed = 0.5;

    useEffect(() => {
        const scroll = () => {
            if (scrollContainerRef.current && !isHovering.current) {
                const el = scrollContainerRef.current;
                if (el.scrollLeft >= el.scrollWidth / 2) {
                    el.scrollLeft = el.scrollLeft - (el.scrollWidth / 2);
                } else {
                    el.scrollLeft += scrollSpeed;
                }
            }
            animationFrameRef.current = requestAnimationFrame(scroll);
        };

        animationFrameRef.current = requestAnimationFrame(scroll);

        return () => {
            if (animationFrameRef.current) {
                cancelAnimationFrame(animationFrameRef.current);
            }
        };
    }, []);

    const handleScroll = (direction: 'left' | 'right') => {
        if (scrollContainerRef.current) {
            const scrollAmount = direction === 'left' ? -300 : 300;
            scrollContainerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
        }
    };

    return (
        <section className="py-8 bg-gradient-to-r from-blue-700 via-blue-900 to-blue-700">
            <style>{`.no-scrollbar::-webkit-scrollbar { display: none; } .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }`}</style>
            <div className="container">
                <div className="flex items-center gap-3 mb-6">
                    <span className="relative flex h-3 w-3"><span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span><span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span></span>
                    <h2 className="text-2xl font-semibold text-white">Live Wins</h2>
                </div>
                <div className="group relative" onMouseEnter={() => isHovering.current = true} onMouseLeave={() => isHovering.current = false}>
                    <div ref={scrollContainerRef} className="flex gap-4 overflow-x-auto no-scrollbar">
                        {[...liveWinsData, ...liveWinsData].map((win, index) => <WinCard key={`${win.gameName}-${index}`} win={win} />)}
                    </div>
                    <button onClick={() => handleScroll('left')} className="absolute left-0 top-1/2 -translate-y-1/2 z-10 p-2 bg-black/30 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-black/50" aria-label="Scroll left"><ChevronLeft className="h-6 w-6" /></button>
                    <button onClick={() => handleScroll('right')} className="absolute right-0 top-1/2 -translate-y-1/2 z-10 p-2 bg-black/30 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-black/50" aria-label="Scroll right"><ChevronRight className="h-6 w-6" /></button>
                </div>
            </div>
        </section>
    );
};

export default LiveWinsCarousel;
