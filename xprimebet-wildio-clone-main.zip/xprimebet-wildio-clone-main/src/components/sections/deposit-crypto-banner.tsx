"use client";

import Image from "next/image";

const cryptoIcons = [
  { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/BTC-26.svg", name: "BTC" },
  { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/ETH-27.svg", name: "ETH" },
  { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/XRP-28.svg", name: "XRP" },
  { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/SOL-29.svg", name: "SOL" },
  { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/USDT-30.svg", name: "USDT" },
  { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/USDC-31.svg", name: "USDC" },
  { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/DOG-32.svg", name: "DOGE" },
  { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/BNB-33.svg", name: "BNB" },
  { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/ADA-34.svg", name: "ADA" },
  { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/TRX-35.svg", name: "TRX" },
  { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/LTC-36.svg", name: "LTC" },
  { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/BCH-37.svg", name: "BCH" },
  { src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/TON-38.svg", name: "TON" },
];

const DepositCryptoBanner = () => {
  return (
    /*<div className="relative my-6 overflow-hidden rounded-xl bg-gradient-to-r from-[#162B3A] to-[#0D2433] p-4 shadow-lg md:my-8 md:p-6">*/
    <div className="relative my-6 overflow-hidden rounded-xl bg-gradient-to-r from-blue-700 to-blue-900 p-4 shadow-lg md:my-8 md:p-6">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <Image
          src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/deposit-banner-bg-39.svg"
          alt="Background Pattern"
          fill
          className="object-cover"
        />
      </div>

      <div className="relative flex flex-col items-center gap-4 md:flex-row md:justify-between">
        {/* Left Text */}
        <div className="text-center md:text-left">
          <h3 className="text-lg font-semibold text-white md:text-xl">
            Want to play? Deposit now
          </h3>
        </div>

        {/* Crypto Icons - Scrollable on mobile */}
        <div className="no-scrollbar flex w-full gap-3 overflow-x-auto md:w-auto md:flex-wrap md:justify-center">
          {cryptoIcons.map((crypto, index) => (
            <div
              key={index}
              className="flex-shrink-0 transition-transform hover:scale-110"
            >
              <Image
                src={crypto.src}
                alt={crypto.name}
                width={32}
                height={32}
                className="h-8 w-8"
              />
            </div>
          ))}
        </div>

        {/* Deposit Button */}
        <a href="#deposit" className="w-full md:w-auto">
          <button className="w-full whitespace-nowrap rounded-lg bg-gradient-to-b from-blue-500 to-blue-700 px-8 py-3 font-semibold text-white shadow-[0_0_20px_rgba(59,130,246,0.3)] transition-all hover:scale-105 hover:shadow-[0_0_28px_rgba(59,130,246,0.5)] md:w-auto">
            Deposit
          </button>
        </a>
      </div>
    </div>
  );
};

export default DepositCryptoBanner;
