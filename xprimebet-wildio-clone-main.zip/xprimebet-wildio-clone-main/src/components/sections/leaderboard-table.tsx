"use client";

import { useState } from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";

const ASSET_BASE_URL = "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs";

const winnersData = [
  {
    game: { name: "Chaos Crew 3", icon: "https://www.wild.io/cdn-cgi/image/width=3840,quality=75,format=auto//assets/home-category-icons/slots.svg" },
    player: "Pl****",
    bet: { amount: "0.20", currency: "LTC", icon: `${ASSET_BASE_URL}/ltc-101.svg` },
    multiplier: "67.00x",
    payout: { amount: "13.40", currency: "LTC", icon: `${ASSET_BASE_URL}/ltc-101.svg` },
  },
  {
    game: { name: "West Town", icon: "https://www.wild.io/cdn-cgi/image/width=3840,quality=75,format=auto//assets/home-category-icons/slots.svg" },
    player: "Da****",
    bet: { amount: "55.84", currency: "BTC", icon: `${ASSET_BASE_URL}/btc-98.svg` },
    multiplier: "1.11x",
    payout: { amount: "62.05", currency: "BTC", icon: `${ASSET_BASE_URL}/btc-98.svg` },
  },
  {
    game: { name: "Sharky Frenzy", icon: `${ASSET_BASE_URL}/bonus-buy-96.svg` },
    player: "Aar**",
    bet: { amount: "0.20", currency: "XRP", icon: `${ASSET_BASE_URL}/xrp-107.svg` },
    multiplier: "11.50x",
    payout: { amount: "2.30", currency: "XRP", icon: `${ASSET_BASE_URL}/xrp-107.svg` },
  },
  {
    game: { name: "Wild Bandito", icon: "https://www.wild.io/cdn-cgi/image/width=3840,quality=75,format=auto//assets/home-category-icons/slots.svg" },
    player: "sej*********************",
    bet: { amount: "1.20", currency: "TRX", icon: `${ASSET_BASE_URL}/trx-104.svg` },
    multiplier: "1.80x",
    payout: { amount: "2.16", currency: "TRX", icon: `${ASSET_BASE_URL}/trx-104.svg` },
  },
  {
    game: { name: "Aztec Clusters", icon: `${ASSET_BASE_URL}/bonus-buy-96.svg` },
    player: "pl****",
    bet: { amount: "0.25", currency: "TRX", icon: `${ASSET_BASE_URL}/trx-104.svg` },
    multiplier: "2.84x",
    payout: { amount: "0.71", currency: "TRX", icon: `${ASSET_BASE_URL}/trx-104.svg` },
  },
  {
    game: { name: "Slot", icon: "https://www.wild.io/cdn-cgi/image/width=3840,quality=75,format=auto//assets/home-category-icons/slots.svg" },
    player: "Pl****",
    bet: { amount: "5.00", currency: "BTC", icon: `${ASSET_BASE_URL}/btc-98.svg` },
    multiplier: "2.20x",
    payout: { amount: "11.00", currency: "BTC", icon: `${ASSET_BASE_URL}/btc-98.svg` },
  },
  {
    game: { name: "West Town", icon: "https://www.wild.io/cdn-cgi/image/width=3840,quality=75,format=auto//assets/home-category-icons/slots.svg" },
    player: "Da****",
    bet: { amount: "55.84", currency: "BTC", icon: `${ASSET_BASE_URL}/btc-98.svg` },
    multiplier: "3.33x",
    payout: { amount: "186.14", currency: "BTC", icon: `${ASSET_BASE_URL}/btc-98.svg` },
  },
];

export default function LeaderboardTable() {
  const [activeTab, setActiveTab] = useState("recent");

  return (
    <section className="py-16 container bg-gradient-to-r from-blue-700 via-blue-900 to-blue-700">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-white font-bold text-[28px] leading-[1.4]">Leaderboard</h2>
	<div className="flex items-center p-1 rounded-lg bg-[#141920]">
          <button
            onClick={() => setActiveTab("recent")}
            className={cn(
              "px-5 py-2 text-sm font-semibold rounded-[5px] transition-colors duration-200",
              activeTab === "recent"
                ? "bg-secondary-background text-white"
                : "text-text-secondary hover:bg-white/5"
            )}
          >
            Recent Winners
          </button>
          <button
            onClick={() => setActiveTab("top")}
            className={cn(
              "px-5 py-2 text-sm font-semibold rounded-[5px] transition-colors duration-200",
              activeTab === "top"
                ? "bg-secondary-background text-white"
                : "text-text-secondary hover:bg-white/5"
            )}
          >
            Top Winners
          </button>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[900px] border-separate border-spacing-y-1">
          <thead>
            <tr>
              <th className="px-5 py-3 text-xs font-semibold text-left uppercase text-text-tertiary">Game</th>
              <th className="px-5 py-3 text-xs font-semibold text-left uppercase text-text-tertiary">Player</th>
              <th className="px-5 py-3 text-xs font-semibold text-left uppercase text-text-tertiary">Bet Amount</th>
              <th className="px-5 py-3 text-xs font-semibold text-left uppercase text-text-tertiary">Multiplier</th>
              <th className="px-5 py-3 text-xs font-semibold text-left uppercase text-text-tertiary">Payout</th>
            </tr>
          </thead>
          <tbody>
            {winnersData.map((row, index) => (
              <tr 
                key={index} 
                className="bg-[#1a1f2e] hover:bg-[#202637] transition-colors rounded-lg"
              >
                <td className="px-5 py-3 whitespace-nowrap rounded-l-md">
                  <div className="flex items-center gap-3">
                    <Image src={row.game.icon} alt={row.game.name} width={32} height={32} />
                    <span className="text-sm font-semibold text-white">{row.game.name}</span>
                  </div>
                </td>
                <td className="px-5 py-3 whitespace-nowrap">
                   <div className="max-w-[120px]">
                    <span className="text-sm font-semibold text-white truncate block">{row.player}</span>
                  </div>
                </td>
                <td className="px-5 py-3 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-white">${row.bet.amount}</span>
                    <Image src={row.bet.icon} alt={row.bet.currency} width={16} height={16} />
                  </div>
                </td>
                <td className="px-5 py-3 whitespace-nowrap">
                  <span className="text-sm font-semibold text-white">{row.multiplier}</span>
                </td>
                <td className="px-5 py-3 whitespace-nowrap rounded-r-md">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-white">${row.payout.amount}</span>
                    <Image src={row.payout.icon} alt={row.payout.currency} width={16} height={16} />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
