"use client";

import { useState } from "react";
import Image from "next/image";

const CookieNoticeBanner = () => {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) {
    return null;
  }

  const handleAccept = () => {
    // In a real app, this would set a cookie.
    setIsVisible(false);
  };

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 bg-[#1a1f2e]">
      <div className="container mx-auto flex flex-col items-stretch gap-y-3 py-3 md:flex-row md:items-center md:justify-between md:gap-x-4">
        <div className="flex items-center gap-x-3">
          <Image
            src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/cookies-1.svg"
            alt="Cookies icon"
            width={20}
            height={20}
            className="shrink-0"
          />
          <p className="text-sm text-white">
            <span className="font-medium">Xprimebet uses cookies.</span> See{' '}
            <a href="#" className="cursor-pointer underline">
              Cookie Notice
            </a>{' '}
            for details.
          </p>
        </div>
        <button
          onClick={handleAccept}
          className="w-full shrink-0 rounded-md bg-blue-600 px-6 py-2 text-sm font-semibold text-white transition-colors hover:bg-blue-700 md:w-auto"
        >
          Accept all
        </button>
      </div>
    </div>
  );
};

export default CookieNoticeBanner;
