globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/01257_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_e6f3783b._.js",
    "static/chunks/01257_next_dist_compiled_27fb8d36._.js",
    "static/chunks/01257_next_dist_client_76689be1._.js",
    "static/chunks/01257_next_dist_dbcdd27a._.js",
    "static/chunks/93c3d_@swc_helpers_cjs_a58df798._.js",
    "static/chunks/Documents_xprimebet-wildio-clone-main_e69f0d32._.js",
    "static/chunks/Documents_xprimebet-wildio-clone-main_f5414772._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];