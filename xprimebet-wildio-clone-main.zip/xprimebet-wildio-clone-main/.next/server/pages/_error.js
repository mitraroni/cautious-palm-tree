const CHUNK_PUBLIC_PATH = "server/pages/_error.js";
const runtime = require("../chunks/ssr/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/ssr/01257_next_354361c8._.js");
runtime.loadChunk("server/chunks/ssr/[root-of-the-server]__c75c51b7._.js");
runtime.loadChunk("server/chunks/ssr/01257_next_f0b21cea._.js");
runtime.loadChunk("server/chunks/ssr/01257_next_27b38ebf._.js");
runtime.getOrInstantiateRuntimeModule("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)", CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
