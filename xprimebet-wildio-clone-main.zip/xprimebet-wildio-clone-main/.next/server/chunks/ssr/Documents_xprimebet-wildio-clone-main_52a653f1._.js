module.exports = {

"[project]/Documents/xprimebet-wildio-clone-main/src/visual-edits/VisualEditsMessenger.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "CHANNEL": (()=>CHANNEL),
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const CHANNEL = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CHANNEL() from the server but CHANNEL is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/visual-edits/VisualEditsMessenger.tsx <module evaluation>", "CHANNEL");
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/visual-edits/VisualEditsMessenger.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/visual-edits/VisualEditsMessenger.tsx <module evaluation>", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/visual-edits/VisualEditsMessenger.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "CHANNEL": (()=>CHANNEL),
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const CHANNEL = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CHANNEL() from the server but CHANNEL is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/visual-edits/VisualEditsMessenger.tsx", "CHANNEL");
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/visual-edits/VisualEditsMessenger.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/visual-edits/VisualEditsMessenger.tsx", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/visual-edits/VisualEditsMessenger.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$visual$2d$edits$2f$VisualEditsMessenger$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/visual-edits/VisualEditsMessenger.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$visual$2d$edits$2f$VisualEditsMessenger$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/visual-edits/VisualEditsMessenger.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$visual$2d$edits$2f$VisualEditsMessenger$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/ErrorReporter.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/ErrorReporter.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/ErrorReporter.tsx <module evaluation>", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/ErrorReporter.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/ErrorReporter.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/ErrorReporter.tsx", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/ErrorReporter.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$ErrorReporter$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/ErrorReporter.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$ErrorReporter$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/ErrorReporter.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$ErrorReporter$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/app/layout.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>RootLayout),
    "metadata": (()=>metadata)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$visual$2d$edits$2f$VisualEditsMessenger$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/visual-edits/VisualEditsMessenger.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$ErrorReporter$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/ErrorReporter.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/script.js [app-rsc] (ecmascript)");
;
;
;
;
;
const metadata = {
    title: "Create Next App",
    description: "Generated by create next app"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("html", {
        "data-orchids-id": "src/app/layout.tsx:18:4",
        "data-orchids-name": "html",
        lang: "en",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("body", {
            "data-orchids-id": "src/app/layout.tsx:19:6",
            "data-orchids-name": "body",
            className: "antialiased",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$ErrorReporter$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                    "data-orchids-id": "src/app/layout.tsx:20:8",
                    "data-orchids-name": "ErrorReporter"
                }, void 0, false, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/layout.tsx",
                    lineNumber: 20,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                    "data-orchids-id": "src/app/layout.tsx:21:8",
                    "data-orchids-name": "Script",
                    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/scripts//route-messenger.js",
                    strategy: "afterInteractive",
                    "data-target-origin": "*",
                    "data-message-type": "ROUTE_CHANGE",
                    "data-include-search-params": "true",
                    "data-only-in-iframe": "true",
                    "data-debug": "true",
                    "data-custom-data": '{"appName": "YourApp", "version": "1.0.0", "greeting": "hi"}'
                }, void 0, false, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/layout.tsx",
                    lineNumber: 21,
                    columnNumber: 9
                }, this),
                children,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$visual$2d$edits$2f$VisualEditsMessenger$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                    "data-orchids-id": "src/app/layout.tsx:32:8",
                    "data-orchids-name": "VisualEditsMessenger"
                }, void 0, false, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/layout.tsx",
                    lineNumber: 32,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/layout.tsx",
            lineNumber: 19,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/layout.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
}}),
"[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
module.exports = __turbopack_context__.r("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-rsc] (ecmascript)").vendored['react-rsc'].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
}}),
"[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/client/script.js (client reference/proxy) <module evaluation>": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const { createClientModuleProxy } = __turbopack_context__.r("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
__turbopack_context__.n(createClientModuleProxy("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/client/script.js <module evaluation>"));
}}),
"[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/client/script.js (client reference/proxy)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const { createClientModuleProxy } = __turbopack_context__.r("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
__turbopack_context__.n(createClientModuleProxy("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/client/script.js"));
}}),
"[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/client/script.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$script$2e$js__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/client/script.js (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$script$2e$js__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/client/script.js (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$script$2e$js__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/script.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
module.exports = __turbopack_context__.r("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/client/script.js [app-rsc] (ecmascript)");
}}),

};

//# sourceMappingURL=Documents_xprimebet-wildio-clone-main_52a653f1._.js.map