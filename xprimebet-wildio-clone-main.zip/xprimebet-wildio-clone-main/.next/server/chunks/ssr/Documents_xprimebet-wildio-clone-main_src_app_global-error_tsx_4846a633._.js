module.exports = {

"[project]/Documents/xprimebet-wildio-clone-main/src/app/global-error.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$ErrorReporter$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/ErrorReporter.tsx [app-ssr] (ecmascript)");
"use client";
;
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$ErrorReporter$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"];
}}),

};

//# sourceMappingURL=Documents_xprimebet-wildio-clone-main_src_app_global-error_tsx_4846a633._.js.map