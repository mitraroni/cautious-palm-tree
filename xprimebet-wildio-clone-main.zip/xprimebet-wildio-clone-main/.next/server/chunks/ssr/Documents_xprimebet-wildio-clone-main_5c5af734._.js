module.exports = {

"[project]/Documents/xprimebet-wildio-clone-main/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/app/favicon.ico.mjs { IMAGE => \"[project]/Documents/xprimebet-wildio-clone-main/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/app/favicon.ico.mjs { IMAGE => \"[project]/Documents/xprimebet-wildio-clone-main/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/app/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/app/global-error.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/app/global-error.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx <module evaluation>", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$cookie$2d$notice$2d$banner$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$cookie$2d$notice$2d$banner$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$cookie$2d$notice$2d$banner$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx <module evaluation>", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$header$2d$navigation$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$header$2d$navigation$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$header$2d$navigation$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx <module evaluation>", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$sidebar$2d$navigation$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$sidebar$2d$navigation$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$sidebar$2d$navigation$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx <module evaluation>", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$mobile$2d$bottom$2d$navigation$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$mobile$2d$bottom$2d$navigation$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$mobile$2d$bottom$2d$navigation$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx <module evaluation>", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$hero$2d$welcome$2d$section$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$hero$2d$welcome$2d$section$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$hero$2d$welcome$2d$section$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx <module evaluation>", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$deposit$2d$crypto$2d$banner$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$deposit$2d$crypto$2d$banner$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$deposit$2d$crypto$2d$banner$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx <module evaluation>", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$casino$2d$sports$2d$cards$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$casino$2d$sports$2d$cards$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$casino$2d$sports$2d$cards$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx <module evaluation>", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$live$2d$wins$2d$carousel$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$live$2d$wins$2d$carousel$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$live$2d$wins$2d$carousel$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx <module evaluation>", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$casino$2d$games$2d$grid$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$casino$2d$games$2d$grid$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$casino$2d$games$2d$grid$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx <module evaluation>", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$daily$2d$rakeback$2d$banner$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$daily$2d$rakeback$2d$banner$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$daily$2d$rakeback$2d$banner$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sports-categories-grid.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/image.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/client/app-dir/link.js [app-rsc] (ecmascript)");
;
;
;
const sportsData = [
    {
        name: 'Football',
        href: '/sports/soccer',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_football-51.svg'
    },
    {
        name: 'Basketball',
        href: '/sports/basketball',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_basketball-52.svg'
    },
    {
        name: 'Tennis',
        href: '/sports/tennis',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_tennis-53.svg'
    },
    {
        name: 'American Football',
        href: '/sports/american-football',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_american_football-54.svg'
    },
    {
        name: 'Counter Strike',
        href: '/sports/cs2',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_counter_strike-55.svg'
    },
    {
        name: 'e-Football',
        href: '/sports/cybersport',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_e_football-56.svg'
    },
    {
        name: 'Ice Hockey',
        href: '/sports/ice-hockey',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_ice_hockey-57.svg'
    },
    {
        name: 'Cricket',
        href: '/sports/cricket',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_cricket-58.svg'
    },
    {
        name: 'Dota',
        href: '/sports/dota2',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_dota-59.svg'
    },
    {
        name: 'LOL',
        href: '/sports/lol',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_league_of_legends-60.svg'
    },
    {
        name: 'Boxing',
        href: '/sports/boxing',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_boxing-61.svg'
    },
    {
        name: 'MMA',
        href: '/sports/mma',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_mma-62.svg'
    },
    {
        name: 'Baseball',
        href: '/sports/baseball',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_baseball-63.svg'
    },
    {
        name: 'Valorant',
        href: '/sports/valorant',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_valorant-64.svg'
    },
    {
        name: 'Volleyball',
        href: '/sports/volleyball',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_volleyball-65.svg'
    },
    {
        name: 'Table Tennis',
        href: '/sports/table-tennis',
        icon: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sportsbook_icon_table_tennis-66.svg'
    }
];
const SportsCategoriesGrid = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "data-orchids-id": "src/components/sections/sports-categories-grid.tsx:25:4",
        "data-orchids-name": "section",
        className: "mt-8 lg:mt-16",
        "aria-labelledby": "sports-heading",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/sports-categories-grid.tsx:26:6",
                "data-orchids-name": "div",
                className: "mb-4 flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        "data-orchids-id": "src/components/sections/sports-categories-grid.tsx:27:8",
                        "data-orchids-name": "Link",
                        href: "/sports",
                        className: "flex items-center space-x-2 group",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                "data-orchids-id": "src/components/sections/sports-categories-grid.tsx:28:10",
                                "data-orchids-name": "img",
                                src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sports-category-50.svg",
                                alt: "Sports icon",
                                width: 28,
                                height: 28,
                                unoptimized: true
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sports-categories-grid.tsx",
                                lineNumber: 28,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                "data-orchids-id": "src/components/sections/sports-categories-grid.tsx:35:10",
                                "data-orchids-name": "h3",
                                id: "sports-heading",
                                className: "text-lg font-bold text-text-primary lg:text-xl transition-colors group-hover:text-primary",
                                children: "Sports"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sports-categories-grid.tsx",
                                lineNumber: 35,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sports-categories-grid.tsx",
                        lineNumber: 27,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        "data-orchids-id": "src/components/sections/sports-categories-grid.tsx:39:8",
                        "data-orchids-name": "Link",
                        href: "/sports",
                        className: "rounded-md px-2 py-0.5 text-xs text-text-secondary hover:bg-secondary transition-colors",
                        children: [
                            "View all",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                "data-orchids-id": "src/components/sections/sports-categories-grid.tsx:41:10",
                                "data-orchids-name": "span",
                                className: "ml-1 rounded-sm bg-card px-2 py-1 text-[10px] font-bold text-text-primary",
                                children: "16"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sports-categories-grid.tsx",
                                lineNumber: 41,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sports-categories-grid.tsx",
                        lineNumber: 39,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sports-categories-grid.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/sports-categories-grid.tsx:46:6",
                "data-orchids-name": "div",
                className: "grid grid-cols-3 gap-2 md:grid-cols-4 md:gap-4 lg:grid-cols-8",
                children: sportsData.map((sport)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        "data-orchids-id": "src/components/sections/sports-categories-grid.tsx:48:10@sportsData",
                        "data-orchids-name": "Link",
                        href: sport.href,
                        className: "group",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/sports-categories-grid.tsx:49:12@sportsData",
                            "data-orchids-name": "div",
                            className: "flex h-full flex-col justify-center rounded-lg bg-[#1a1f2e] p-3 text-center transition-colors ease-in-out hover:bg-[#202638] lg:gap-2 lg:p-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                    "data-orchids-id": "src/components/sections/sports-categories-grid.tsx:50:14@sportsData",
                                    "data-orchids-name": "img",
                                    src: sport.icon,
                                    alt: `Sports ${sport.name}`,
                                    width: 64,
                                    height: 64,
                                    unoptimized: true,
                                    className: "mx-auto block h-12 w-12 transform-gpu transition-transform duration-200 ease-in-out group-hover:scale-110 lg:h-16 lg:w-16"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sports-categories-grid.tsx",
                                    lineNumber: 50,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    "data-orchids-id": "src/components/sections/sports-categories-grid.tsx:58:14@sportsData",
                                    "data-orchids-name": "span",
                                    className: "mt-2 text-[13px] text-text-primary",
                                    children: sport.name
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sports-categories-grid.tsx",
                                    lineNumber: 58,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sports-categories-grid.tsx",
                            lineNumber: 49,
                            columnNumber: 13
                        }, this)
                    }, sport.name, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sports-categories-grid.tsx",
                        lineNumber: 48,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sports-categories-grid.tsx",
                lineNumber: 46,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sports-categories-grid.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = SportsCategoriesGrid;
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx <module evaluation>", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$game$2d$providers$2d$carousel$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$game$2d$providers$2d$carousel$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$game$2d$providers$2d$carousel$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx <module evaluation>", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$content$2d$about$2d$casino$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$content$2d$about$2d$casino$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$content$2d$about$2d$casino$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/crypto-payment-logos.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/image.js [app-rsc] (ecmascript)");
;
;
const cryptoLogos = [
    {
        name: "Bitcoin",
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/btc-98.svg"
    },
    {
        name: "Bitcoin Cash",
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/bch-99.svg"
    },
    {
        name: "Ethereum",
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/eth-100.svg"
    },
    {
        name: "Litecoin",
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/ltc-101.svg"
    },
    {
        name: "Dogecoin",
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/dog-102.svg"
    },
    {
        name: "Tether",
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/usdt-103.svg"
    },
    {
        name: "Tron",
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/trx-104.svg"
    },
    {
        name: "Cardano",
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/ada-105.svg"
    },
    {
        name: "Binance",
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/bnb-106.svg"
    },
    {
        name: "Ripple",
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/xrp-107.svg"
    },
    {
        name: "Solana",
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sol-108.svg"
    },
    {
        name: "USD Coin",
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/usdc-110.svg"
    }
];
const CryptoPaymentLogos = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "data-orchids-id": "src/components/sections/crypto-payment-logos.tsx:57:4",
        "data-orchids-name": "section",
        className: "bg-background",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            "data-orchids-id": "src/components/sections/crypto-payment-logos.tsx:58:6",
            "data-orchids-name": "div",
            className: "container px-3 py-10 md:py-14",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/crypto-payment-logos.tsx:59:8",
                "data-orchids-name": "div",
                className: "flex flex-wrap items-center justify-center gap-x-12 gap-y-4 md:gap-x-20",
                children: cryptoLogos.map((logo)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        "data-orchids-id": "src/components/sections/crypto-payment-logos.tsx:61:12@cryptoLogos",
                        "data-orchids-name": "img",
                        src: logo.src,
                        alt: logo.name,
                        width: 80,
                        height: 32,
                        className: "h-auto w-20 filter grayscale transition-all duration-300 hover:filter-none"
                    }, logo.name, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/crypto-payment-logos.tsx",
                        lineNumber: 61,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/crypto-payment-logos.tsx",
                lineNumber: 59,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/crypto-payment-logos.tsx",
            lineNumber: 58,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/crypto-payment-logos.tsx",
        lineNumber: 57,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = CryptoPaymentLogos;
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/image.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$instagram$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Instagram$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/instagram.js [app-rsc] (ecmascript) <export default as Instagram>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-rsc] (ecmascript) <export default as MessageCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/star.js [app-rsc] (ecmascript) <export default as Star>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$twitter$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Twitter$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/twitter.js [app-rsc] (ecmascript) <export default as Twitter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$send$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Send$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/send.js [app-rsc] (ecmascript) <export default as Send>");
;
;
;
const ThemeToggle = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-orchids-id": "src/components/sections/footer.tsx:5:2",
        "data-orchids-name": "div",
        className: "relative flex w-[76px] cursor-pointer items-center rounded-full bg-[#061824] p-1 text-sm font-semibold text-gray-400",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/footer.tsx:6:4",
                "data-orchids-name": "div",
                className: "absolute h-[28px] w-[34px] rounded-full bg-[#5cb85c] transition-transform duration-300",
                style: {
                    transform: 'translateX(34px)'
                }
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                lineNumber: 6,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                "data-orchids-id": "src/components/sections/footer.tsx:7:4",
                "data-orchids-name": "span",
                className: "relative z-10 flex h-7 w-1/2 items-center justify-center",
                children: "AM"
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                lineNumber: 7,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                "data-orchids-id": "src/components/sections/footer.tsx:8:4",
                "data-orchids-name": "span",
                className: "relative z-10 flex h-7 w-1/2 items-center justify-center text-white",
                children: "PM"
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                lineNumber: 8,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
        lineNumber: 5,
        columnNumber: 3
    }, this);
const ExcellentSupportBadge = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-orchids-id": "src/components/sections/footer.tsx:13:2",
        "data-orchids-name": "div",
        className: "relative flex h-[72px] w-[120px] flex-col items-center justify-center gap-y-1 rounded-lg border border-gray-700 bg-gray-800/10 p-2 text-center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/footer.tsx:14:4",
                "data-orchids-name": "div",
                className: "flex text-[#ffb700]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                        "data-orchids-id": "src/components/sections/footer.tsx:15:6",
                        "data-orchids-name": "Star",
                        fill: "currentColor",
                        strokeWidth: 0,
                        className: "h-3.5 w-3.5"
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                        lineNumber: 15,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                        "data-orchids-id": "src/components/sections/footer.tsx:16:6",
                        "data-orchids-name": "Star",
                        fill: "currentColor",
                        strokeWidth: 0,
                        className: "h-3.5 w-3.5"
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                        lineNumber: 16,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                        "data-orchids-id": "src/components/sections/footer.tsx:17:6",
                        "data-orchids-name": "Star",
                        fill: "currentColor",
                        strokeWidth: 0,
                        className: "h-3.5 w-3.5"
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                        lineNumber: 17,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                        "data-orchids-id": "src/components/sections/footer.tsx:18:6",
                        "data-orchids-name": "Star",
                        fill: "currentColor",
                        strokeWidth: 0,
                        className: "h-3.5 w-3.5"
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                        lineNumber: 18,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                        "data-orchids-id": "src/components/sections/footer.tsx:19:6",
                        "data-orchids-name": "Star",
                        fill: "currentColor",
                        strokeWidth: 0,
                        className: "h-3.5 w-3.5"
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                        lineNumber: 19,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                lineNumber: 14,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/footer.tsx:21:4",
                "data-orchids-name": "div",
                className: "text-[9px] font-bold uppercase leading-none tracking-wider text-white",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    "data-orchids-id": "src/components/sections/footer.tsx:22:6",
                    "data-orchids-name": "p",
                    children: "Excellent Support"
                }, void 0, false, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                    lineNumber: 22,
                    columnNumber: 7
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                lineNumber: 21,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                "data-orchids-id": "src/components/sections/footer.tsx:24:4",
                "data-orchids-name": "p",
                className: "text-[8px] uppercase text-gray-400",
                children: "2025"
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                lineNumber: 24,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
        lineNumber: 13,
        columnNumber: 3
    }, this);
const FooterLink = ({ href, children })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
        "data-orchids-id": "src/components/sections/footer.tsx:29:2",
        "data-orchids-name": "li",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            "data-orchids-id": "src/components/sections/footer.tsx:30:4",
            "data-orchids-name": "a",
            href: href,
            className: "text-[#a0a0a0] hover:text-[#5cb85c] transition-colors leading-loose",
            children: children
        }, void 0, false, {
            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
            lineNumber: 30,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
        lineNumber: 29,
        columnNumber: 3
    }, this);
const Footer = ()=>{
    const socialLinks = [
        {
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$send$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Send$3e$__["Send"], {
                "data-orchids-id": "src/components/sections/footer.tsx:38:16",
                "data-orchids-name": "Send",
                className: "h-5 w-5"
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                lineNumber: 38,
                columnNumber: 17
            }, this),
            href: "https://t.me/wild_io",
            label: "Telegram"
        },
        {
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$twitter$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Twitter$3e$__["Twitter"], {
                "data-orchids-id": "src/components/sections/footer.tsx:39:16",
                "data-orchids-name": "Twitter",
                className: "h-5 w-5"
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                lineNumber: 39,
                columnNumber: 17
            }, this),
            href: "https://x.com/wild_io",
            label: "Twitter"
        },
        {
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$instagram$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__Instagram$3e$__["Instagram"], {
                "data-orchids-id": "src/components/sections/footer.tsx:40:16",
                "data-orchids-name": "Instagram",
                className: "h-5 w-5"
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                lineNumber: 40,
                columnNumber: 17
            }, this),
            href: "https://instagram.com/wild.io_casino",
            label: "Instagram"
        },
        {
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__["MessageCircle"], {
                "data-orchids-id": "src/components/sections/footer.tsx:41:16",
                "data-orchids-name": "MessageCircle",
                className: "h-5 w-5"
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                lineNumber: 41,
                columnNumber: 17
            }, this),
            href: "https://discord.gg/wildio",
            label: "Discord"
        }
    ];
    const linkColumns = {
        'SLOT GAMES': [
            {
                text: 'Slots',
                href: '/slots'
            },
            {
                text: 'Skill Games',
                href: '/casino'
            },
            {
                text: 'Jackpot',
                href: '/casino'
            },
            {
                text: 'Bonus Buy',
                href: '/casino'
            },
            {
                text: 'Crash Games',
                href: '/casino'
            }
        ],
        'LIVE CASINO': [
            {
                text: 'Roulette',
                href: '/live-casino'
            },
            {
                text: 'Blackjack',
                href: '/live-casino'
            },
            {
                text: 'Live Casino',
                href: '/live-casino'
            },
            {
                text: 'Table Games',
                href: '/casino'
            },
            {
                text: 'Video Poker',
                href: '/casino'
            }
        ],
        'CASINO': [
            {
                text: 'About Us',
                href: '/about'
            },
            {
                text: 'Promotions',
                href: '/promotions'
            },
            {
                text: 'Tournaments',
                href: '/tournaments'
            },
            {
                text: 'Affiliate Program',
                href: '/affiliate'
            },
            {
                text: 'Loyalty Program',
                href: '/vip'
            },
            {
                text: 'Refer a friend',
                href: '/vip'
            },
            {
                text: 'Blog',
                href: '/blog'
            },
            {
                text: 'Bonus Shop',
                href: '/promotions'
            },
            {
                text: 'Agent Verification',
                href: '/support'
            },
            {
                text: 'Jungle Jackpot',
                href: '/casino'
            }
        ],
        'LEGAL': [
            {
                text: 'Privacy Policy',
                href: '/privacy-policy'
            },
            {
                text: 'Terms & Conditions',
                href: '/terms'
            },
            {
                text: 'Bonus Terms',
                href: '/promotions'
            },
            {
                text: 'Responsible Gambling',
                href: '/responsible-gambling'
            }
        ],
        'SUPPORT': [
            {
                text: 'Live Support',
                href: '/support'
            }
        ]
    };
    const awards = [
        {
            src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fbest-new-casino-1-117.svg",
            alt: "Best New Casino 2023"
        },
        {
            src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fbest-casino-1-119.svg",
            alt: "Best Casino 2024"
        },
        {
            src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fplayers-choice-1-121.svg",
            alt: "Player's Choice 2025"
        }
    ];
    const responsibleGamingLogos = [
        {
            src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/footer-badge-112.svg",
            alt: "18+",
            width: 28,
            height: 28
        },
        {
            src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/gamcare-113.svg",
            alt: "GameCare",
            width: 106,
            height: 28
        },
        {
            src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/responsiblegambling-114.svg",
            alt: "Responsible Gaming",
            width: 104,
            height: 28
        },
        {
            src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/gamblersanonymous-115.svg",
            alt: "Gamblers Anonymous",
            width: 92,
            height: 28
        },
        {
            src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/icons/GCBSeal-1.png",
            alt: "GCB Seal",
            width: 42,
            height: 42
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        "data-orchids-id": "src/components/sections/footer.tsx:97:8",
        "data-orchids-name": "footer",
        className: "bg-[#0a0e14] py-16 text-sm font-sans",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            "data-orchids-id": "src/components/sections/footer.tsx:98:12",
            "data-orchids-name": "div",
            className: "mx-auto max-w-[1440px] px-8 lg:px-12",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    "data-orchids-id": "src/components/sections/footer.tsx:99:16",
                    "data-orchids-name": "div",
                    className: "grid grid-cols-2 md:grid-cols-4 lg:grid-cols-[1.5fr_repeat(5,_1fr)] gap-y-10 gap-x-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/footer.tsx:100:20",
                            "data-orchids-name": "div",
                            className: "col-span-2 flex flex-col gap-y-6 lg:col-span-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    "data-orchids-id": "src/components/sections/footer.tsx:101:24",
                                    "data-orchids-name": "a",
                                    href: "/",
                                    className: "w-fit",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                        "data-orchids-id": "src/components/sections/footer.tsx:102:28",
                                        "data-orchids-name": "img",
                                        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Flogo-dark-v2-3.svg",
                                        alt: "Xprimebet Logo",
                                        width: 110,
                                        height: 36
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                                        lineNumber: 102,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                                    lineNumber: 101,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    "data-orchids-id": "src/components/sections/footer.tsx:104:24",
                                    "data-orchids-name": "p",
                                    className: "text-[#a0a0a0]",
                                    children: "© 2025 Xprimebet. All rights reserved."
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                                    lineNumber: 104,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    "data-orchids-id": "src/components/sections/footer.tsx:105:24",
                                    "data-orchids-name": "div",
                                    className: "flex space-x-4 text-[#a0a0a0]",
                                    children: socialLinks.map((link, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            "data-map-index": index,
                                            "data-orchids-id": "src/components/sections/footer.tsx:107:32@socialLinks",
                                            "data-orchids-name": "a",
                                            href: link.href,
                                            "aria-label": link.label,
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            className: "hover:text-[#5cb85c] transition-colors",
                                            children: link.icon
                                        }, index, false, {
                                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                                            lineNumber: 107,
                                            columnNumber: 33
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                                    lineNumber: 105,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(ThemeToggle, {
                                    "data-orchids-id": "src/components/sections/footer.tsx:112:24",
                                    "data-orchids-name": "ThemeToggle"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                                    lineNumber: 112,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                            lineNumber: 100,
                            columnNumber: 21
                        }, this),
                        Object.entries(linkColumns).map(([title, links])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-orchids-id": "src/components/sections/footer.tsx:116:24",
                                "data-orchids-name": "div",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        "data-orchids-id": "src/components/sections/footer.tsx:117:28",
                                        "data-orchids-name": "h3",
                                        className: "font-semibold text-white uppercase tracking-wider mb-4",
                                        children: title
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                                        lineNumber: 117,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        "data-orchids-id": "src/components/sections/footer.tsx:118:28",
                                        "data-orchids-name": "ul",
                                        className: "space-y-2",
                                        children: links.map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(FooterLink, {
                                                "data-orchids-id": "src/components/sections/footer.tsx:120:36@links",
                                                "data-orchids-name": "FooterLink",
                                                href: link.href,
                                                children: link.text
                                            }, link.text, false, {
                                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                                                lineNumber: 120,
                                                columnNumber: 37
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                                        lineNumber: 118,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, title, true, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                                lineNumber: 116,
                                columnNumber: 25
                            }, this))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                    lineNumber: 99,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    "data-orchids-id": "src/components/sections/footer.tsx:127:16",
                    "data-orchids-name": "div",
                    className: "my-12 border-t border-gray-800"
                }, void 0, false, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                    lineNumber: 127,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    "data-orchids-id": "src/components/sections/footer.tsx:129:16",
                    "data-orchids-name": "div",
                    className: "flex flex-col lg:flex-row lg:items-start lg:justify-between gap-y-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            "data-orchids-id": "src/components/sections/footer.tsx:130:20",
                            "data-orchids-name": "p",
                            className: "text-[#a0a0a0] max-w-2xl leading-relaxed",
                            children: "Xprimebet.io is owned and operated by Nonce Gaming B.V. a company that is incorporated under the laws of Curacao with company registration number 161858, having its registered address at Scharlooweg 39, Willemstad, Curaçao. Xprimebet.io is licensed and holds a valid Certificate of Operation (OGL/2024/210/0198)."
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                            lineNumber: 130,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/footer.tsx:133:20",
                            "data-orchids-name": "div",
                            className: "flex items-center justify-start lg:justify-end gap-x-4 flex-wrap gap-y-4 shrink-0",
                            children: responsibleGamingLogos.map((logo, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                    "data-map-index": index,
                                    "data-orchids-id": "src/components/sections/footer.tsx:135:28@responsibleGamingLogos",
                                    "data-orchids-name": "img",
                                    src: logo.src,
                                    alt: logo.alt,
                                    width: logo.width,
                                    height: logo.height,
                                    className: "opacity-70"
                                }, index, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                                    lineNumber: 135,
                                    columnNumber: 29
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                            lineNumber: 133,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                    lineNumber: 129,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    "data-orchids-id": "src/components/sections/footer.tsx:140:16",
                    "data-orchids-name": "div",
                    className: "my-12 border-t border-gray-800"
                }, void 0, false, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                    lineNumber: 140,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    "data-orchids-id": "src/components/sections/footer.tsx:142:16",
                    "data-orchids-name": "div",
                    className: "flex flex-col lg:flex-row items-start gap-y-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            "data-orchids-id": "src/components/sections/footer.tsx:143:20",
                            "data-orchids-name": "h3",
                            className: "font-semibold text-white uppercase tracking-wider shrink-0 mr-8",
                            children: "Awards"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                            lineNumber: 143,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/footer.tsx:144:20",
                            "data-orchids-name": "div",
                            className: "flex items-center flex-wrap gap-4",
                            children: [
                                awards.map((award, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        "data-map-index": index,
                                        "data-orchids-id": "src/components/sections/footer.tsx:146:28@awards",
                                        "data-orchids-name": "a",
                                        href: "#",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                            "data-map-index": index,
                                            "data-orchids-id": "src/components/sections/footer.tsx:147:32@awards",
                                            "data-orchids-name": "img",
                                            src: award.src,
                                            alt: award.alt,
                                            width: 120,
                                            height: 72,
                                            className: "opacity-80 hover:opacity-100 transition-opacity"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                                            lineNumber: 147,
                                            columnNumber: 33
                                        }, this)
                                    }, index, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                                        lineNumber: 146,
                                        columnNumber: 29
                                    }, this)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    "data-orchids-id": "src/components/sections/footer.tsx:150:24",
                                    "data-orchids-name": "a",
                                    href: "#",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(ExcellentSupportBadge, {
                                        "data-orchids-id": "src/components/sections/footer.tsx:151:27",
                                        "data-orchids-name": "ExcellentSupportBadge"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                                        lineNumber: 151,
                                        columnNumber: 28
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                                    lineNumber: 150,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                            lineNumber: 144,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
                    lineNumber: 142,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
            lineNumber: 98,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx",
        lineNumber: 97,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = Footer;
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx <module evaluation>", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx", "default");
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$live$2d$chat$2d$widget$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$live$2d$chat$2d$widget$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$live$2d$chat$2d$widget$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Home)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$cookie$2d$notice$2d$banner$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$header$2d$navigation$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$sidebar$2d$navigation$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$mobile$2d$bottom$2d$navigation$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$hero$2d$welcome$2d$section$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$deposit$2d$crypto$2d$banner$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$casino$2d$sports$2d$cards$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$live$2d$wins$2d$carousel$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$casino$2d$games$2d$grid$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$daily$2d$rakeback$2d$banner$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$sports$2d$categories$2d$grid$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sports-categories-grid.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$game$2d$providers$2d$carousel$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx [app-rsc] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '@/components/sections/leaderboard-table'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$content$2d$about$2d$casino$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$crypto$2d$payment$2d$logos$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/crypto-payment-logos.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$footer$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/footer.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$live$2d$chat$2d$widget$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function Home() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-orchids-id": "src/app/page.tsx:22:4",
        "data-orchids-name": "div",
        className: "min-h-screen bg-primary-background",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$cookie$2d$notice$2d$banner$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                "data-orchids-id": "src/app/page.tsx:23:6",
                "data-orchids-name": "CookieNoticeBanner"
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$header$2d$navigation$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                "data-orchids-id": "src/app/page.tsx:24:6",
                "data-orchids-name": "HeaderNavigation"
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$sidebar$2d$navigation$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                "data-orchids-id": "src/app/page.tsx:25:6",
                "data-orchids-name": "SidebarNavigation"
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$mobile$2d$bottom$2d$navigation$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                "data-orchids-id": "src/app/page.tsx:26:6",
                "data-orchids-name": "MobileBottomNavigation"
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                "data-orchids-id": "src/app/page.tsx:28:6",
                "data-orchids-name": "main",
                className: "pb-16 pt-14 md:pb-0 lg:ml-16 lg:pt-16",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$hero$2d$welcome$2d$section$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        "data-orchids-id": "src/app/page.tsx:29:8",
                        "data-orchids-name": "HeroWelcomeSection"
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                        lineNumber: 29,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/app/page.tsx:31:8",
                        "data-orchids-name": "div",
                        className: "container mx-auto px-4 lg:px-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$deposit$2d$crypto$2d$banner$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                "data-orchids-id": "src/app/page.tsx:32:10",
                                "data-orchids-name": "DepositCryptoBanner"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                                lineNumber: 32,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$casino$2d$sports$2d$cards$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                "data-orchids-id": "src/app/page.tsx:33:10",
                                "data-orchids-name": "CasinoSportsCards"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                                lineNumber: 33,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                        lineNumber: 31,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$live$2d$wins$2d$carousel$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        "data-orchids-id": "src/app/page.tsx:36:8",
                        "data-orchids-name": "LiveWinsCarousel"
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                        lineNumber: 36,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/app/page.tsx:38:8",
                        "data-orchids-name": "div",
                        className: "container mx-auto px-4 lg:px-8",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$casino$2d$games$2d$grid$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                            "data-orchids-id": "src/app/page.tsx:39:10",
                            "data-orchids-name": "CasinoGamesGrid"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                            lineNumber: 39,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                        lineNumber: 38,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$daily$2d$rakeback$2d$banner$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        "data-orchids-id": "src/app/page.tsx:42:8",
                        "data-orchids-name": "DailyRakebackBanner"
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/app/page.tsx:44:8",
                        "data-orchids-name": "div",
                        className: "container mx-auto px-4 lg:px-8",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$sports$2d$categories$2d$grid$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                            "data-orchids-id": "src/app/page.tsx:45:10",
                            "data-orchids-name": "SportsCategoriesGrid"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                            lineNumber: 45,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                        lineNumber: 44,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$game$2d$providers$2d$carousel$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        "data-orchids-id": "src/app/page.tsx:48:8",
                        "data-orchids-name": "GameProvidersCarousel"
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(LeaderboardTable, {
                        "data-orchids-id": "src/app/page.tsx:49:8",
                        "data-orchids-name": "LeaderboardTable"
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$content$2d$about$2d$casino$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                "data-orchids-id": "src/app/page.tsx:52:6",
                "data-orchids-name": "ContentAboutCasino"
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$crypto$2d$payment$2d$logos$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                "data-orchids-id": "src/app/page.tsx:53:6",
                "data-orchids-name": "CryptoPaymentLogos"
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$footer$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                "data-orchids-id": "src/app/page.tsx:54:6",
                "data-orchids-name": "Footer"
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$src$2f$components$2f$sections$2f$live$2d$chat$2d$widget$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                "data-orchids-id": "src/app/page.tsx:55:6",
                "data-orchids-name": "LiveChatWidget"
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
                lineNumber: 55,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/src/app/page.tsx [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=Documents_xprimebet-wildio-clone-main_5c5af734._.js.map