module.exports = {

"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/menu.js [app-ssr] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/search.js [app-ssr] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/user.js [app-ssr] (ecmascript) <export default as User>");
"use client";
;
;
;
;
const NavLink = ({ href, iconSrc, text, active = false })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
        "data-orchids-id": "src/components/sections/header-navigation.tsx:8:2",
        "data-orchids-name": "a",
        href: href,
        className: `group flex items-center space-x-2 whitespace-nowrap rounded-md px-5 py-2 text-[15px] font-semibold transition-all duration-200 focus:outline-none ${active ? "bg-[#1a2332] text-white" : "text-gray-400 hover:bg-[#1a2332] hover:text-white"}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                "data-orchids-id": "src/components/sections/header-navigation.tsx:16:4",
                "data-orchids-name": "img",
                src: iconSrc,
                alt: `${text} tab`,
                width: 18,
                height: 18
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                lineNumber: 16,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                "data-orchids-id": "src/components/sections/header-navigation.tsx:17:4",
                "data-orchids-name": "span",
                children: text
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                lineNumber: 17,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
        lineNumber: 8,
        columnNumber: 3
    }, this);
const HeaderNavigation = ()=>{
    const [isMobileMenuOpen, setIsMobileMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const handleResize = ()=>{
            if (window.innerWidth >= 768) {
                setIsMobileMenuOpen(false);
            }
        };
        window.addEventListener('resize', handleResize);
        return ()=>window.removeEventListener('resize', handleResize);
    }, []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                "data-orchids-id": "src/components/sections/header-navigation.tsx:36:6",
                "data-orchids-name": "header",
                className: "fixed top-0 left-0 right-0 z-[100] w-full bg-[#1a2332] font-['Proxima_Nova'] shadow-[0_2px_8px_rgba(0,0,0,0.15)]",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    "data-orchids-id": "src/components/sections/header-navigation.tsx:37:8",
                    "data-orchids-name": "div",
                    className: "flex h-14 flex-row items-center px-3 lg:h-16",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/header-navigation.tsx:38:10",
                            "data-orchids-name": "div",
                            className: "flex items-center space-x-3 md:space-x-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:39:12",
                                    "data-orchids-name": "button",
                                    className: "hidden h-9 w-9 items-center justify-center rounded-md p-0 text-gray-400 hover:bg-white/10 md:flex",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:40:16",
                                        "data-orchids-name": "Menu",
                                        className: "h-7 w-7"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 40,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 39,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:42:12",
                                    "data-orchids-name": "button",
                                    className: "flex h-9 w-9 items-center justify-center rounded-md p-0 text-gray-400 hover:bg-white/10 md:hidden",
                                    onClick: ()=>setIsMobileMenuOpen(!isMobileMenuOpen),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:43:16",
                                        "data-orchids-name": "Menu",
                                        className: "h-7 w-7"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 43,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 42,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:45:12",
                                    "data-orchids-name": "a",
                                    href: "/",
                                    className: "flex items-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:46:16",
                                        "data-orchids-name": "img",
                                        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/document-uploads/IMG_20251006_113700_220-1759733945934.jpg",
                                        alt: "Xprimebet Logo",
                                        width: 140,
                                        height: 48,
                                        className: "h-9 w-auto md:h-10",
                                        priority: true
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 46,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 45,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                            lineNumber: 38,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/header-navigation.tsx:57:10",
                            "data-orchids-name": "div",
                            className: "ml-4 hidden flex-row items-center md:flex",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                "data-orchids-id": "src/components/sections/header-navigation.tsx:58:14",
                                "data-orchids-name": "nav",
                                "aria-label": "Tabs",
                                className: "inline-flex space-x-1 rounded-lg bg-[#0D2433] p-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(NavLink, {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:59:16",
                                        "data-orchids-name": "NavLink",
                                        href: "#",
                                        iconSrc: "https://www.wild.io/cdn-cgi/image/width=48,quality=75,format=auto//assets/category-icons/slot-games.svg",
                                        text: "Casino",
                                        active: true
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 59,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(NavLink, {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:60:16",
                                        "data-orchids-name": "NavLink",
                                        href: "#",
                                        iconSrc: "https://www.wild.io/cdn-cgi/image/width=48,quality=75,format=auto//assets/category-icons/sports.svg",
                                        text: "Sports"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 60,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                lineNumber: 58,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                            lineNumber: 57,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/header-navigation.tsx:64:10",
                            "data-orchids-name": "div",
                            className: "hidden flex-1 items-center lg:flex lg:pl-2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-orchids-id": "src/components/sections/header-navigation.tsx:65:12",
                                "data-orchids-name": "div",
                                className: "relative w-full max-w-md",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:66:16",
                                        "data-orchids-name": "div",
                                        className: "pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                            "data-orchids-id": "src/components/sections/header-navigation.tsx:67:20",
                                            "data-orchids-name": "Search",
                                            className: "h-5 w-5 stroke-gray-500"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                            lineNumber: 67,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 66,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:69:16",
                                        "data-orchids-name": "input",
                                        id: "navbar-search-trigger",
                                        className: "h-10 w-full cursor-pointer rounded-lg border-0 bg-[#0D2433] py-2.5 pl-12 pr-10 text-sm text-white placeholder-gray-500 ring-1 ring-inset ring-white/10 transition-all duration-200 ease-in-out focus:ring-2 focus:ring-inset focus:ring-[#5cb85c] hover:placeholder:text-gray-400",
                                        placeholder: "Search for Games & Providers",
                                        type: "search"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 69,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:75:16",
                                        "data-orchids-name": "div",
                                        className: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("kbd", {
                                            "data-orchids-id": "src/components/sections/header-navigation.tsx:76:20",
                                            "data-orchids-name": "kbd",
                                            className: "inline-flex items-center rounded border border-gray-600 px-2 font-sans text-xs font-medium text-gray-400",
                                            children: "CTRL+K"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                            lineNumber: 76,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 75,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                lineNumber: 65,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                            lineNumber: 64,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/header-navigation.tsx:83:10",
                            "data-orchids-name": "div",
                            className: "ml-auto flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:84:14",
                                    "data-orchids-name": "button",
                                    className: "flex h-10 w-10 items-center justify-center rounded-lg p-0 text-sm text-gray-400 hover:bg-white/10 lg:hidden",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:85:16",
                                        "data-orchids-name": "Search",
                                        className: "h-5 w-5 stroke-current"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 85,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 84,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:87:14",
                                    "data-orchids-name": "a",
                                    href: "#",
                                    className: "hidden md:block",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:88:16",
                                        "data-orchids-name": "button",
                                        className: "relative z-0 flex h-10 items-center justify-center overflow-hidden rounded-lg bg-transparent px-6 text-sm font-semibold text-white transition-all hover:bg-white/10",
                                        children: "Log In"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 88,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 87,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:92:14",
                                    "data-orchids-name": "a",
                                    href: "#",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:93:16",
                                        "data-orchids-name": "button",
                                        className: "relative z-0 flex h-10 items-center justify-center overflow-hidden whitespace-nowrap rounded-lg bg-[#5cb85c] px-6 text-sm font-semibold text-white transition-all hover:bg-[#5DB51F]",
                                        children: "Sign Up"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 93,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 92,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:97:14",
                                    "data-orchids-name": "div",
                                    className: "hidden rounded-xl bg-[#0D2433] p-1 md:block",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:98:16",
                                        "data-orchids-name": "button",
                                        className: "relative z-0 flex h-8 w-8 items-center justify-center overflow-hidden rounded-lg bg-transparent p-0 text-sm text-white transition-all hover:bg-white/10",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"], {
                                            "data-orchids-id": "src/components/sections/header-navigation.tsx:99:18",
                                            "data-orchids-name": "User",
                                            className: "h-5 w-5"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                            lineNumber: 99,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 98,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 97,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                            lineNumber: 83,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                    lineNumber: 37,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this),
            isMobileMenuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/header-navigation.tsx:108:8",
                "data-orchids-name": "div",
                className: "fixed inset-0 z-[99] pt-14 md:hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/header-navigation.tsx:109:10",
                        "data-orchids-name": "div",
                        className: "absolute inset-0 bg-black/50",
                        onClick: ()=>setIsMobileMenuOpen(false)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                        lineNumber: 109,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/header-navigation.tsx:110:10",
                        "data-orchids-name": "div",
                        className: "relative h-full w-4/5 max-w-xs bg-[#1a2332] p-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                            "data-orchids-id": "src/components/sections/header-navigation.tsx:111:14",
                            "data-orchids-name": "nav",
                            className: "flex flex-col space-y-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(NavLink, {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:112:17",
                                    "data-orchids-name": "NavLink",
                                    href: "#",
                                    iconSrc: "https://www.wild.io/cdn-cgi/image/width=48,quality=75,format=auto//assets/category-icons/slot-games.svg",
                                    text: "Casino",
                                    active: true
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 112,
                                    columnNumber: 18
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(NavLink, {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:113:17",
                                    "data-orchids-name": "NavLink",
                                    href: "#",
                                    iconSrc: "https://www.wild.io/cdn-cgi/image/width=48,quality=75,format=auto//assets/category-icons/sports.svg",
                                    text: "Sports"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 113,
                                    columnNumber: 18
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:114:17",
                                    "data-orchids-name": "div",
                                    className: "border-t border-white/10 pt-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:115:18",
                                        "data-orchids-name": "a",
                                        href: "#",
                                        className: "block w-full rounded-lg bg-transparent px-4 py-2.5 text-center font-semibold text-white ring-1 ring-inset ring-white/20",
                                        children: "Log In"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 115,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 114,
                                    columnNumber: 18
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                            lineNumber: 111,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                        lineNumber: 110,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                lineNumber: 108,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
};
const __TURBOPACK__default__export__ = HeaderNavigation;
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/image.js [app-ssr] (ecmascript)");
"use client";
;
;
const sidebarItems = [
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/home-5.svg",
        label: "Home",
        href: "/",
        active: true
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/slot-games-6.svg",
        label: "Slots",
        href: "#slots"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Flive_casino-17.svg",
        label: "Live Casino",
        href: "#live-casino"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Ftable_games-18.svg",
        label: "Table Games",
        href: "#table-games"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sports-7.svg",
        label: "Sports",
        href: "#sports"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fpromotions-21.svg",
        label: "Promotions",
        href: "#promotions"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Ftournaments-22.svg",
        label: "Tournaments",
        href: "#tournaments"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2FVIP_club-23.svg",
        label: "VIP Club",
        href: "#vip"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fwheel_of_fortune-8.svg",
        label: "Wheel",
        href: "#wheel"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fwild_lottery-10.svg",
        label: "Lottery",
        href: "#lottery"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fbonus_shop-11.svg",
        label: "Bonus Shop",
        href: "#bonus"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Flive_support-24.svg",
        label: "Support",
        href: "#support"
    }
];
const SidebarNavigation = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
        "data-orchids-id": "src/components/sections/sidebar-navigation.tsx:22:4",
        "data-orchids-name": "aside",
        className: "fixed left-0 top-14 z-[80] hidden h-[calc(100vh-3.5rem)] w-16 flex-col items-center gap-2 overflow-y-auto bg-[#0f1419] py-4 shadow-[2px_0_8px_rgba(0,0,0,0.15)] lg:top-16 lg:flex lg:h-[calc(100vh-4rem)]",
        children: sidebarItems.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                "data-map-index": index,
                "data-orchids-id": "src/components/sections/sidebar-navigation.tsx:24:8@sidebarItems",
                "data-orchids-name": "a",
                href: item.href,
                className: `group relative flex h-12 w-12 items-center justify-center rounded-full transition-all ${item.active ? "bg-[#6FCF26]/20 ring-2 ring-[#6FCF26]" : "bg-transparent hover:bg-white/10"}`,
                title: item.label,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        "data-map-index": index,
                        "data-orchids-id": "src/components/sections/sidebar-navigation.tsx:34:10@sidebarItems",
                        "data-orchids-name": "img",
                        src: item.icon,
                        alt: item.label,
                        width: 24,
                        height: 24,
                        className: `transition-all ${item.active ? "brightness-125" : "opacity-60 group-hover:opacity-100"}`
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx",
                        lineNumber: 34,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "data-map-index": index,
                        "data-orchids-id": "src/components/sections/sidebar-navigation.tsx:45:10@sidebarItems",
                        "data-orchids-name": "span",
                        className: "pointer-events-none absolute left-14 whitespace-nowrap rounded-md bg-[#1a2332] px-3 py-1.5 text-xs font-medium text-white opacity-0 shadow-lg transition-opacity group-hover:opacity-100",
                        children: item.label
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx",
                        lineNumber: 45,
                        columnNumber: 11
                    }, this)
                ]
            }, index, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx",
                lineNumber: 24,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = SidebarNavigation;
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$house$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Home$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/house.js [app-ssr] (ecmascript) <export default as Home>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gamepad$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Gamepad2$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/gamepad-2.js [app-ssr] (ecmascript) <export default as Gamepad2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trophy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trophy$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/trophy.js [app-ssr] (ecmascript) <export default as Trophy>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gift$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Gift$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/gift.js [app-ssr] (ecmascript) <export default as Gift>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/user.js [app-ssr] (ecmascript) <export default as User>");
"use client";
;
;
const MobileBottomNavigation = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:8:4",
        "data-orchids-name": "nav",
        className: "fixed bottom-0 left-0 right-0 z-[90] border-t border-white/10 bg-[#1a2332] shadow-[0_-2px_8px_rgba(0,0,0,0.15)] md:hidden",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:9:6",
            "data-orchids-name": "div",
            className: "flex items-center justify-around px-2 py-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:11:8",
                    "data-orchids-name": "a",
                    href: "/",
                    className: "flex flex-col items-center gap-1 rounded-lg px-4 py-2 transition-colors hover:bg-white/10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$house$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Home$3e$__["Home"], {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:15:10",
                            "data-orchids-name": "Home",
                            className: "h-5 w-5 text-[#6FCF26]"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 15,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:16:10",
                            "data-orchids-name": "span",
                            className: "text-[10px] font-medium text-white",
                            children: "Home"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 16,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                    lineNumber: 11,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:20:8",
                    "data-orchids-name": "a",
                    href: "#casino",
                    className: "flex flex-col items-center gap-1 rounded-lg px-4 py-2 transition-colors hover:bg-white/10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gamepad$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Gamepad2$3e$__["Gamepad2"], {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:24:10",
                            "data-orchids-name": "Gamepad2",
                            className: "h-5 w-5 text-gray-400"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 24,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:25:10",
                            "data-orchids-name": "span",
                            className: "text-[10px] font-medium text-gray-400",
                            children: "Casino"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 25,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                    lineNumber: 20,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:29:8",
                    "data-orchids-name": "a",
                    href: "#sports",
                    className: "flex flex-col items-center gap-1 rounded-lg px-4 py-2 transition-colors hover:bg-white/10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trophy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trophy$3e$__["Trophy"], {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:33:10",
                            "data-orchids-name": "Trophy",
                            className: "h-5 w-5 text-gray-400"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 33,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:34:10",
                            "data-orchids-name": "span",
                            className: "text-[10px] font-medium text-gray-400",
                            children: "Sports"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 34,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:38:8",
                    "data-orchids-name": "a",
                    href: "#promotions",
                    className: "flex flex-col items-center gap-1 rounded-lg px-4 py-2 transition-colors hover:bg-white/10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gift$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Gift$3e$__["Gift"], {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:42:10",
                            "data-orchids-name": "Gift",
                            className: "h-5 w-5 text-gray-400"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 42,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:43:10",
                            "data-orchids-name": "span",
                            className: "text-[10px] font-medium text-gray-400",
                            children: "Promos"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 43,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                    lineNumber: 38,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:47:8",
                    "data-orchids-name": "a",
                    href: "#account",
                    className: "flex flex-col items-center gap-1 rounded-lg px-4 py-2 transition-colors hover:bg-white/10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"], {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:51:10",
                            "data-orchids-name": "User",
                            className: "h-5 w-5 text-gray-400"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 51,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:52:10",
                            "data-orchids-name": "span",
                            className: "text-[10px] font-medium text-gray-400",
                            children: "Account"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 52,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                    lineNumber: 47,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
            lineNumber: 9,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = MobileBottomNavigation;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$square$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageSquare$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/message-square.js [app-ssr] (ecmascript) <export default as MessageSquare>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
"use client";
;
;
;
const LiveChatWidget = ()=>{
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-orchids-id": "src/components/sections/live-chat-widget.tsx:10:4",
        "data-orchids-name": "div",
        className: "fixed bottom-4 right-4 z-[9999] lg:bottom-8 lg:right-8",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            "data-orchids-id": "src/components/sections/live-chat-widget.tsx:11:6",
            "data-orchids-name": "button",
            onClick: ()=>setIsOpen(!isOpen),
            className: `
          group flex h-16 w-16 items-center justify-center rounded-full bg-[#6FCF26] text-white
          shadow-[0_0_20px_rgba(111,207,38,0.3)]
          transition-all duration-300 ease-in-out
          hover:scale-110 hover:shadow-[0_0_30px_rgba(111,207,38,0.6)]
          focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2
          ${!isOpen ? "animate-pulse" : ""}
        `,
            "aria-label": "Toggle live chat",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/live-chat-widget.tsx:23:8",
                "data-orchids-name": "div",
                className: "relative flex h-full w-full items-center justify-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "data-orchids-id": "src/components/sections/live-chat-widget.tsx:24:10",
                        "data-orchids-name": "span",
                        className: `
              absolute inset-0 flex items-center justify-center
              transition-opacity duration-300
              ${isOpen ? "opacity-0" : "opacity-100"}
            `,
                        "aria-hidden": isOpen,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$square$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageSquare$3e$__["MessageSquare"], {
                            "data-orchids-id": "src/components/sections/live-chat-widget.tsx:32:12",
                            "data-orchids-name": "MessageSquare",
                            size: 32,
                            className: "stroke-current"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx",
                            lineNumber: 32,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx",
                        lineNumber: 24,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "data-orchids-id": "src/components/sections/live-chat-widget.tsx:34:10",
                        "data-orchids-name": "span",
                        className: `
              absolute inset-0 flex items-center justify-center
              transition-opacity duration-300
              ${isOpen ? "opacity-100" : "opacity-0"}
            `,
                        "aria-hidden": !isOpen,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                            "data-orchids-id": "src/components/sections/live-chat-widget.tsx:42:12",
                            "data-orchids-name": "X",
                            size: 32,
                            className: "stroke-current"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx",
                            lineNumber: 42,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx",
                        lineNumber: 34,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx",
                lineNumber: 23,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx",
            lineNumber: 11,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = LiveChatWidget;
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__c8ad2e8a._.js.map