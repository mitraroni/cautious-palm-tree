module.exports = {

"[project]/Documents/xprimebet-wildio-clone-main/.next-internal/server/app/favicon.ico/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/app/favicon--route-entry.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "GET": (()=>GET),
    "dynamic": (()=>dynamic)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/server.js [app-rsc] (ecmascript)");
;
const contentType = "image/x-icon";
const cacheControl = "public, max-age=0, must-revalidate";
const buffer = Buffer.from("AAABAAEAIB8AAAEAIAAkEAAAFgAAACgAAAAgAAAAPgAAAAEAIAAAAAAAgA8AAAAAAAAAAAAAAAAAAAAAAADZ2dn/29vb/9zc3P/e3t7/39/f/+Dh4P/i4uH/4uPi/+Pj4//k5OT/5eXl/+Xl5f/m5ub/5+jm/+fn5//n5+f/5+fn/+fn5//n5+f/5+fn/+bm5v/m5ub/5eXl/+Tk5P/i4uL/4uLi/+Hh4f/f39//3d3d/9zc3P/b29v/2dnZ/9vb2//d3d3/3t7e/9/f3//h4eH/4uPi/+Pk4//l5eX/5+fm/+jo6P/p6en/6urq/+rq6v/r6+v/7Ozr/+zs7P/s7Oz/7Ozs/+vr6//r6+v/6urq/+np6f/o6Oj/5ubm/+Xl5f/k5OT/4uLi/+Hh4f/f39//3d3d/9zc3P/b29v/3d3d/97e3v/g4OD/4eHh/+Li4v/j4+P/4+Pj/+Hh4f/f39//3t7e/9vb2//Y2Nj/1tbV/9HR0f/Ozc3/zczM/87Nzf/Q0M//1NPT/9fX1//a2tr/3t7e/+Dg4P/i4uL/4+Pj/+Tk5P/k5OT/4uLi/+Hh4f/f39//3d3d/9zc3P/e3t7/4ODg/+Li4v/j4+P/5ebl/+Xl5f/k5OT/4uLi/9/f3//c3Nz/2NfX/9PS0f/T09T/0tXW/9DU1v/P09X/0NTW/9LV1//T1Nb/09PT/9fW1v/d3Nz/4ODg/+Pj4//l5eX/5eXl/+Xl5f/k5OT/4uLi/+Hh4f/f39//3d3d/+Dg4P/h4eH/4+Pj/+Xl5f/m5ub/6Ojo/+np6f/r6+v/7Ozs/+vq6v/y9Pb/9vn8/+ro5//b0cr/0L+z/8u3qf/Muqz/1ci9/+Pe2f/y9PX/9vn8/+3t7f/s6+v/7Ozs/+rq6v/p6en/5+fn/+Xl5f/k5OT/4uLi/+Hh4f/f39//4eHh/+Li4v/k5OT/5ubm/+fn5//p6en/6+vr/+rq6v/t7e3/9fn8/9zUzv+2nIn/n3ld/5ZqSv+VZ0X/lGZF/5RmRP+WaEX/mnBQ/6uJcf/Mu67/7/Dw//L19v/r6un/6+zr/+rq6v/p6en/5ufm/+Xl5f/k5OT/4uLi/+Dg4P/i4uL/5OTj/+Xl5f/n5+f/6enp/+rq6v/q6en/7/Hy/+7v7v+6oIz/mG5O/5drSv+ohmv/vqWS/9LCtf/g1c//18vD/8exoP+zlX3/nHRW/5RoR/+mg2n/29HK//X5+//r6+n/6+zr/+rq6v/p6ej/5ubm/+Xl5f/j4+P/4eHh/+Li4v/k5eT/5ubm/+jo6P/p6en/6unp/+7w8f/o5eP/poNp/5VrSv+qiW//2MrA//Hw8P//////7O3v/6qVfP/h1Lz///////f5+P/n4dz/vaSR/5pwUv+Ybk7/zLyv//T4+//q6ej/6+vr/+rq6v/o6Oj/5ubm/+Tk5P/i4uL/5OTk/+Xl5f/n5+f/6Ojo/+np6f/s7e3/6uno/6V/Zf+Xbk//vKOP//T09P/4+vv//f///9HKwv9WNyP/WCgA/6RlAf/HqnT/9Pf6//f4+f/7////2MvC/6J7X/+WbEr/zb+z//P3+v/q6ej/6+vr/+np6f/n5+f/5eXl/+Pj4//k5OT/5ubm/+jo6P/p6en/6eno//L19v+xk3z/l2xL/76nk//8////9PT2//r8/f/Mw7n/UyoN/0ggCP9xRhH/s3oI/6doAP/JpmD/9ff4//Pz9P/9////4NbP/6B5Xf+acVL/39nT//Dy8//q6+n/6uvq/+jo6P/m5ub/5OTk/+Xl5f/n5+f/6Ojo/+jn5//x9Pf/0MK2/5ZqSv+xknz/+Pn4//b3/P/s5tj/2Mqx/3FKL/9dLQz/VyoN/3hFCv+8fwP/uYEN/7d7AP/VvIX/5NrE//Py8//8////0sO3/5luT/+tjnb/8fT1/+rp6f/r6+v/6enp/+bm5v/l5eX/5eXl/+fn5//o6Oj/6ero/+7w8f+qh2//nHNU/+Pb1P/6////7enh/9m7d/+ZcVL/n35n//////+ynpL/dToA/9SqS//49e//6+DA/8eXMP/RtHP/382n//b6///5+/3/tZaA/5hrTP/XzcT/8fT2/+np6P/p6en/5+fn/+Xl5f/m5ub/6Ojn/+jo5//v8vL/2tLK/5ZsTf+3mYP/+////+TVtf/Cjhj/0rRz/4NQNP9wMQT/3dHF//////+3lmD/6ty1///////Qp0L/woIA/9vBgP/DkiT/0rFj//j7/P/bz8T/mGxM/7qfjP/0+Pr/6ejo/+rp6v/n6Of/5ubl/+bm5v/n6Of/5+fl//L1+P/EsaL/k2ZF/9XGvv/6////1LNi/8uXFP/NsoX/eDwX/3MwBP+BRyL/8Ovp//z57//hyYv/27de/8mLAP/LjQD/27pl/9GsTf/JmB//6uPM//L2//+mgGT/poFm/+3t7f/r6+z/6urq/+fn5//l5eX/5ubm/+jo5//n5ub/8fT2/7eahv+bcVT/4dbE/9itPf/MmBf/1aUk/8Sngv9wLwX/fUAV/3U0CP+kf2L///////Tq0v/SmhD/1JkG/9GSAP/ctU7/2LVd/8uXFf/LmBT/6Nej/7icjP+dc1L/5eDc/+7w8f/q6un/6Ojn/+Xl5f/m5uX/6Onn/+jo5v/v8vT/rYxw/5p2Y//bw4r/27NF/9u3Vf/eryz/x6uJ/4pSLv+PWTH/up2E/+be1f/Qv6z///////Pox//kwWD/36sk/+XAYP/fv2X/16sv/9q3Vv/gwF//uJ+L/5ZpR//f18//8PPz/+rq6P/o6Oj/5ubm/+bm5v/n6Of/6Ojn/+/w8P+ymIn/waqQ/+PEcv/erCX/15UA/+GpHv/Ls5j/kFkz/62FZv/7+/j/+Pj8/7ePWf/168r//////+7Xlf/jrRz/7Mpr/+PDa//VkAD/3KQP/+S+Tv/YwpP/rI18/93Uz//w8vL/6urp/+jo6P/l5eX/5ubm/+jo5//o6Ob/6+73/+PRn//jrRb/3pwA/96fAP/itDD/9uey/8eum/+HSh7/tJF2/9G7q/+ogmv/pGsk/+/Paf/06cP/68xu/+SuE//nv0b/8+3R/+fFYf/gqA7/25oA/+KmBf/kwFf/7Ovr/+zt7f/q6+n/6Ojo/+Xl5f/m5ub/6Ofm/+nr8f/o4MP/4qYF/+arBf/owU7/9uvA/66Od/+gfGf/wqmU/389Dv+APQ//fjoK/389GP+lax7/6LAE/+GnAP/jqwf/4qYA/+/EPf/HtKT/ilxD/+fdxf/t1H7/6LUf/+WiAP/nx2n/7PH4/+rp5v/o6Oj/5ubm/+Xl5f/n5+T/6u34/+bLef/lvUn/yrGK/8m4r//Bq6D/dToU/5txUf/TxLn/1MO1/7qZgv+ne1v/k19B/613Lv/ywiv/7sQ///LRYv/z3JH/8efL/7OWf/9+RyL/k2dO/9rSz//Apov/38Jz/+a9Pf/q59z/6uvt/+fn5v/l5eX/5eXl/+fn5//p6en/6eff/+3x+/+jgGz/mnBO/9zRx//Bqpj/i1gy/594W/+ngmf/vKKP/827rP/UxLj/2ce3/93Mtv/UxLX/wq2h/7GViP+Vak//hVEq/5xzVP/j3tb/tZmA/5NjRP/Ty8z/8fXz/+nn4v/p6ev/5+bm/+Xl5f/l5eX/5+fn/+np6f/o6Or/8vX1/829r/+UZ0b/wauY/7aZhf+LWDX/tJeA/6aEaf+TZEP/nnha/5drS/+UaEf/i1s4/553Wv+mg2f/tJh//5luTv+ifWD/mG1P/9XGvP+cc1T/rYxy//Dy8P/q6ur/6err/+jo6P/m5ub/5OTk/+Tk5P/l5eX/6Ojo/+jo6P/o6Of/8PP0/62MdP+YblH/qopx/7eciP+NXDj/oXpc/6N+Yv+3nYn/n3hc/6yNdf+8pZL/qIdu/6+Se/+Vakz/m3FS/6qHb/+6n43/oHZa/5pwUv/a0sv/8PLz/+no5//o6Oj/5+fn/+Xl5f/j4+P/4+Pj/+Xl5f/m5ub/6Ojo/+fn5//s7e3/5uTi/595Xv+fdln/x7Wm/+7v7//WysD/uqCL/6+Ndf+iel3/o3tg/6F5Xf+phWz/tpmD/8m1p//q5uP/39fR/6uKcv+Ya0v/yLao//P2+f/o5+f/6Onp/+fn5//m5ub/5OTk/+Li4v/i4uL/5OTk/+Xl5f/m5ub/6Ojn/+fm5v/u8PL/4t7Z/6B6X/+WZ0f/sJJ7/+Le2P/8//////////7////7/v///P7///7/////////8vPz/8a0pf+ddFb/lmpJ/8Syov/z9/n/6ejn/+np6f/o6Of/5ubm/+Xl5f/j4+P/4uLi/+Hh4f/j4+P/5eXl/+Xl5f/m5ub/6Ojo/+fm5f/t7/D/6Ofl/7OUfv+XaUn/l2xL/6yLcv/Drp7/08W6/9vOxv/XysL/zLqt/7abh/+ed1r/lGhH/6J8Yf/Sxrz/8vf4/+jn5//o6Oj/5+fn/+bm5v/l5eX/4+Pj/+Li4v/h4eH/4ODg/+Li4v/j4+P/5eXl/+Xl5f/m5ub/6Ojo/+fn5v/q6+z/8fX2/9XJwP+wkXv/mnJS/5RoRv+WaUn/mWtL/5hqSf+UaEj/l2tN/6WBZ//Dr6D/6enm//D09f/n5ub/6Ono/+fn5//m5ub/5eXl/+Tk5P/i4uL/4eHh/9/f3//f39//4eHh/+Li4v/i4+L/5OXk/+Xm5f/m5ub/5+jn/+jo5//n5ub/7/Pz//D09f/i3tr/0cW6/8aypP/Bq5r/w66e/8u7r//b08z/7Ozr//L2+P/q6+v/5+fm/+jo6P/n5+f/5ubm/+Xl5f/k5OT/4uLi/+Hh4f/g4OD/3t7e/93d3f/f39//4ODg/+Hh4f/i4uL/5OTk/+Xl5f/l5eX/5+fn/+jo6P/n5ub/5+bm/+vs7f/v8vX/8fT3//H09//x9Pf/8fT2/+3v8f/o6Oj/5+bl/+jn5//n5+f/5ubm/+Xl5f/k5OT/4+Pj/+Li4v/h4eH/4ODg/97e3v/c3Nz/3Nzc/93d3f/e3t7/4ODg/+Hh4f/i4uL/4+Tj/+Tl5P/l5eX/5ubm/+fn5//n5+f/5+fn/+bm5f/m5eX/5uXl/+bm5f/m5eX/5+fm/+fo5//n5+f/5ubm/+Xl5f/l5eX/5OTk/+Li4v/i4uL/4eHh/9/f3//e3t7/3d3d/9ra2v/a2tr/3Nzc/93d3f/e3t7/39/f/+Dg4P/i4eL/4+Pi/+Tk4//l5OX/5eXl/+Xl5f/m5ub/5ufl/+bm5v/m5ub/5ubm/+bm5v/m5uX/5ubl/+Xl5f/k5OT/5OTk/+Pj4//i4uL/4eHh/+Dg4P/f4N//3t7e/9zc3P/b29v/2dnZ/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=", 'base64');
if ("TURBOPACK compile-time falsy", 0) {
    "TURBOPACK unreachable";
}
function GET() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NextResponse"](buffer, {
        headers: {
            'Content-Type': contentType,
            'Cache-Control': cacheControl
        }
    });
}
const dynamic = 'force-static';
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__74ab2739._.js.map