(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_e6f3783b._.js",
  "static/chunks/01257_next_dist_compiled_27fb8d36._.js",
  "static/chunks/01257_next_dist_client_76689be1._.js",
  "static/chunks/01257_next_dist_dbcdd27a._.js",
  "static/chunks/93c3d_@swc_helpers_cjs_a58df798._.js"
],
    source: "entry"
});
