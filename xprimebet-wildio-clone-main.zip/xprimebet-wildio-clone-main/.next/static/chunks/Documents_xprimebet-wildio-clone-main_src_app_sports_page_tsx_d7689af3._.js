(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/01257_d4a9da82._.js",
  "static/chunks/Documents_xprimebet-wildio-clone-main_src_components_sections_1518469a._.js"
],
    source: "dynamic"
});
