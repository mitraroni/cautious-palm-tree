(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Documents_xprimebet-wildio-clone-main_src_app_global-error_tsx_3b2eaf3f._.js"
],
    source: "dynamic"
});
