(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/image.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const CookieNoticeBanner = ()=>{
    _s();
    const [isVisible, setIsVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    if (!isVisible) {
        return null;
    }
    const handleAccept = ()=>{
        // In a real app, this would set a cookie.
        setIsVisible(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-orchids-id": "src/components/sections/cookie-notice-banner.tsx:19:4",
        "data-orchids-name": "div",
        className: "fixed inset-x-0 bottom-0 z-50 bg-[#1a1f2e]",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            "data-orchids-id": "src/components/sections/cookie-notice-banner.tsx:20:6",
            "data-orchids-name": "div",
            className: "container mx-auto flex flex-col items-stretch gap-y-3 py-3 md:flex-row md:items-center md:justify-between md:gap-x-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    "data-orchids-id": "src/components/sections/cookie-notice-banner.tsx:21:8",
                    "data-orchids-name": "div",
                    className: "flex items-center gap-x-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            "data-orchids-id": "src/components/sections/cookie-notice-banner.tsx:22:10",
                            "data-orchids-name": "img",
                            src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/cookies-1.svg",
                            alt: "Cookies icon",
                            width: 20,
                            height: 20,
                            className: "shrink-0"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx",
                            lineNumber: 22,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            "data-orchids-id": "src/components/sections/cookie-notice-banner.tsx:29:10",
                            "data-orchids-name": "p",
                            className: "text-sm text-white",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    "data-orchids-id": "src/components/sections/cookie-notice-banner.tsx:30:12",
                                    "data-orchids-name": "span",
                                    className: "font-medium",
                                    children: "Xprimebet uses cookies."
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx",
                                    lineNumber: 30,
                                    columnNumber: 13
                                }, this),
                                " See",
                                ' ',
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    "data-orchids-id": "src/components/sections/cookie-notice-banner.tsx:31:12",
                                    "data-orchids-name": "a",
                                    href: "#",
                                    className: "cursor-pointer underline",
                                    children: "Cookie Notice"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx",
                                    lineNumber: 31,
                                    columnNumber: 13
                                }, this),
                                ' ',
                                "for details."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx",
                            lineNumber: 29,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx",
                    lineNumber: 21,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    "data-orchids-id": "src/components/sections/cookie-notice-banner.tsx:37:8@handleAccept",
                    "data-orchids-name": "button",
                    onClick: handleAccept,
                    className: "w-full shrink-0 rounded-md bg-[#5cb85c] px-6 py-2 text-sm font-semibold text-white transition-colors hover:bg-[#4cae4c] md:w-auto",
                    children: "Accept all"
                }, void 0, false, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx",
                    lineNumber: 37,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx",
            lineNumber: 20,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/cookie-notice-banner.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
};
_s(CookieNoticeBanner, "C45KFF5iQHXNkju7O/pllv86QL4=");
_c = CookieNoticeBanner;
const __TURBOPACK__default__export__ = CookieNoticeBanner;
var _c;
__turbopack_context__.k.register(_c, "CookieNoticeBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/menu.js [app-client] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/search.js [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/user.js [app-client] (ecmascript) <export default as User>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const NavLink = ({ href, iconSrc, text, active = false })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
        "data-orchids-id": "src/components/sections/header-navigation.tsx:8:2",
        "data-orchids-name": "a",
        href: href,
        className: `group flex items-center space-x-2 whitespace-nowrap rounded-md px-5 py-2 text-[15px] font-semibold transition-all duration-200 focus:outline-none ${active ? "bg-[#1a2332] text-white" : "text-gray-400 hover:bg-[#1a2332] hover:text-white"}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                "data-orchids-id": "src/components/sections/header-navigation.tsx:16:4",
                "data-orchids-name": "img",
                src: iconSrc,
                alt: `${text} tab`,
                width: 18,
                height: 18
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                lineNumber: 16,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                "data-orchids-id": "src/components/sections/header-navigation.tsx:17:4",
                "data-orchids-name": "span",
                children: text
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                lineNumber: 17,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
        lineNumber: 8,
        columnNumber: 3
    }, this);
_c = NavLink;
const HeaderNavigation = ()=>{
    _s();
    const [isMobileMenuOpen, setIsMobileMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HeaderNavigation.useEffect": ()=>{
            const handleResize = {
                "HeaderNavigation.useEffect.handleResize": ()=>{
                    if (window.innerWidth >= 768) {
                        setIsMobileMenuOpen(false);
                    }
                }
            }["HeaderNavigation.useEffect.handleResize"];
            window.addEventListener('resize', handleResize);
            return ({
                "HeaderNavigation.useEffect": ()=>window.removeEventListener('resize', handleResize)
            })["HeaderNavigation.useEffect"];
        }
    }["HeaderNavigation.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                "data-orchids-id": "src/components/sections/header-navigation.tsx:36:6",
                "data-orchids-name": "header",
                className: "fixed top-0 left-0 right-0 z-[100] w-full bg-[#1a2332] font-['Proxima_Nova'] shadow-[0_2px_8px_rgba(0,0,0,0.15)]",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    "data-orchids-id": "src/components/sections/header-navigation.tsx:37:8",
                    "data-orchids-name": "div",
                    className: "flex h-14 flex-row items-center px-3 lg:h-16",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/header-navigation.tsx:38:10",
                            "data-orchids-name": "div",
                            className: "flex items-center space-x-3 md:space-x-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:39:12",
                                    "data-orchids-name": "button",
                                    className: "hidden h-9 w-9 items-center justify-center rounded-md p-0 text-gray-400 hover:bg-white/10 md:flex",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:40:16",
                                        "data-orchids-name": "Menu",
                                        className: "h-7 w-7"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 40,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 39,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:42:12",
                                    "data-orchids-name": "button",
                                    className: "flex h-9 w-9 items-center justify-center rounded-md p-0 text-gray-400 hover:bg-white/10 md:hidden",
                                    onClick: ()=>setIsMobileMenuOpen(!isMobileMenuOpen),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:43:16",
                                        "data-orchids-name": "Menu",
                                        className: "h-7 w-7"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 43,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 42,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:45:12",
                                    "data-orchids-name": "a",
                                    href: "/",
                                    className: "flex items-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:46:16",
                                        "data-orchids-name": "img",
                                        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/document-uploads/IMG_20251006_113700_220-1759733945934.jpg",
                                        alt: "Xprimebet Logo",
                                        width: 140,
                                        height: 48,
                                        className: "h-9 w-auto md:h-10",
                                        priority: true
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 46,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 45,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                            lineNumber: 38,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/header-navigation.tsx:57:10",
                            "data-orchids-name": "div",
                            className: "ml-4 hidden flex-row items-center md:flex",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                "data-orchids-id": "src/components/sections/header-navigation.tsx:58:14",
                                "data-orchids-name": "nav",
                                "aria-label": "Tabs",
                                className: "inline-flex space-x-1 rounded-lg bg-[#0D2433] p-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NavLink, {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:59:16",
                                        "data-orchids-name": "NavLink",
                                        href: "#",
                                        iconSrc: "https://www.wild.io/cdn-cgi/image/width=48,quality=75,format=auto//assets/category-icons/slot-games.svg",
                                        text: "Casino",
                                        active: true
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 59,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NavLink, {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:60:16",
                                        "data-orchids-name": "NavLink",
                                        href: "#",
                                        iconSrc: "https://www.wild.io/cdn-cgi/image/width=48,quality=75,format=auto//assets/category-icons/sports.svg",
                                        text: "Sports"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 60,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                lineNumber: 58,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                            lineNumber: 57,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/header-navigation.tsx:64:10",
                            "data-orchids-name": "div",
                            className: "hidden flex-1 items-center lg:flex lg:pl-2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-orchids-id": "src/components/sections/header-navigation.tsx:65:12",
                                "data-orchids-name": "div",
                                className: "relative w-full max-w-md",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:66:16",
                                        "data-orchids-name": "div",
                                        className: "pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                            "data-orchids-id": "src/components/sections/header-navigation.tsx:67:20",
                                            "data-orchids-name": "Search",
                                            className: "h-5 w-5 stroke-gray-500"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                            lineNumber: 67,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 66,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:69:16",
                                        "data-orchids-name": "input",
                                        id: "navbar-search-trigger",
                                        className: "h-10 w-full cursor-pointer rounded-lg border-0 bg-[#0D2433] py-2.5 pl-12 pr-10 text-sm text-white placeholder-gray-500 ring-1 ring-inset ring-white/10 transition-all duration-200 ease-in-out focus:ring-2 focus:ring-inset focus:ring-[#5cb85c] hover:placeholder:text-gray-400",
                                        placeholder: "Search for Games & Providers",
                                        type: "search"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 69,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:75:16",
                                        "data-orchids-name": "div",
                                        className: "pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("kbd", {
                                            "data-orchids-id": "src/components/sections/header-navigation.tsx:76:20",
                                            "data-orchids-name": "kbd",
                                            className: "inline-flex items-center rounded border border-gray-600 px-2 font-sans text-xs font-medium text-gray-400",
                                            children: "CTRL+K"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                            lineNumber: 76,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 75,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                lineNumber: 65,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                            lineNumber: 64,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/header-navigation.tsx:83:10",
                            "data-orchids-name": "div",
                            className: "ml-auto flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:84:14",
                                    "data-orchids-name": "button",
                                    className: "flex h-10 w-10 items-center justify-center rounded-lg p-0 text-sm text-gray-400 hover:bg-white/10 lg:hidden",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:85:16",
                                        "data-orchids-name": "Search",
                                        className: "h-5 w-5 stroke-current"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 85,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 84,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:87:14",
                                    "data-orchids-name": "a",
                                    href: "#",
                                    className: "hidden md:block",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:88:16",
                                        "data-orchids-name": "button",
                                        className: "relative z-0 flex h-10 items-center justify-center overflow-hidden rounded-lg bg-transparent px-6 text-sm font-semibold text-white transition-all hover:bg-white/10",
                                        children: "Log In"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 88,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 87,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:92:14",
                                    "data-orchids-name": "a",
                                    href: "#",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:93:16",
                                        "data-orchids-name": "button",
                                        className: "relative z-0 flex h-10 items-center justify-center overflow-hidden whitespace-nowrap rounded-lg bg-[#5cb85c] px-6 text-sm font-semibold text-white transition-all hover:bg-[#5DB51F]",
                                        children: "Sign Up"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 93,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 92,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:97:14",
                                    "data-orchids-name": "div",
                                    className: "hidden rounded-xl bg-[#0D2433] p-1 md:block",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:98:16",
                                        "data-orchids-name": "button",
                                        className: "relative z-0 flex h-8 w-8 items-center justify-center overflow-hidden rounded-lg bg-transparent p-0 text-sm text-white transition-all hover:bg-white/10",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"], {
                                            "data-orchids-id": "src/components/sections/header-navigation.tsx:99:18",
                                            "data-orchids-name": "User",
                                            className: "h-5 w-5"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                            lineNumber: 99,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 98,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 97,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                            lineNumber: 83,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                    lineNumber: 37,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this),
            isMobileMenuOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/header-navigation.tsx:108:8",
                "data-orchids-name": "div",
                className: "fixed inset-0 z-[99] pt-14 md:hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/header-navigation.tsx:109:10",
                        "data-orchids-name": "div",
                        className: "absolute inset-0 bg-black/50",
                        onClick: ()=>setIsMobileMenuOpen(false)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                        lineNumber: 109,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/header-navigation.tsx:110:10",
                        "data-orchids-name": "div",
                        className: "relative h-full w-4/5 max-w-xs bg-[#1a2332] p-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                            "data-orchids-id": "src/components/sections/header-navigation.tsx:111:14",
                            "data-orchids-name": "nav",
                            className: "flex flex-col space-y-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NavLink, {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:112:17",
                                    "data-orchids-name": "NavLink",
                                    href: "#",
                                    iconSrc: "https://www.wild.io/cdn-cgi/image/width=48,quality=75,format=auto//assets/category-icons/slot-games.svg",
                                    text: "Casino",
                                    active: true
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 112,
                                    columnNumber: 18
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NavLink, {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:113:17",
                                    "data-orchids-name": "NavLink",
                                    href: "#",
                                    iconSrc: "https://www.wild.io/cdn-cgi/image/width=48,quality=75,format=auto//assets/category-icons/sports.svg",
                                    text: "Sports"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 113,
                                    columnNumber: 18
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    "data-orchids-id": "src/components/sections/header-navigation.tsx:114:17",
                                    "data-orchids-name": "div",
                                    className: "border-t border-white/10 pt-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        "data-orchids-id": "src/components/sections/header-navigation.tsx:115:18",
                                        "data-orchids-name": "a",
                                        href: "#",
                                        className: "block w-full rounded-lg bg-transparent px-4 py-2.5 text-center font-semibold text-white ring-1 ring-inset ring-white/20",
                                        children: "Log In"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                        lineNumber: 115,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                                    lineNumber: 114,
                                    columnNumber: 18
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                            lineNumber: 111,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                        lineNumber: 110,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/header-navigation.tsx",
                lineNumber: 108,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
};
_s(HeaderNavigation, "gQOEbwLkKOhPX9CeqhbWWB3OzL4=");
_c1 = HeaderNavigation;
const __TURBOPACK__default__export__ = HeaderNavigation;
var _c, _c1;
__turbopack_context__.k.register(_c, "NavLink");
__turbopack_context__.k.register(_c1, "HeaderNavigation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/image.js [app-client] (ecmascript)");
"use client";
;
;
const sidebarItems = [
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/home-5.svg",
        label: "Home",
        href: "/",
        active: true
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/slot-games-6.svg",
        label: "Slots",
        href: "#slots"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Flive_casino-17.svg",
        label: "Live Casino",
        href: "#live-casino"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Ftable_games-18.svg",
        label: "Table Games",
        href: "#table-games"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/sports-7.svg",
        label: "Sports",
        href: "#sports"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fpromotions-21.svg",
        label: "Promotions",
        href: "#promotions"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Ftournaments-22.svg",
        label: "Tournaments",
        href: "#tournaments"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2FVIP_club-23.svg",
        label: "VIP Club",
        href: "#vip"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fwheel_of_fortune-8.svg",
        label: "Wheel",
        href: "#wheel"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fwild_lottery-10.svg",
        label: "Lottery",
        href: "#lottery"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Fbonus_shop-11.svg",
        label: "Bonus Shop",
        href: "#bonus"
    },
    {
        icon: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/https%3A%2F%2Fpayload.wild.io%2Fapi%2Fmedia%2Ffile%2Flive_support-24.svg",
        label: "Support",
        href: "#support"
    }
];
const SidebarNavigation = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
        "data-orchids-id": "src/components/sections/sidebar-navigation.tsx:22:4",
        "data-orchids-name": "aside",
        className: "fixed left-0 top-14 z-[80] hidden h-[calc(100vh-3.5rem)] w-16 flex-col items-center gap-2 overflow-y-auto bg-[#0f1419] py-4 shadow-[2px_0_8px_rgba(0,0,0,0.15)] lg:top-16 lg:flex lg:h-[calc(100vh-4rem)]",
        children: sidebarItems.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                "data-map-index": index,
                "data-orchids-id": "src/components/sections/sidebar-navigation.tsx:24:8@sidebarItems",
                "data-orchids-name": "a",
                href: item.href,
                className: `group relative flex h-12 w-12 items-center justify-center rounded-full transition-all ${item.active ? "bg-[#6FCF26]/20 ring-2 ring-[#6FCF26]" : "bg-transparent hover:bg-white/10"}`,
                title: item.label,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        "data-map-index": index,
                        "data-orchids-id": "src/components/sections/sidebar-navigation.tsx:34:10@sidebarItems",
                        "data-orchids-name": "img",
                        src: item.icon,
                        alt: item.label,
                        width: 24,
                        height: 24,
                        className: `transition-all ${item.active ? "brightness-125" : "opacity-60 group-hover:opacity-100"}`
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx",
                        lineNumber: 34,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "data-map-index": index,
                        "data-orchids-id": "src/components/sections/sidebar-navigation.tsx:45:10@sidebarItems",
                        "data-orchids-name": "span",
                        className: "pointer-events-none absolute left-14 whitespace-nowrap rounded-md bg-[#1a2332] px-3 py-1.5 text-xs font-medium text-white opacity-0 shadow-lg transition-opacity group-hover:opacity-100",
                        children: item.label
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx",
                        lineNumber: 45,
                        columnNumber: 11
                    }, this)
                ]
            }, index, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx",
                lineNumber: 24,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/sidebar-navigation.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
};
_c = SidebarNavigation;
const __TURBOPACK__default__export__ = SidebarNavigation;
var _c;
__turbopack_context__.k.register(_c, "SidebarNavigation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$house$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Home$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/house.js [app-client] (ecmascript) <export default as Home>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gamepad$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Gamepad2$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/gamepad-2.js [app-client] (ecmascript) <export default as Gamepad2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trophy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trophy$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/trophy.js [app-client] (ecmascript) <export default as Trophy>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gift$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Gift$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/gift.js [app-client] (ecmascript) <export default as Gift>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/user.js [app-client] (ecmascript) <export default as User>");
"use client";
;
;
const MobileBottomNavigation = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:8:4",
        "data-orchids-name": "nav",
        className: "fixed bottom-0 left-0 right-0 z-[90] border-t border-white/10 bg-[#1a2332] shadow-[0_-2px_8px_rgba(0,0,0,0.15)] md:hidden",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:9:6",
            "data-orchids-name": "div",
            className: "flex items-center justify-around px-2 py-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:11:8",
                    "data-orchids-name": "a",
                    href: "/",
                    className: "flex flex-col items-center gap-1 rounded-lg px-4 py-2 transition-colors hover:bg-white/10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$house$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Home$3e$__["Home"], {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:15:10",
                            "data-orchids-name": "Home",
                            className: "h-5 w-5 text-[#6FCF26]"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 15,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:16:10",
                            "data-orchids-name": "span",
                            className: "text-[10px] font-medium text-white",
                            children: "Home"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 16,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                    lineNumber: 11,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:20:8",
                    "data-orchids-name": "a",
                    href: "#casino",
                    className: "flex flex-col items-center gap-1 rounded-lg px-4 py-2 transition-colors hover:bg-white/10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gamepad$2d$2$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Gamepad2$3e$__["Gamepad2"], {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:24:10",
                            "data-orchids-name": "Gamepad2",
                            className: "h-5 w-5 text-gray-400"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 24,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:25:10",
                            "data-orchids-name": "span",
                            className: "text-[10px] font-medium text-gray-400",
                            children: "Casino"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 25,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                    lineNumber: 20,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:29:8",
                    "data-orchids-name": "a",
                    href: "#sports",
                    className: "flex flex-col items-center gap-1 rounded-lg px-4 py-2 transition-colors hover:bg-white/10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trophy$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trophy$3e$__["Trophy"], {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:33:10",
                            "data-orchids-name": "Trophy",
                            className: "h-5 w-5 text-gray-400"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 33,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:34:10",
                            "data-orchids-name": "span",
                            className: "text-[10px] font-medium text-gray-400",
                            children: "Sports"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 34,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                    lineNumber: 29,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:38:8",
                    "data-orchids-name": "a",
                    href: "#promotions",
                    className: "flex flex-col items-center gap-1 rounded-lg px-4 py-2 transition-colors hover:bg-white/10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$gift$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Gift$3e$__["Gift"], {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:42:10",
                            "data-orchids-name": "Gift",
                            className: "h-5 w-5 text-gray-400"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 42,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:43:10",
                            "data-orchids-name": "span",
                            className: "text-[10px] font-medium text-gray-400",
                            children: "Promos"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 43,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                    lineNumber: 38,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:47:8",
                    "data-orchids-name": "a",
                    href: "#account",
                    className: "flex flex-col items-center gap-1 rounded-lg px-4 py-2 transition-colors hover:bg-white/10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"], {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:51:10",
                            "data-orchids-name": "User",
                            className: "h-5 w-5 text-gray-400"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 51,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            "data-orchids-id": "src/components/sections/mobile-bottom-navigation.tsx:52:10",
                            "data-orchids-name": "span",
                            className: "text-[10px] font-medium text-gray-400",
                            children: "Account"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                            lineNumber: 52,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
                    lineNumber: 47,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
            lineNumber: 9,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/mobile-bottom-navigation.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, this);
};
_c = MobileBottomNavigation;
const __TURBOPACK__default__export__ = MobileBottomNavigation;
var _c;
__turbopack_context__.k.register(_c, "MobileBottomNavigation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/star.js [app-client] (ecmascript) <export default as Star>");
"use client";
;
;
;
const HeroWelcomeSection = ()=>{
    return /*<section className="relative min-h-[400px] overflow-hidden bg-gradient-to-br from-[#0a4a5c] via-[#1a1f3a] to-[#0a4a5c] px-4 py-12 md:min-h-[500px] md:py-16 lg:py-20">*/ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:8:174",
        "data-orchids-name": "section",
        className: "relative min-h-[400px] overflow-hidden bg-gradient-to-br from-blue-700 via-blue-900 to-blue-700 px-4 py-12 md:min-h-[500px] md:py-16 lg:py-20",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:11:6",
                "data-orchids-name": "div",
                className: "absolute inset-0 opacity-20",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:12:8",
                    "data-orchids-name": "img",
                    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/hero-background-desktop-2.webp",
                    alt: "Hero Background",
                    fill: true,
                    className: "object-cover",
                    priority: true
                }, void 0, false, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                    lineNumber: 12,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                lineNumber: 11,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:21:6",
                "data-orchids-name": "div",
                className: "container relative mx-auto flex flex-col items-center gap-8 lg:flex-row lg:items-center lg:justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:23:8",
                        "data-orchids-name": "div",
                        className: "z-10 w-full text-center lg:w-1/2 lg:text-left",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:24:10",
                                "data-orchids-name": "p",
                                className: "mb-2 text-sm font-medium text-gray-400 md:text-base",
                                children: "Welcome Offer"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                lineNumber: 24,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:25:10",
                                "data-orchids-name": "h1",
                                className: "mb-2 text-4xl font-bold leading-tight text-[#FFB800] md:text-5xl lg:text-6xl",
                                children: "120% up to $5,000"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                lineNumber: 25,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:28:10",
                                "data-orchids-name": "p",
                                className: "mb-6 text-xl font-semibold text-white md:mb-8 md:text-2xl",
                                children: "and 75 Free Spins"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                lineNumber: 28,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:32:10",
                                "data-orchids-name": "div",
                                className: "flex flex-col items-center gap-4 lg:items-start",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:33:12",
                                        "data-orchids-name": "a",
                                        href: "#signup",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:34:14",
                                            "data-orchids-name": "button",
                                            className: "group relative overflow-hidden rounded-xl bg-gradient-to-b from-[#6FCF26] to-[#5DB51F] px-10 py-4 text-lg font-semibold text-white shadow-[0_0_24px_rgba(111,207,38,0.4)] transition-all hover:scale-105 hover:shadow-[0_0_32px_rgba(111,207,38,0.6)] md:px-12 md:py-5 md:text-xl",
                                            children: [
                                                "Sign Up Now",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:36:16",
                                                    "data-orchids-name": "span",
                                                    className: "mt-1 block text-xs font-normal opacity-90",
                                                    children: "Only Takes 30 seconds"
                                                }, void 0, false, {
                                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                                    lineNumber: 36,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                            lineNumber: 34,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                        lineNumber: 33,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:43:12",
                                        "data-orchids-name": "div",
                                        className: "flex items-center gap-3 rounded-lg bg-white/10 px-4 py-2 backdrop-blur-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:44:14",
                                                "data-orchids-name": "div",
                                                className: "flex items-center gap-1",
                                                children: [
                                                    1,
                                                    2,
                                                    3,
                                                    4,
                                                    5
                                                ].map((star)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"], {
                                                        "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:46:18",
                                                        "data-orchids-name": "Star",
                                                        className: "h-4 w-4 fill-[#6FCF26] text-[#6FCF26]"
                                                    }, star, false, {
                                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                                        lineNumber: 46,
                                                        columnNumber: 19
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                                lineNumber: 44,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:49:14",
                                                "data-orchids-name": "div",
                                                className: "text-left",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:50:16",
                                                        "data-orchids-name": "p",
                                                        className: "text-sm font-semibold text-white",
                                                        children: "Great"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                                        lineNumber: 50,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:51:16",
                                                        "data-orchids-name": "p",
                                                        className: "text-xs text-gray-300",
                                                        children: "550+ User Reviews"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                                        lineNumber: 51,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                                lineNumber: 49,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                        lineNumber: 43,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                lineNumber: 32,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                        lineNumber: 23,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:58:8",
                        "data-orchids-name": "div",
                        className: "relative z-10 w-full lg:w-1/2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:59:10",
                            "data-orchids-name": "div",
                            className: "relative mx-auto aspect-square w-full max-w-[400px] md:max-w-[500px]",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:61:12",
                                "data-orchids-name": "div",
                                className: "absolute inset-0 flex items-center justify-center",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:62:14",
                                    "data-orchids-name": "div",
                                    className: "text-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:63:16",
                                            "data-orchids-name": "div",
                                            className: "mb-4 text-6xl md:text-8xl",
                                            children: "🎰"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                            lineNumber: 63,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:64:16",
                                            "data-orchids-name": "div",
                                            className: "flex justify-center gap-4 text-4xl md:text-5xl",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:65:18",
                                                    "data-orchids-name": "span",
                                                    children: "🎲"
                                                }, void 0, false, {
                                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                                    lineNumber: 65,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:66:18",
                                                    "data-orchids-name": "span",
                                                    children: "🃏"
                                                }, void 0, false, {
                                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                                    lineNumber: 66,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    "data-orchids-id": "src/components/sections/hero-welcome-section.tsx:67:18",
                                                    "data-orchids-name": "span",
                                                    children: "💎"
                                                }, void 0, false, {
                                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                                    lineNumber: 67,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                            lineNumber: 64,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                    lineNumber: 62,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                                lineNumber: 61,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                            lineNumber: 59,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                        lineNumber: 58,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/hero-welcome-section.tsx",
        lineNumber: 8,
        columnNumber: 175
    }, this);
};
_c = HeroWelcomeSection;
const __TURBOPACK__default__export__ = HeroWelcomeSection;
var _c;
__turbopack_context__.k.register(_c, "HeroWelcomeSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/image.js [app-client] (ecmascript)");
"use client";
;
;
const cryptoIcons = [
    {
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/BTC-26.svg",
        name: "BTC"
    },
    {
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/ETH-27.svg",
        name: "ETH"
    },
    {
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/XRP-28.svg",
        name: "XRP"
    },
    {
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/SOL-29.svg",
        name: "SOL"
    },
    {
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/USDT-30.svg",
        name: "USDT"
    },
    {
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/USDC-31.svg",
        name: "USDC"
    },
    {
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/DOG-32.svg",
        name: "DOGE"
    },
    {
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/BNB-33.svg",
        name: "BNB"
    },
    {
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/ADA-34.svg",
        name: "ADA"
    },
    {
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/TRX-35.svg",
        name: "TRX"
    },
    {
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/LTC-36.svg",
        name: "LTC"
    },
    {
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/BCH-37.svg",
        name: "BCH"
    },
    {
        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/TON-38.svg",
        name: "TON"
    }
];
const DepositCryptoBanner = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-orchids-id": "src/components/sections/deposit-crypto-banner.tsx:23:4",
        "data-orchids-name": "div",
        className: "relative my-6 overflow-hidden rounded-xl bg-gradient-to-r from-[#162B3A] to-[#0D2433] p-4 shadow-lg md:my-8 md:p-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/deposit-crypto-banner.tsx:25:6",
                "data-orchids-name": "div",
                className: "absolute inset-0 opacity-10",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    "data-orchids-id": "src/components/sections/deposit-crypto-banner.tsx:26:8",
                    "data-orchids-name": "img",
                    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/deposit-banner-bg-39.svg",
                    alt: "Background Pattern",
                    fill: true,
                    className: "object-cover"
                }, void 0, false, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx",
                    lineNumber: 26,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/deposit-crypto-banner.tsx:34:6",
                "data-orchids-name": "div",
                className: "relative flex flex-col items-center gap-4 md:flex-row md:justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/deposit-crypto-banner.tsx:36:8",
                        "data-orchids-name": "div",
                        className: "text-center md:text-left",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            "data-orchids-id": "src/components/sections/deposit-crypto-banner.tsx:37:10",
                            "data-orchids-name": "h3",
                            className: "text-lg font-semibold text-white md:text-xl",
                            children: "Want to play? Deposit now"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx",
                            lineNumber: 37,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx",
                        lineNumber: 36,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/deposit-crypto-banner.tsx:43:8",
                        "data-orchids-name": "div",
                        className: "no-scrollbar flex w-full gap-3 overflow-x-auto md:w-auto md:flex-wrap md:justify-center",
                        children: cryptoIcons.map((crypto, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-map-index": index,
                                "data-orchids-id": "src/components/sections/deposit-crypto-banner.tsx:45:12@cryptoIcons",
                                "data-orchids-name": "div",
                                className: "flex-shrink-0 transition-transform hover:scale-110",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    "data-map-index": index,
                                    "data-orchids-id": "src/components/sections/deposit-crypto-banner.tsx:49:14@cryptoIcons",
                                    "data-orchids-name": "img",
                                    src: crypto.src,
                                    alt: crypto.name,
                                    width: 32,
                                    height: 32,
                                    className: "h-8 w-8"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx",
                                    lineNumber: 49,
                                    columnNumber: 15
                                }, this)
                            }, index, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx",
                                lineNumber: 45,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx",
                        lineNumber: 43,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        "data-orchids-id": "src/components/sections/deposit-crypto-banner.tsx:61:8",
                        "data-orchids-name": "a",
                        href: "#deposit",
                        className: "w-full md:w-auto",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            "data-orchids-id": "src/components/sections/deposit-crypto-banner.tsx:62:10",
                            "data-orchids-name": "button",
                            className: "w-full whitespace-nowrap rounded-lg bg-gradient-to-b from-[#6FCF26] to-[#5DB51F] px-8 py-3 font-semibold text-white shadow-[0_0_20px_rgba(111,207,38,0.3)] transition-all hover:scale-105 hover:shadow-[0_0_28px_rgba(111,207,38,0.5)] md:w-auto",
                            children: "Deposit"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx",
                            lineNumber: 62,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx",
                        lineNumber: 61,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/deposit-crypto-banner.tsx",
        lineNumber: 23,
        columnNumber: 5
    }, this);
};
_c = DepositCryptoBanner;
const __TURBOPACK__default__export__ = DepositCryptoBanner;
var _c;
__turbopack_context__.k.register(_c, "DepositCryptoBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/image.js [app-client] (ecmascript)");
"use client";
;
;
const CasinoSportsCards = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:7:4",
        "data-orchids-name": "div",
        className: "my-6 grid grid-cols-1 gap-4 md:my-8 md:grid-cols-2 md:gap-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:9:6",
                "data-orchids-name": "a",
                href: "#casino",
                className: "group relative overflow-hidden rounded-2xl transition-transform hover:scale-[1.02]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:13:8",
                        "data-orchids-name": "div",
                        className: "relative h-64 md:h-80",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:14:10",
                                "data-orchids-name": "img",
                                src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/banner_casino-3.webp",
                                alt: "Casino",
                                fill: true,
                                className: "object-cover brightness-90 transition-all group-hover:brightness-100"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                lineNumber: 14,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:20:10",
                                "data-orchids-name": "div",
                                className: "absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                lineNumber: 20,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                        lineNumber: 13,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:23:8",
                        "data-orchids-name": "div",
                        className: "absolute bottom-0 left-0 right-0 p-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:24:10",
                                "data-orchids-name": "div",
                                className: "mb-3 flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:25:12",
                                        "data-orchids-name": "img",
                                        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/seven-40.svg",
                                        alt: "Casino Icon",
                                        width: 40,
                                        height: 40
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                        lineNumber: 25,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:31:12",
                                        "data-orchids-name": "div",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:32:14",
                                                "data-orchids-name": "h3",
                                                className: "text-2xl font-bold text-white",
                                                children: "Casino"
                                            }, void 0, false, {
                                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                                lineNumber: 32,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:33:14",
                                                "data-orchids-name": "span",
                                                className: "inline-block rounded-full bg-[#8B5CF6] px-3 py-1 text-xs font-semibold text-white",
                                                children: "8k+ Games"
                                            }, void 0, false, {
                                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                                lineNumber: 33,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                        lineNumber: 31,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                lineNumber: 24,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:38:10",
                                "data-orchids-name": "p",
                                className: "text-sm text-gray-200 md:text-base",
                                children: "Explore our exclusive games, live casino, and thrilling slot games."
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                lineNumber: 38,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                        lineNumber: 23,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                lineNumber: 9,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:45:6",
                "data-orchids-name": "a",
                href: "#sportsbook",
                className: "group relative overflow-hidden rounded-2xl transition-transform hover:scale-[1.02]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:49:8",
                        "data-orchids-name": "div",
                        className: "relative h-64 md:h-80",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:50:10",
                                "data-orchids-name": "img",
                                src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/banner_sports-4.webp",
                                alt: "Sportsbook",
                                fill: true,
                                className: "object-cover brightness-90 transition-all group-hover:brightness-100"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                lineNumber: 50,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:56:10",
                                "data-orchids-name": "div",
                                className: "absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                lineNumber: 56,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:59:8",
                        "data-orchids-name": "div",
                        className: "absolute bottom-0 left-0 right-0 p-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:60:10",
                                "data-orchids-name": "div",
                                className: "mb-3 flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:61:12",
                                        "data-orchids-name": "img",
                                        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/football-41.svg",
                                        alt: "Sportsbook Icon",
                                        width: 40,
                                        height: 40
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                        lineNumber: 61,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:67:12",
                                        "data-orchids-name": "div",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:68:14",
                                                "data-orchids-name": "h3",
                                                className: "text-2xl font-bold text-white",
                                                children: "Sportsbook"
                                            }, void 0, false, {
                                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                                lineNumber: 68,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:69:14",
                                                "data-orchids-name": "span",
                                                className: "inline-block rounded-full bg-[#6FCF26] px-3 py-1 text-xs font-semibold text-white",
                                                children: "Free Bets"
                                            }, void 0, false, {
                                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                                lineNumber: 69,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                        lineNumber: 67,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                lineNumber: 60,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                "data-orchids-id": "src/components/sections/casino-sports-cards.tsx:74:10",
                                "data-orchids-name": "p",
                                className: "text-sm text-gray-200 md:text-base",
                                children: "Bet on Football, Cricket, NFL, eSports & more than 80 other sports."
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                                lineNumber: 74,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                        lineNumber: 59,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-sports-cards.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
};
_c = CasinoSportsCards;
const __TURBOPACK__default__export__ = CasinoSportsCards;
var _c;
__turbopack_context__.k.register(_c, "CasinoSportsCards");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const cryptoIcons = {
    BTC: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/BTC-43.svg',
    USDT: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/USDT-47.svg',
    XRP: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/XRP-44.svg',
    SOL: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/SOL-97.svg',
    LTC: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/LTC-42.svg',
    DOGE: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/DOG-45.svg',
    TRX: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/TRX-46.svg'
};
const liveWinsData = [
    {
        gameName: "West Town",
        winAmount: "$186.14",
        currency: "BTC",
        gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fsoftswiss%2FWestTown-17.png",
        gameUrl: "https://wild.io/games/west-town"
    },
    {
        gameName: "Bonanza Trillion",
        winAmount: "$1.00",
        currency: "USDT",
        gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fsoftswiss%2FBonanzaTrillion-19.png",
        gameUrl: "https://wild.io/games/bonanza-trillion"
    },
    {
        gameName: "Sharky Frenzy",
        winAmount: "$0.50",
        currency: "XRP",
        gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fwild.io%2Fthumbnail%2Fmancala%2FSharkyFrenzy-16.webp",
        gameUrl: "https://wild.io/games/sharky-frenzy"
    },
    {
        gameName: "Clucking Hell",
        winAmount: "$72.53",
        currency: "SOL",
        gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fsoftswiss%2FCluckingHell-22.png",
        gameUrl: "https://wild.io/games/clucking-hell"
    },
    {
        gameName: "Bonus Mania Plinko",
        winAmount: "$2.00",
        currency: "LTC",
        gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fkagaming%2FBonusManiaPlinko-12.png",
        gameUrl: "https://wild.io/games/bonus-mania-plinko"
    },
    {
        gameName: "Slot",
        winAmount: "$17.50",
        currency: "BTC",
        gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Foriginals%2FSlot-14.png",
        gameUrl: "https://wild.io/games/slot"
    },
    {
        gameName: "Hell Hot 20",
        winAmount: "$1.60",
        currency: "BTC",
        gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fendorphina%2Fendorphina2_HellHot20-7.png",
        gameUrl: "https://wild.io/games/hell-hot-20"
    },
    {
        gameName: "Hell Hot 100",
        winAmount: "$126.00",
        currency: "BTC",
        gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fendorphina%2Fendorphina2_HellHot100-9.png",
        gameUrl: "https://wild.io/games/hell-hot-100"
    },
    {
        gameName: "Fortune Mummy",
        winAmount: "$4.35",
        currency: "LTC",
        gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fbelatra%2FFortuneMummy-5.png",
        gameUrl: "https://wild.io/games/fortune-mummy"
    },
    {
        gameName: "Temple Of Ra",
        winAmount: "$1.20",
        currency: "BTC",
        gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fendorphina%2Fendorphina2_TempleOfRa-6.png",
        gameUrl: "https://wild.io/games/temple-of-ra"
    },
    {
        gameName: "Jackpot Joker FEVER",
        winAmount: "$6.40",
        currency: "XRP",
        gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fwild.io%2Fthumbnail%2Ftadagaming%2FJackpotJokerFEVER-8.webp",
        gameUrl: "https://wild.io/games/jackpot-joker-fever"
    },
    {
        gameName: "LuckyCrown 81x",
        winAmount: "$0.31",
        currency: "DOGE",
        gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2F1spin4win%2FLuckyCrown81x-10.png",
        gameUrl: "https://wild.io/games/luckycrown-81x"
    },
    {
        gameName: "Wild Bandito",
        winAmount: "$2.16",
        currency: "TRX",
        gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fwild.io%2Fthumbnail%2Fpgsoft%2FWildBandito-15.webp",
        gameUrl: "https://wild.io/games/wild-bandito"
    },
    {
        gameName: "Chaos Crew 3",
        winAmount: "$13.40",
        currency: "LTC",
        gameImage: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fhacksaw%2FChaosCrew394-18.png",
        gameUrl: "https://wild.io/games/chaos-crew-3"
    }
];
const WinCard = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(({ win })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
        "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:43:2",
        "data-orchids-name": "a",
        href: win.gameUrl,
        className: "flex-shrink-0 w-[150px] bg-[#1a1f2e] rounded-md shadow-md hover:shadow-xl transition-all duration-300 ease-in-out hover:scale-105",
        target: "_blank",
        rel: "noopener noreferrer",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:44:4",
                "data-orchids-name": "div",
                className: "relative h-[200px] w-full",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:44:47",
                    "data-orchids-name": "img",
                    src: win.gameImage,
                    alt: win.gameName,
                    layout: "fill",
                    objectFit: "cover",
                    className: "rounded-t-md"
                }, void 0, false, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                    lineNumber: 44,
                    columnNumber: 142
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                lineNumber: 44,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:45:4",
                "data-orchids-name": "div",
                className: "p-3 flex flex-col gap-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:46:6",
                        "data-orchids-name": "p",
                        className: "text-xs text-text-secondary truncate",
                        children: win.gameName
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                        lineNumber: 46,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:47:6",
                        "data-orchids-name": "div",
                        className: "flex items-center gap-1.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:48:8",
                                "data-orchids-name": "p",
                                className: "text-base font-bold text-white",
                                children: win.winAmount
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                                lineNumber: 48,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:49:8",
                                "data-orchids-name": "img",
                                src: cryptoIcons[win.currency],
                                alt: win.currency,
                                width: 16,
                                height: 16
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                                lineNumber: 49,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                        lineNumber: 47,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                lineNumber: 45,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
        lineNumber: 43,
        columnNumber: 3
    }, this));
_c = WinCard;
WinCard.displayName = 'WinCard';
const LiveWinsCarousel = ()=>{
    _s();
    const scrollContainerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const animationFrameRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    const isHovering = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const scrollSpeed = 0.5;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LiveWinsCarousel.useEffect": ()=>{
            const scroll = {
                "LiveWinsCarousel.useEffect.scroll": ()=>{
                    if (scrollContainerRef.current && !isHovering.current) {
                        const el = scrollContainerRef.current;
                        if (el.scrollLeft >= el.scrollWidth / 2) {
                            el.scrollLeft = el.scrollLeft - el.scrollWidth / 2;
                        } else {
                            el.scrollLeft += scrollSpeed;
                        }
                    }
                    animationFrameRef.current = requestAnimationFrame(scroll);
                }
            }["LiveWinsCarousel.useEffect.scroll"];
            animationFrameRef.current = requestAnimationFrame(scroll);
            return ({
                "LiveWinsCarousel.useEffect": ()=>{
                    if (animationFrameRef.current) {
                        cancelAnimationFrame(animationFrameRef.current);
                    }
                }
            })["LiveWinsCarousel.useEffect"];
        }
    }["LiveWinsCarousel.useEffect"], []);
    const handleScroll = (direction)=>{
        if (scrollContainerRef.current) {
            const scrollAmount = direction === 'left' ? -300 : 300;
            scrollContainerRef.current.scrollBy({
                left: scrollAmount,
                behavior: 'smooth'
            });
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:92:8",
        "data-orchids-name": "section",
        className: "py-8",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:93:12",
                "data-orchids-name": "style",
                children: `.no-scrollbar::-webkit-scrollbar { display: none; } .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }`
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                lineNumber: 93,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:94:12",
                "data-orchids-name": "div",
                className: "container",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:95:16",
                        "data-orchids-name": "div",
                        className: "flex items-center gap-3 mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:96:20",
                                "data-orchids-name": "span",
                                className: "relative flex h-3 w-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:96:60",
                                        "data-orchids-name": "span",
                                        className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                                        lineNumber: 96,
                                        columnNumber: 157
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:96:168",
                                        "data-orchids-name": "span",
                                        className: "relative inline-flex rounded-full h-3 w-3 bg-primary"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                                        lineNumber: 96,
                                        columnNumber: 361
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                                lineNumber: 96,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:97:20",
                                "data-orchids-name": "h2",
                                className: "text-2xl font-semibold text-white",
                                children: "Live Wins"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                                lineNumber: 97,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                        lineNumber: 95,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:99:16",
                        "data-orchids-name": "div",
                        className: "group relative",
                        onMouseEnter: ()=>isHovering.current = true,
                        onMouseLeave: ()=>isHovering.current = false,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:100:20@scrollContainerRef",
                                "data-orchids-name": "div",
                                ref: scrollContainerRef,
                                className: "flex gap-4 overflow-x-auto no-scrollbar",
                                children: [
                                    ...liveWinsData,
                                    ...liveWinsData
                                ].map((win, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(WinCard, {
                                        "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:101:80",
                                        "data-orchids-name": "WinCard",
                                        win: win
                                    }, `${win.gameName}-${index}`, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                                        lineNumber: 101,
                                        columnNumber: 81
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                                lineNumber: 100,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:103:20",
                                "data-orchids-name": "button",
                                onClick: ()=>handleScroll('left'),
                                className: "absolute left-0 top-1/2 -translate-y-1/2 z-10 p-2 bg-black/30 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-black/50",
                                "aria-label": "Scroll left",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                    "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:103:272",
                                    "data-orchids-name": "ChevronLeft",
                                    className: "h-6 w-6"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                                    lineNumber: 103,
                                    columnNumber: 372
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                                lineNumber: 103,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:104:20",
                                "data-orchids-name": "button",
                                onClick: ()=>handleScroll('right'),
                                className: "absolute right-0 top-1/2 -translate-y-1/2 z-10 p-2 bg-black/30 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-black/50",
                                "aria-label": "Scroll right",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                    "data-orchids-id": "src/components/sections/live-wins-carousel.tsx:104:275",
                                    "data-orchids-name": "ChevronRight",
                                    className: "h-6 w-6"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                                    lineNumber: 104,
                                    columnNumber: 375
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                                lineNumber: 104,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                        lineNumber: 99,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
                lineNumber: 94,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-wins-carousel.tsx",
        lineNumber: 92,
        columnNumber: 9
    }, this);
};
_s(LiveWinsCarousel, "HV24XITt1P1znpqliCnRw5CaaKA=");
_c1 = LiveWinsCarousel;
const __TURBOPACK__default__export__ = LiveWinsCarousel;
var _c, _c1;
__turbopack_context__.k.register(_c, "WinCard");
__turbopack_context__.k.register(_c1, "LiveWinsCarousel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$play$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Play$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/play.js [app-client] (ecmascript) <export default as Play>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const slugify = (text)=>text.toLowerCase().replace(' - ', '-').replace(/\s+/g, '-').replace(/[^\w-]+/g, '');
const gameData = [
    {
        name: 'Sweet Rush Bonanza',
        provider: 'Pragmatic Play',
        image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fpragmaticexternal%2FSweetRushBonanza-21.png'
    },
    {
        name: 'Clucking Hell',
        provider: 'BGAMING',
        image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fsoftswiss%2FCluckingHell-22.png'
    },
    {
        name: 'Wild Tiger 2',
        provider: 'BGAMING',
        image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fsoftswiss%2FWildTiger2-23.png'
    },
    {
        name: 'Chaos Crew 3',
        provider: 'Hacksaw Gaming',
        image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fhacksaw%2FChaosCrew394-24.png'
    },
    {
        name: 'Disco Farm',
        provider: 'Betsoft',
        image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fbsg%2FDiscoFarmHoldAndWin-25.png'
    },
    {
        name: '5 Lions Megaways 2',
        provider: 'Pragmatic Play',
        image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fwild.io%2Fthumbnail%2Fpragmaticexternal%2F5LionsMegaways2-26.webp'
    },
    {
        name: 'Coin Dazzle',
        provider: 'Platipus',
        image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fwild.io%2Fthumbnail%2Fplatipus%2Fcoindazzle-27.webp'
    },
    {
        name: 'Overheat',
        provider: 'Mascot',
        image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fwild.io%2Fthumbnail%2Fmascot%2Foverheat-28.webp'
    },
    {
        name: 'Bonanza Trillion',
        provider: 'BGAMING',
        image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fsoftswiss%2FBonanzaTrillion-29.png'
    },
    {
        name: 'Waves of Poseidon',
        provider: 'Pragmatic Play',
        image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fpragmaticexternal%2FWavesOfPoseidon-30.png'
    },
    {
        name: 'Freak Out',
        provider: 'Gamebeat',
        image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fwild.io%2Fthumbnail%2Fgamebeat%2FFreakOut-31.webp'
    },
    {
        name: 'Thunder Crown',
        provider: 'Endorphina',
        image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fendorphina%2Fendorphina2_ThunderCrown-32.png'
    },
    {
        name: 'Genie\'s Gem Bonanza',
        provider: 'Pragmatic Play',
        image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fpragmaticexternal%2FGeniesGemBonanza-33.png'
    },
    {
        name: 'Oktobearfest',
        provider: 'Popiplay',
        image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fpopiplay%2FOktobearfest-34.png'
    },
    {
        name: 'Fortune Chests',
        provider: 'Endorphina',
        image: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/https%3A%2F%2Fcdn.wild.io%2Fthumbnail%2Fendorphina%2Fendorphina2_FortuneChests-35.png'
    }
];
const games = gameData.map((game)=>({
        ...game,
        href: `/games/${slugify(game.name)}`
    }));
const GameCard = ({ game })=>{
    _s();
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isVisible, setIsVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GameCard.useEffect": ()=>{
            const observer = new IntersectionObserver({
                "GameCard.useEffect": ([entry])=>{
                    if (entry.isIntersecting) {
                        setIsVisible(true);
                        observer.unobserve(entry.target);
                    }
                }
            }["GameCard.useEffect"], {
                threshold: 0.1
            });
            const currentRef = ref.current;
            if (currentRef) {
                observer.observe(currentRef);
            }
            return ({
                "GameCard.useEffect": ()=>{
                    if (currentRef) {
                        observer.unobserve(currentRef);
                    }
                }
            })["GameCard.useEffect"];
        }
    }["GameCard.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        "data-orchids-id": "src/components/sections/casino-games-grid.tsx:68:4@ref",
        "data-orchids-name": "Link",
        ref: ref,
        href: game.href,
        className: `group relative block overflow-hidden rounded-lg outline-none transition-all duration-500 ease-out focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/casino-games-grid.tsx:75:6",
                "data-orchids-name": "div",
                className: "aspect-[3/4] w-full",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    "data-orchids-id": "src/components/sections/casino-games-grid.tsx:76:8",
                    "data-orchids-name": "img",
                    src: game.image,
                    alt: `Game thumbnail for ${game.name}`,
                    fill: true,
                    sizes: "(max-width: 768px) 50vw, (max-width: 1024px) 33vw, 20vw",
                    className: "object-cover transition-transform duration-300 group-hover:scale-105",
                    loading: "lazy"
                }, void 0, false, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                    lineNumber: 76,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                lineNumber: 75,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/casino-games-grid.tsx:85:6",
                "data-orchids-name": "div",
                className: "absolute inset-0 flex flex-col items-center justify-center bg-black/60 p-4 opacity-0 transition-opacity duration-300 group-hover:opacity-100",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/casino-games-grid.tsx:86:8",
                        "data-orchids-name": "div",
                        className: "absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/casino-games-grid.tsx:87:8",
                        "data-orchids-name": "div",
                        className: "relative z-10 flex h-14 w-14 transform items-center justify-center rounded-full bg-primary text-primary-foreground scale-75 transition-transform duration-300 group-hover:scale-100",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$play$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Play$3e$__["Play"], {
                            "data-orchids-id": "src/components/sections/casino-games-grid.tsx:88:10",
                            "data-orchids-name": "Play",
                            className: "ml-1 h-8 w-8 fill-current"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                            lineNumber: 88,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                        lineNumber: 87,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/casino-games-grid.tsx:90:8",
                        "data-orchids-name": "div",
                        className: "absolute bottom-4 left-4 right-4 z-10 text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                "data-orchids-id": "src/components/sections/casino-games-grid.tsx:91:10",
                                "data-orchids-name": "h4",
                                className: "truncate font-semibold uppercase text-white text-base",
                                children: game.name
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                                lineNumber: 91,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                "data-orchids-id": "src/components/sections/casino-games-grid.tsx:92:10",
                                "data-orchids-name": "p",
                                className: "text-xs uppercase text-text-secondary",
                                children: game.provider
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                                lineNumber: 92,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                        lineNumber: 90,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                lineNumber: 85,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
        lineNumber: 68,
        columnNumber: 5
    }, this);
};
_s(GameCard, "Wk8baY7uc+CWSrD2kMBp+I8qtIg=");
_c = GameCard;
const CasinoGamesGrid = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "data-orchids-id": "src/components/sections/casino-games-grid.tsx:101:4",
        "data-orchids-name": "section",
        className: "py-8 md:py-16",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            "data-orchids-id": "src/components/sections/casino-games-grid.tsx:102:6",
            "data-orchids-name": "div",
            className: "container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    "data-orchids-id": "src/components/sections/casino-games-grid.tsx:103:8",
                    "data-orchids-name": "div",
                    className: "mb-6 flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/casino-games-grid.tsx:104:10",
                            "data-orchids-name": "div",
                            className: "flex items-center gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    "data-orchids-id": "src/components/sections/casino-games-grid.tsx:105:12",
                                    "data-orchids-name": "Link",
                                    href: "/games",
                                    className: "hidden md:flex",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        "data-orchids-id": "src/components/sections/casino-games-grid.tsx:106:14",
                                        "data-orchids-name": "img",
                                        src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/providers-page-49.svg",
                                        alt: "Casino icon",
                                        width: 26,
                                        height: 26
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                                        lineNumber: 106,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                                    lineNumber: 105,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    "data-orchids-id": "src/components/sections/casino-games-grid.tsx:113:12",
                                    "data-orchids-name": "Link",
                                    href: "/games",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        "data-orchids-id": "src/components/sections/casino-games-grid.tsx:114:14",
                                        "data-orchids-name": "h3",
                                        className: "text-2xl font-bold text-white lg:text-3xl",
                                        children: "Casino"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                                        lineNumber: 114,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                                    lineNumber: 113,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                            lineNumber: 104,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            "data-orchids-id": "src/components/sections/casino-games-grid.tsx:117:10",
                            "data-orchids-name": "Link",
                            href: "/games",
                            className: "group flex items-center gap-2 text-text-secondary transition-colors hover:text-primary",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    "data-orchids-id": "src/components/sections/casino-games-grid.tsx:118:12",
                                    "data-orchids-name": "span",
                                    className: "text-right text-sm font-semibold leading-tight",
                                    children: [
                                        "View all",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {
                                            "data-orchids-id": "src/components/sections/casino-games-grid.tsx:120:14",
                                            "data-orchids-name": "br"
                                        }, void 0, false, {
                                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                                            lineNumber: 120,
                                            columnNumber: 15
                                        }, this),
                                        "3778"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                                    lineNumber: 118,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                    "data-orchids-id": "src/components/sections/casino-games-grid.tsx:123:12",
                                    "data-orchids-name": "ChevronRight",
                                    className: "h-4 w-4 shrink-0"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                                    lineNumber: 123,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                            lineNumber: 117,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                    lineNumber: 103,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    "data-orchids-id": "src/components/sections/casino-games-grid.tsx:127:8",
                    "data-orchids-name": "div",
                    className: "grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-5",
                    children: games.map((game, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(GameCard, {
                            "data-map-index": index,
                            "data-orchids-id": "src/components/sections/casino-games-grid.tsx:129:12@games",
                            "data-orchids-name": "GameCard",
                            game: game
                        }, index, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                            lineNumber: 129,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
                    lineNumber: 127,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
            lineNumber: 102,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/casino-games-grid.tsx",
        lineNumber: 101,
        columnNumber: 5
    }, this);
};
_c1 = CasinoGamesGrid;
const __TURBOPACK__default__export__ = CasinoGamesGrid;
var _c, _c1;
__turbopack_context__.k.register(_c, "GameCard");
__turbopack_context__.k.register(_c1, "CasinoGamesGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/image.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const DailyRakebackBanner = ()=>{
    _s();
    const [timeLeft, setTimeLeft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        days: 5,
        hours: 12,
        minutes: 30,
        seconds: 45
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DailyRakebackBanner.useEffect": ()=>{
            const timer = setInterval({
                "DailyRakebackBanner.useEffect.timer": ()=>{
                    setTimeLeft({
                        "DailyRakebackBanner.useEffect.timer": (prev)=>{
                            if (prev.seconds > 0) {
                                return {
                                    ...prev,
                                    seconds: prev.seconds - 1
                                };
                            } else if (prev.minutes > 0) {
                                return {
                                    ...prev,
                                    minutes: prev.minutes - 1,
                                    seconds: 59
                                };
                            } else if (prev.hours > 0) {
                                return {
                                    ...prev,
                                    hours: prev.hours - 1,
                                    minutes: 59,
                                    seconds: 59
                                };
                            } else if (prev.days > 0) {
                                return {
                                    days: prev.days - 1,
                                    hours: 23,
                                    minutes: 59,
                                    seconds: 59
                                };
                            }
                            return prev;
                        }
                    }["DailyRakebackBanner.useEffect.timer"]);
                }
            }["DailyRakebackBanner.useEffect.timer"], 1000);
            return ({
                "DailyRakebackBanner.useEffect": ()=>clearInterval(timer)
            })["DailyRakebackBanner.useEffect"];
        }
    }["DailyRakebackBanner.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:34:4",
        "data-orchids-name": "div",
        className: "relative my-8 overflow-hidden rounded-2xl bg-gradient-to-r from-purple-900 via-purple-800 to-blue-900 md:my-12",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:36:6",
                "data-orchids-name": "div",
                className: "absolute inset-0 opacity-30",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:37:8",
                    "data-orchids-name": "img",
                    src: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/images/rakeback-banner-36.png",
                    alt: "Rakeback Background",
                    fill: true,
                    className: "object-cover"
                }, void 0, false, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                    lineNumber: 37,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:45:6",
                "data-orchids-name": "div",
                className: "relative flex flex-col items-center gap-6 p-6 md:flex-row md:justify-between md:p-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:47:8",
                        "data-orchids-name": "div",
                        className: "text-center md:text-left",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:48:10",
                                "data-orchids-name": "p",
                                className: "mb-1 text-sm font-medium text-[#6FCF26] md:text-base",
                                children: "Earn rewards"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                lineNumber: 48,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:51:10",
                                "data-orchids-name": "p",
                                className: "text-base font-medium text-white md:text-lg",
                                children: "from every single bet you place."
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                lineNumber: 51,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:57:8",
                        "data-orchids-name": "div",
                        className: "text-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:58:10",
                            "data-orchids-name": "h2",
                            className: "text-3xl font-bold text-white md:text-4xl",
                            children: "Daily Rakeback"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                            lineNumber: 58,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                        lineNumber: 57,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:64:8",
                        "data-orchids-name": "div",
                        className: "flex flex-col items-center gap-3 md:flex-row md:gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:65:10",
                                "data-orchids-name": "div",
                                className: "text-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:66:12",
                                        "data-orchids-name": "p",
                                        className: "mb-2 text-xs font-semibold uppercase tracking-wide text-gray-300",
                                        children: "Hurry Up"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                        lineNumber: 66,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:69:12",
                                        "data-orchids-name": "div",
                                        className: "flex gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:70:14",
                                                "data-orchids-name": "div",
                                                className: "flex flex-col items-center rounded-lg bg-[#0D2433] px-3 py-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:71:16",
                                                        "data-orchids-name": "span",
                                                        className: "text-xl font-bold text-[#6FCF26] md:text-2xl",
                                                        children: timeLeft.days
                                                    }, void 0, false, {
                                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                                        lineNumber: 71,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:74:16",
                                                        "data-orchids-name": "span",
                                                        className: "text-[10px] uppercase text-gray-400",
                                                        children: "Days"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                                        lineNumber: 74,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                                lineNumber: 70,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:76:14",
                                                "data-orchids-name": "div",
                                                className: "flex flex-col items-center rounded-lg bg-[#0D2433] px-3 py-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:77:16",
                                                        "data-orchids-name": "span",
                                                        className: "text-xl font-bold text-[#6FCF26] md:text-2xl",
                                                        children: String(timeLeft.hours).padStart(2, "0")
                                                    }, void 0, false, {
                                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                                        lineNumber: 77,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:80:16",
                                                        "data-orchids-name": "span",
                                                        className: "text-[10px] uppercase text-gray-400",
                                                        children: "Hrs"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                                        lineNumber: 80,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                                lineNumber: 76,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:82:14",
                                                "data-orchids-name": "div",
                                                className: "flex flex-col items-center rounded-lg bg-[#0D2433] px-3 py-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:83:16",
                                                        "data-orchids-name": "span",
                                                        className: "text-xl font-bold text-[#6FCF26] md:text-2xl",
                                                        children: String(timeLeft.minutes).padStart(2, "0")
                                                    }, void 0, false, {
                                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                                        lineNumber: 83,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:86:16",
                                                        "data-orchids-name": "span",
                                                        className: "text-[10px] uppercase text-gray-400",
                                                        children: "Mins"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                                        lineNumber: 86,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                                lineNumber: 82,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:88:14",
                                                "data-orchids-name": "div",
                                                className: "flex flex-col items-center rounded-lg bg-[#0D2433] px-3 py-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:89:16",
                                                        "data-orchids-name": "span",
                                                        className: "text-xl font-bold text-[#6FCF26] md:text-2xl",
                                                        children: String(timeLeft.seconds).padStart(2, "0")
                                                    }, void 0, false, {
                                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                                        lineNumber: 89,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:92:16",
                                                        "data-orchids-name": "span",
                                                        className: "text-[10px] uppercase text-gray-400",
                                                        children: "Sec"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                                        lineNumber: 92,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                                lineNumber: 88,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                        lineNumber: 69,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                lineNumber: 65,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:97:10",
                                "data-orchids-name": "a",
                                href: "#claim-bonus",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    "data-orchids-id": "src/components/sections/daily-rakeback-banner.tsx:98:12",
                                    "data-orchids-name": "button",
                                    className: "whitespace-nowrap rounded-lg bg-gradient-to-b from-[#6FCF26] to-[#5DB51F] px-6 py-3 font-semibold text-white shadow-[0_0_20px_rgba(111,207,38,0.3)] transition-all hover:scale-105 hover:shadow-[0_0_28px_rgba(111,207,38,0.5)] md:px-8",
                                    children: "Claim Bonus"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                    lineNumber: 98,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                                lineNumber: 97,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                        lineNumber: 64,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/daily-rakeback-banner.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
};
_s(DailyRakebackBanner, "tzEXwcrfpTGWHXKPCDdLfY/V/XI=");
_c = DailyRakebackBanner;
const __TURBOPACK__default__export__ = DailyRakebackBanner;
var _c;
__turbopack_context__.k.register(_c, "DailyRakebackBanner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const providersData = [
    {
        name: 'Endorphina',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/endorphina-67.svg',
        games: 197,
        href: '/providers/endorphina'
    },
    {
        name: 'Originals',
        logo: null,
        games: 14,
        href: '/providers/originals'
    },
    {
        name: 'BGAMING',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/bgaming-68.svg',
        games: 207,
        href: '/providers/bgaming'
    },
    {
        name: 'Platipus',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/platipus-69.svg',
        games: 162,
        href: '/providers/platipus'
    },
    {
        name: 'BELATRA',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/belatra-70.svg',
        games: 108,
        href: '/providers/belatra'
    },
    {
        name: 'popiplay',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/popiplay-71.svg',
        games: 67,
        href: '/providers/popiplay'
    },
    {
        name: 'Onlyplay',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/onlyplay-72.svg',
        games: 123,
        href: '/providers/onlyplay'
    },
    {
        name: 'BSG',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/bsg-73.svg',
        games: 194,
        href: '/providers/bsg'
    },
    {
        name: 'Evolution',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/evolution-74.svg',
        games: 1,
        href: '/providers/evolution'
    },
    {
        name: 'Booming',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/booming-75.svg',
        games: 205,
        href: '/providers/booming'
    },
    {
        name: 'Gamebeat',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/gamebeat-76.svg',
        games: 51,
        href: '/providers/gamebeat'
    },
    {
        name: 'Mascot',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/mascot-77.svg',
        games: 123,
        href: '/providers/mascot'
    },
    {
        name: 'Yggdrasil',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/yggdrasil-78.svg',
        games: 347,
        href: '/providers/yggdrasil'
    },
    {
        name: 'AvatarUX',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/avatarux-79.svg',
        games: 65,
        href: '/providers/avatarux'
    },
    {
        name: 'GameArt',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/gameart-80.svg',
        games: 151,
        href: '/providers/gameart'
    },
    {
        name: 'KAGaming',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/kagaming-81.svg',
        games: 889,
        href: '/providers/kagaming'
    },
    {
        name: '1spin4win',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/1spin4win-82.svg',
        games: 174,
        href: '/providers/1spin4win'
    },
    {
        name: 'Nucleus',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/nucleus-83.svg',
        games: 154,
        href: '/providers/nucleus'
    },
    {
        name: 'Zillion',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/zillion-84.svg',
        games: 60,
        href: '/providers/zillion'
    },
    {
        name: 'Spribe',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/spribe-85.svg',
        games: 1,
        href: '/providers/spribe'
    },
    {
        name: 'Apparat',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/apparat-86.svg',
        games: 57,
        href: '/providers/apparat'
    },
    {
        name: 'Mancala',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/mancala-87.svg',
        games: 86,
        href: '/providers/mancala'
    },
    {
        name: 'Clawbuster',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/clawbuster-88.svg',
        games: 32,
        href: '/providers/clawbuster'
    },
    {
        name: 'Platipuslive',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/platipuslive-89.svg',
        games: 4,
        href: '/providers/platipuslive'
    },
    {
        name: 'TaDaGaming',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/tadagaming-90.svg',
        games: 196,
        href: '/providers/tadagaming'
    },
    {
        name: 'Beterlive',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/beterlive-91.svg',
        games: 51,
        href: '/providers/beterlive'
    },
    {
        name: 'FelixGaming',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/felixgaming-92.svg',
        games: 59,
        href: '/providers/felixgaming'
    },
    {
        name: 'PragmaticPlay',
        logo: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/c292a018-7934-447b-8b17-efc7cf47a9b9-wild-io/assets/svgs/pragmaticplay-93.svg',
        games: 510,
        href: '/providers/pragmaticplay'
    }
];
function useInterval(callback, delay) {
    _s();
    const savedCallback = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useInterval.useEffect": ()=>{
            savedCallback.current = callback;
        }
    }["useInterval.useEffect"], [
        callback
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useInterval.useEffect": ()=>{
            function tick() {
                if (savedCallback.current) {
                    savedCallback.current();
                }
            }
            if (delay !== null) {
                let id = setInterval(tick, delay);
                return ({
                    "useInterval.useEffect": ()=>clearInterval(id)
                })["useInterval.useEffect"];
            }
        }
    }["useInterval.useEffect"], [
        delay
    ]);
}
_s(useInterval, "dqNZMqbncP+HtqBlD20aSNv0Ugk=");
const GameProvidersCarousel = ()=>{
    _s1();
    const scrollContainerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [isHovered, setIsHovered] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const scrollAmount = 200 + 16;
    useInterval({
        "GameProvidersCarousel.useInterval": ()=>{
            if (scrollContainerRef.current) {
                const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
                if (scrollLeft + clientWidth >= scrollWidth - 1) {
                    scrollContainerRef.current.scrollTo({
                        left: 0,
                        behavior: 'smooth'
                    });
                } else {
                    scrollContainerRef.current.scrollBy({
                        left: scrollAmount,
                        behavior: 'smooth'
                    });
                }
            }
        }
    }["GameProvidersCarousel.useInterval"], isHovered ? null : 3000);
    const handleScroll = (direction)=>{
        if (scrollContainerRef.current) {
            scrollContainerRef.current.scrollBy({
                left: direction === 'left' ? -scrollAmount : scrollAmount,
                behavior: 'smooth'
            });
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:92:4",
        "data-orchids-name": "section",
        className: "py-8 md:py-16",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:93:6",
            "data-orchids-name": "div",
            className: "container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                    "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:94:8",
                    "data-orchids-name": "header",
                    className: "mb-6 flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:95:10",
                            "data-orchids-name": "div",
                            className: "flex items-center gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:96:12",
                                    "data-orchids-name": "img",
                                    src: "https://www.wild.io/cdn-cgi/image/width=3840,quality=75,format=auto//assets/providers-page.svg",
                                    alt: "Game Providers Icon",
                                    width: 32,
                                    height: 32
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                                    lineNumber: 96,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:102:12",
                                    "data-orchids-name": "h2",
                                    className: "text-xl font-bold text-white md:text-2xl",
                                    children: "Game Providers"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                                    lineNumber: 102,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                            lineNumber: 95,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:104:10",
                            "data-orchids-name": "Link",
                            href: "/providers",
                            className: "flex items-center gap-2 text-sm font-semibold text-primary transition-colors hover:brightness-110",
                            children: [
                                "View all",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:106:12",
                                    "data-orchids-name": "span",
                                    className: "flex h-5 w-5 items-center justify-center rounded-full bg-secondary text-xs font-bold text-primary",
                                    children: "28"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                                    lineNumber: 106,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                            lineNumber: 104,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                    lineNumber: 94,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:112:8",
                    "data-orchids-name": "div",
                    className: "relative",
                    onMouseEnter: ()=>setIsHovered(true),
                    onMouseLeave: ()=>setIsHovered(false),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:117:10@scrollContainerRef",
                            "data-orchids-name": "div",
                            ref: scrollContainerRef,
                            className: "flex gap-4 overflow-x-auto pb-4 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
                            children: providersData.map((provider)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:122:14@providersData",
                                    "data-orchids-name": "Link",
                                    href: provider.href,
                                    className: "group block flex-shrink-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:123:16@providersData",
                                        "data-orchids-name": "div",
                                        className: "flex h-[120px] w-[200px] flex-col items-center justify-center gap-2 rounded-xl bg-[#1a1f2e] p-4 text-center transition-all duration-300 ease-in-out group-hover:scale-105 group-hover:shadow-[0_0_20px_rgba(111,207,38,0.3)]",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:124:18@providersData",
                                                "data-orchids-name": "div",
                                                className: "flex h-10 flex-grow items-center justify-center",
                                                children: provider.logo ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:126:22@providersData",
                                                    "data-orchids-name": "div",
                                                    className: "relative h-10 w-36",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:127:24@providersData",
                                                        "data-orchids-name": "img",
                                                        src: provider.logo,
                                                        alt: `${provider.name} logo`,
                                                        fill: true,
                                                        sizes: "(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw",
                                                        style: {
                                                            objectFit: 'contain'
                                                        },
                                                        className: "filter invert"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                                                        lineNumber: 127,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                                                    lineNumber: 126,
                                                    columnNumber: 23
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:137:22@providersData",
                                                    "data-orchids-name": "span",
                                                    className: "text-3xl font-extrabold uppercase text-white",
                                                    children: provider.name
                                                }, void 0, false, {
                                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                                                    lineNumber: 137,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                                                lineNumber: 124,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:140:18@providersData",
                                                "data-orchids-name": "span",
                                                className: "text-sm text-text-secondary",
                                                children: [
                                                    provider.games,
                                                    " Games"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                                                lineNumber: 140,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                                        lineNumber: 123,
                                        columnNumber: 17
                                    }, this)
                                }, provider.name, false, {
                                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                                    lineNumber: 122,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                            lineNumber: 117,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:146:10",
                            "data-orchids-name": "button",
                            onClick: ()=>handleScroll('left'),
                            className: `absolute left-0 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2 grid h-10 w-10 place-items-center rounded-full bg-slate-800/80 text-white transition-opacity hover:bg-slate-700/90 disabled:opacity-0 ${isHovered ? 'opacity-100' : 'opacity-0'}`,
                            "aria-label": "Scroll left",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:151:14",
                                "data-orchids-name": "ChevronLeft",
                                size: 24
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                                lineNumber: 151,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                            lineNumber: 146,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:153:12",
                            "data-orchids-name": "button",
                            onClick: ()=>handleScroll('right'),
                            className: `absolute right-0 top-1/2 z-10 translate-x-1/2 -translate-y-1/2 grid h-10 w-10 place-items-center rounded-full bg-slate-800/80 text-white transition-opacity hover:bg-slate-700/90 disabled:opacity-0 ${isHovered ? 'opacity-100' : 'opacity-0'}`,
                            "aria-label": "Scroll right",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                "data-orchids-id": "src/components/sections/game-providers-carousel.tsx:158:14",
                                "data-orchids-name": "ChevronRight",
                                size: 24
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                                lineNumber: 158,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                            lineNumber: 153,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
                    lineNumber: 112,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
            lineNumber: 93,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/game-providers-carousel.tsx",
        lineNumber: 92,
        columnNumber: 5
    }, this);
};
_s1(GameProvidersCarousel, "d8OUnyXcvrtblVDaSpS24pReoQg=", false, function() {
    return [
        useInterval
    ];
});
_c = GameProvidersCarousel;
const __TURBOPACK__default__export__ = GameProvidersCarousel;
var _c;
__turbopack_context__.k.register(_c, "GameProvidersCarousel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const ListItem = ({ children })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
        "data-orchids-id": "src/components/sections/content-about-casino.tsx:7:2",
        "data-orchids-name": "li",
        className: "flex items-start",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                "data-orchids-id": "src/components/sections/content-about-casino.tsx:8:4",
                "data-orchids-name": "Check",
                className: "h-5 w-5 text-primary flex-shrink-0 mt-1 mr-4",
                style: {
                    color: '#5cb85c'
                }
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                lineNumber: 8,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                "data-orchids-id": "src/components/sections/content-about-casino.tsx:9:4",
                "data-orchids-name": "p",
                className: "!m-0 text-text-secondary leading-relaxed",
                children: children
            }, void 0, false, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                lineNumber: 9,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
        lineNumber: 7,
        columnNumber: 3
    }, this);
_c = ListItem;
const ContentAboutCasino = ()=>{
    _s();
    const [isExpanded, setIsExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-orchids-id": "src/components/sections/content-about-casino.tsx:17:4",
        "data-orchids-name": "div",
        className: "w-full bg-[#0f1419]",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            "data-orchids-id": "src/components/sections/content-about-casino.tsx:18:6",
            "data-orchids-name": "div",
            className: "max-w-[1200px] mx-auto py-16 px-4 md:px-8",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/content-about-casino.tsx:19:8",
                "data-orchids-name": "div",
                className: "space-y-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:20:10",
                        "data-orchids-name": "h1",
                        className: "text-white font-bold text-center text-2xl md:text-[2.5rem] !leading-tight mb-8",
                        children: "Xprimebet: Experience the Future of Online Gaming With the Best Bitcoin & Crypto Casino"
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                        lineNumber: 20,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:24:10",
                        "data-orchids-name": "p",
                        className: "text-base text-text-secondary leading-relaxed",
                        children: "Welcome to Xprimebet, your one-stop shop for premium online gaming using popular cryptocurrencies like Bitcoin (BTC), Solana (SOL), Bitcoin Cash (BCH), Ethereum (ETH), Litecoin (LTC), Binance Coin (BNB), Ripple (XRP), Tron (TRX), and Cardano (ADA). Whether you’re a crypto veteran or just getting started, we have lots of perks:"
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                        lineNumber: 24,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:28:10",
                        "data-orchids-name": "ul",
                        className: "list-none p-0 my-8 space-y-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ListItem, {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:29:12",
                                "data-orchids-name": "ListItem",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:30:14",
                                        "data-orchids-name": "a",
                                        href: "https://wild.io/blog/understanding-what-provably-fair-is",
                                        className: "text-[#5cb85c] hover:underline font-semibold",
                                        children: "Provably fair games"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 30,
                                        columnNumber: 15
                                    }, this),
                                    ": A major highlight of Xprimebet is its extensive collection of over 9000 games, showcasing its commitment to a vast and diverse gaming experience."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 29,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ListItem, {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:33:12",
                                "data-orchids-name": "ListItem",
                                children: "Instant deposits and withdrawals: We have rapid processing times for both deposits and withdrawals, ensuring you can start playing or cash out your winnings in less than 10 minutes."
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 33,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ListItem, {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:36:12",
                                "data-orchids-name": "ListItem",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:37:14",
                                        "data-orchids-name": "a",
                                        href: "https://wild.io/promotions",
                                        className: "text-[#5cb85c] hover:underline font-semibold",
                                        children: "Large bonuses and promotions"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 37,
                                        columnNumber: 15
                                    }, this),
                                    ": Take advantage of enticing offers, such as sign-up bonuses, free spins, and loyalty rewards to enhance your overall gaming experience."
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 36,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ListItem, {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:40:12",
                                "data-orchids-name": "ListItem",
                                children: "Privacy & Anonymity: One of the standout features of crypto casinos is the level of anonymity they offer. Transactions are recorded on a public ledger also known as the blockchain, without revealing your personal information, ensuring your privacy is maintained."
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 40,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ListItem, {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:43:12",
                                "data-orchids-name": "ListItem",
                                children: "Lower Transaction Fees: Compared to fiat payment methods, transaction fees for cryptocurrencies are generally much lower, allowing you to keep more of your winnings."
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 43,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                        lineNumber: 28,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:48:10",
                        "data-orchids-name": "div",
                        className: `${isExpanded ? "block" : "hidden"} space-y-6 text-text-secondary`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:49:12",
                                "data-orchids-name": "p",
                                className: "leading-relaxed",
                                children: "Read on to see why more players are choosing Xprimebet for their favorite crypto casino games, from classic table games to the latest slots, all powered by digital currencies."
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 49,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:51:12",
                                "data-orchids-name": "h2",
                                className: "text-3xl font-semibold text-white pt-4",
                                children: "Are Bitcoin Casinos Legit?"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 51,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:52:12",
                                "data-orchids-name": "p",
                                className: "leading-relaxed",
                                children: "Worried about online sites accepting BTC? Here’s what to check:"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 52,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:53:12",
                                "data-orchids-name": "ol",
                                className: "list-decimal list-inside space-y-2 pl-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:54:14",
                                        "data-orchids-name": "li",
                                        children: "Check licensing and regulation. Reputable operators, like those licensed by the Malta Gaming Authority, the UK Gambling Commission, or holding a Curaçao Gaming License, must follow strict guidelines. This ensures the casino's operations are legitimized and provides a safe environment for players."
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 54,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:55:14",
                                        "data-orchids-name": "li",
                                        children: "Look for provably fair gaming. Many crypto casinos use transparent algorithms that let you verify game results on the blockchain."
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 55,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:56:14",
                                        "data-orchids-name": "li",
                                        children: [
                                            "Read user reviews. ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:56:37",
                                                "data-orchids-name": "a",
                                                href: "https://www.trustpilot.com/review/wild.io",
                                                rel: "noopener noreferrer nofollow",
                                                target: "_blank",
                                                className: "text-[#5cb85c] hover:underline",
                                                children: "Look for feedback"
                                            }, void 0, false, {
                                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                                lineNumber: 56,
                                                columnNumber: 134
                                            }, this),
                                            " on withdrawal speed, fairness and overall customer satisfaction."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 56,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:57:14",
                                        "data-orchids-name": "li",
                                        children: "Security measures. A good site should use SSL encryption, two-factor authentication (2FA) and robust internal protocols to protect your funds and personal data."
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 57,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 53,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:59:12",
                                "data-orchids-name": "p",
                                className: "leading-relaxed",
                                children: "By doing some research, you can find a trustworthy crypto casino that respects your privacy and provides a reliable platform for online gaming—just like Xprimebet."
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 59,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:61:12",
                                "data-orchids-name": "h2",
                                className: "text-3xl font-semibold text-white pt-4",
                                children: "Responsible Gaming in Ethereum Casinos and Beyond"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 61,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:62:12",
                                "data-orchids-name": "p",
                                className: "leading-relaxed",
                                children: "Choosing a site that prioritizes responsible gambling is key for a safe and enjoyable experience. Look for:"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 62,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:63:12",
                                "data-orchids-name": "ul",
                                className: "list-disc list-inside space-y-2 pl-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:64:14",
                                        "data-orchids-name": "li",
                                        children: "Licensing & Regulation. An operator that follows regulatory requirements is more likely to have fair games and protect players."
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 64,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:65:14",
                                        "data-orchids-name": "li",
                                        children: "Provably Fair Games. Platforms that offer provably fair games ensure transparency and trust in the gaming experience, which is crucial for user satisfaction."
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 65,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:66:14",
                                        "data-orchids-name": "li",
                                        children: "Account Tools. Features like deposit limits, self-exclusion and time-outs to help you stay in control."
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 66,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:67:14",
                                        "data-orchids-name": "li",
                                        children: "Player Protection. Mandatory ID verification, age checks and other security measures to prevent fraud and underage play."
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 67,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:68:14",
                                        "data-orchids-name": "li",
                                        children: "Transparent Payouts. Reputable casinos show game payout percentages so you can make informed decisions."
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 68,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:69:14",
                                        "data-orchids-name": "li",
                                        children: "Support Resources. A site that cares about player well-being will link to external help organizations and offer direct support for problem gambling."
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 69,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 63,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:71:12",
                                "data-orchids-name": "p",
                                className: "leading-relaxed",
                                children: "Xprimebet has all of these measures in place to create a safe and secure environment for everyone whether you’re playing Ethereum casino games, Cardano or any other cryptocurrency."
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 71,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:76:12",
                                "data-orchids-name": "h2",
                                className: "text-3xl font-semibold text-white pt-4",
                                children: "FAQ"
                            }, void 0, false, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 76,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                "data-orchids-id": "src/components/sections/content-about-casino.tsx:77:12",
                                "data-orchids-name": "div",
                                className: "space-y-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:78:16",
                                        "data-orchids-name": "h3",
                                        className: "text-xl font-semibold text-white",
                                        children: "What cryptocurrencies do you accept?"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 78,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:79:16",
                                        "data-orchids-name": "p",
                                        children: "We accept a wide range of cryptocurrencies including Bitcoin (BTC), Ethereum (ETH), Litecoin (LTC), Dogecoin (DOGE), Bitcoin Cash (BCH), Ripple (XRP), Tron (TRX), Tether (USDT), Binance Coin (BNB), USD Coin (USDC), Cardano (ADA), and Solana (SOL). So you can play in your favourite cryptocurrency."
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 79,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:80:16",
                                        "data-orchids-name": "h3",
                                        className: "text-xl font-semibold text-white",
                                        children: "Are there bonuses for new players?"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 80,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:81:16",
                                        "data-orchids-name": "p",
                                        children: "Yes, new players at Xprimebet are welcome with a large variety of bonuses. The First Deposit Bonus consists of a reload of up to 120% (up to $1,000) + 75 high-value Free Spins (at $1.00 per spin). There are also bonuses for your second and third deposits to enhance your experience with us."
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 81,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:82:16",
                                        "data-orchids-name": "h3",
                                        className: "text-xl font-semibold text-white",
                                        children: "What types of games do you have?"
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 82,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:83:16",
                                        "data-orchids-name": "p",
                                        children: "We have over 9000 games including Bitcoin slots, dice games, classic table games like blackjack, roulette and baccarat, live casino games and unique games like Crash, Plinko, Bingo and Keno. Our games are for all types of players so everyone has a great time."
                                    }, void 0, false, {
                                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                        lineNumber: 83,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                                lineNumber: 77,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                        lineNumber: 48,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        "data-orchids-id": "src/components/sections/content-about-casino.tsx:87:10",
                        "data-orchids-name": "div",
                        className: "text-center",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            "data-orchids-id": "src/components/sections/content-about-casino.tsx:88:12",
                            "data-orchids-name": "button",
                            onClick: ()=>setIsExpanded(!isExpanded),
                            className: "text-[#5cb85c] font-semibold hover:underline mt-4 text-lg",
                            children: isExpanded ? "Read less" : "Read more"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                            lineNumber: 88,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                        lineNumber: 87,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
                lineNumber: 19,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
            lineNumber: 18,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/content-about-casino.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
};
_s(ContentAboutCasino, "FPNvbbHVlWWR4LKxxNntSxiIS38=");
_c1 = ContentAboutCasino;
const __TURBOPACK__default__export__ = ContentAboutCasino;
var _c, _c1;
__turbopack_context__.k.register(_c, "ListItem");
__turbopack_context__.k.register(_c1, "ContentAboutCasino");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$square$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageSquare$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/message-square.js [app-client] (ecmascript) <export default as MessageSquare>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/Documents/xprimebet-wildio-clone-main/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const LiveChatWidget = ()=>{
    _s();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-orchids-id": "src/components/sections/live-chat-widget.tsx:10:4",
        "data-orchids-name": "div",
        className: "fixed bottom-4 right-4 z-[9999] lg:bottom-8 lg:right-8",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            "data-orchids-id": "src/components/sections/live-chat-widget.tsx:11:6",
            "data-orchids-name": "button",
            onClick: ()=>setIsOpen(!isOpen),
            className: `
          group flex h-16 w-16 items-center justify-center rounded-full bg-[#6FCF26] text-white
          shadow-[0_0_20px_rgba(111,207,38,0.3)]
          transition-all duration-300 ease-in-out
          hover:scale-110 hover:shadow-[0_0_30px_rgba(111,207,38,0.6)]
          focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2
          ${!isOpen ? "animate-pulse" : ""}
        `,
            "aria-label": "Toggle live chat",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                "data-orchids-id": "src/components/sections/live-chat-widget.tsx:23:8",
                "data-orchids-name": "div",
                className: "relative flex h-full w-full items-center justify-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "data-orchids-id": "src/components/sections/live-chat-widget.tsx:24:10",
                        "data-orchids-name": "span",
                        className: `
              absolute inset-0 flex items-center justify-center
              transition-opacity duration-300
              ${isOpen ? "opacity-0" : "opacity-100"}
            `,
                        "aria-hidden": isOpen,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$square$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageSquare$3e$__["MessageSquare"], {
                            "data-orchids-id": "src/components/sections/live-chat-widget.tsx:32:12",
                            "data-orchids-name": "MessageSquare",
                            size: 32,
                            className: "stroke-current"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx",
                            lineNumber: 32,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx",
                        lineNumber: 24,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        "data-orchids-id": "src/components/sections/live-chat-widget.tsx:34:10",
                        "data-orchids-name": "span",
                        className: `
              absolute inset-0 flex items-center justify-center
              transition-opacity duration-300
              ${isOpen ? "opacity-100" : "opacity-0"}
            `,
                        "aria-hidden": !isOpen,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$xprimebet$2d$wildio$2d$clone$2d$main$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                            "data-orchids-id": "src/components/sections/live-chat-widget.tsx:42:12",
                            "data-orchids-name": "X",
                            size: 32,
                            className: "stroke-current"
                        }, void 0, false, {
                            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx",
                            lineNumber: 42,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx",
                        lineNumber: 34,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx",
                lineNumber: 23,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx",
            lineNumber: 11,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/xprimebet-wildio-clone-main/src/components/sections/live-chat-widget.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
};
_s(LiveChatWidget, "+sus0Lb0ewKHdwiUhiTAJFoFyQ0=");
_c = LiveChatWidget;
const __TURBOPACK__default__export__ = LiveChatWidget;
var _c;
__turbopack_context__.k.register(_c, "LiveChatWidget");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=Documents_xprimebet-wildio-clone-main_src_components_sections_597e932b._.js.map