__turbopack_load_page_chunks__("/_app", [
  "static/chunks/[root-of-the-server]__f1e62870._.js",
  "static/chunks/01257_react-dom_3b32046d._.js",
  "static/chunks/01257_147f2e45._.js",
  "static/chunks/[root-of-the-server]__63db1cf1._.js",
  "static/chunks/Documents_xprimebet-wildio-clone-main_pages__app_5771e187._.js",
  "static/chunks/Documents_xprimebet-wildio-clone-main_pages__app_4961616e._.js"
])
