__turbopack_load_page_chunks__("/_error", [
  "static/chunks/[root-of-the-server]__100d3eb0._.js",
  "static/chunks/01257_react-dom_3b32046d._.js",
  "static/chunks/01257_147f2e45._.js",
  "static/chunks/[root-of-the-server]__16d4a67d._.js",
  "static/chunks/Documents_xprimebet-wildio-clone-main_pages__error_5771e187._.js",
  "static/chunks/Documents_xprimebet-wildio-clone-main_pages__error_7317d3cb._.js"
])
