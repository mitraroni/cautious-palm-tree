(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Documents_xprimebet-wildio-clone-main_src_2518a077._.js",
  "static/chunks/01257_f4788b65._.js"
],
    source: "dynamic"
});
